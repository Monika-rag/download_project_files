import fnmatch
import logging
import posixpath
from typing import List, Optional, Dict, Any

from azure.core.exceptions import ResourceNotFoundError
from azure.storage.filedatalake import DataLakeServiceClient


class OneLakeService:
    """
    Service class responsible for Fabric OneLake operations:
    - Normalize Lakehouse folder paths
    - Validate source and target folders already exist
    - List files
    - Filter files by pattern
    - Validate source file count
    - Read files
    - Write files without creating directories
    - Validate copied file size
    - Delete source files after successful copy if move mode is enabled

    Important:
    This service intentionally does NOT create any OneLake directory.
    Required source and target folders must already exist before execution.
    """

    def __init__(self, credential, workspace_name: str, lakehouse_name: str):
        self.credential = credential
        self.workspace_name = workspace_name
        self.lakehouse_name = lakehouse_name

        self.service_client = DataLakeServiceClient(
            account_url="https://onelake.dfs.fabric.microsoft.com",
            credential=self.credential
        )

        # In OneLake ADLS-compatible API, the Fabric workspace is used as the file system.
        self.file_system_client = self.service_client.get_file_system_client(
            file_system=self.workspace_name
        )

    # ============================================================
    # Path helpers
    # ============================================================

    def _lakehouse_root(self) -> str:
        if self.lakehouse_name.endswith(".Lakehouse"):
            return self.lakehouse_name

        return f"{self.lakehouse_name}.Lakehouse"

    def _normalize_folder_path(self, folder_path: str) -> str:
        """
        Converts user-friendly Lakehouse folder path into OneLake DFS path.

        Accepted:
        - Files/processed/Dataverse/2026/06/week02
        - processed/Dataverse/2026/06/week02
        - /lakehouse/default/Files/processed/Dataverse/2026/06/week02

        Returned:
        <lakehouse>.Lakehouse/Files/processed/Dataverse/2026/06/week02
        """

        if not folder_path or str(folder_path).strip() == "":
            raise ValueError("folder_path cannot be empty.")

        folder_path = str(folder_path).strip().replace("\\", "/")

        if folder_path.startswith("/lakehouse/default/"):
            folder_path = folder_path.replace("/lakehouse/default/", "", 1)

        if folder_path.startswith("Files:/"):
            folder_path = folder_path.replace("Files:/", "Files/", 1)

        folder_path = folder_path.strip("/")

        lakehouse_root = self._lakehouse_root()

        if folder_path.startswith(f"{lakehouse_root}/"):
            return folder_path.rstrip("/")

        if not folder_path.startswith("Files/") and not folder_path.startswith("Tables/"):
            folder_path = f"Files/{folder_path}"

        return f"{lakehouse_root}/{folder_path}".rstrip("/")

    def _validate_directory_exists(self, directory_path: str, path_label: str = "Directory") -> None:
        """
        Validates that a OneLake directory already exists.

        This function does NOT create any directory.
        It only checks whether the path exists.
        """

        if not directory_path or str(directory_path).strip() == "":
            raise ValueError("directory_path cannot be empty.")

        directory_path = directory_path.strip("/").replace("\\", "/")

        logging.info("Validating %s exists: %s", path_label, directory_path)

        try:
            directory_client = self.file_system_client.get_directory_client(directory_path)
            directory_client.get_directory_properties()
            logging.info("%s exists: %s", path_label, directory_path)

        except ResourceNotFoundError:
            raise FileNotFoundError(
                f"{path_label} does not exist: {directory_path}. "
                f"Please create this folder before running the Function App."
            )

    # ============================================================
    # File operations
    # ============================================================

    def list_files(self, folder_path: str, recursive: bool = False) -> List[str]:
        """
        Lists files from a OneLake folder.

        If recursive=False:
        Only direct files under the folder are returned.

        If recursive=True:
        Files from subfolders are also returned.
        """

        source_directory_path = self._normalize_folder_path(folder_path)

        logging.info("Listing files from OneLake path: %s", source_directory_path)
        logging.info("Recursive listing enabled: %s", recursive)

        try:
            paths = self.file_system_client.get_paths(
                path=source_directory_path,
                recursive=recursive
            )

            file_paths = []

            for path in paths:
                if path.is_directory:
                    logging.info("Skipping directory: %s", path.name)
                    continue

                logging.info("File discovered: %s", path.name)
                file_paths.append(path.name)

            logging.info("Total files found: %s", len(file_paths))
            return file_paths

        except ResourceNotFoundError:
            logging.error("Source folder does not exist: %s", source_directory_path)
            raise

    def _filter_files_by_pattern(self, file_paths: List[str], file_pattern: str) -> List[str]:
        """
        Filters files by filename pattern.
        Example:
        *.csv
        Practitioner*.csv
        *
        """

        if not file_pattern or str(file_pattern).strip() == "":
            file_pattern = "*"

        filtered_files = []

        for file_path in file_paths:
            file_name = posixpath.basename(file_path)

            if fnmatch.fnmatch(file_name, file_pattern):
                filtered_files.append(file_path)

        logging.info(
            "Files matching pattern '%s': %s",
            file_pattern,
            len(filtered_files)
        )

        return filtered_files

    def read_file_by_full_path(self, file_full_path: str) -> bytes:
        """
        Reads file content from OneLake using full DFS path.
        """

        logging.info("Reading OneLake file: %s", file_full_path)

        file_client = self.file_system_client.get_file_client(file_full_path)
        file_content = file_client.download_file().readall()

        logging.info(
            "Read completed for file: %s. Size: %s bytes",
            file_full_path,
            len(file_content)
        )

        return file_content

    def write_file_by_full_path(self, file_full_path: str, file_content: bytes) -> None:
        """
        Writes bytes to OneLake file path.

        Important:
        This function does NOT create target directory.
        Target directory must already exist.
        """

        logging.info("Preparing to write OneLake file: %s", file_full_path)

        target_directory = posixpath.dirname(file_full_path)

        # Validate only. Do not create directory.
        self._validate_directory_exists(
            directory_path=target_directory,
            path_label="Target directory"
        )

        file_client = self.file_system_client.get_file_client(file_full_path)

        file_client.upload_data(
            data=file_content,
            overwrite=True
        )

        logging.info("File written successfully: %s", file_full_path)

    def get_file_size_by_full_path(self, file_full_path: str) -> int:
        """
        Gets file size in bytes from OneLake.
        """

        file_client = self.file_system_client.get_file_client(file_full_path)
        properties = file_client.get_file_properties()

        size = getattr(properties, "size", None)

        if size is None:
            try:
                size = properties["size"]
            except Exception:
                size = len(file_client.download_file().readall())

        return int(size)

    def delete_file_by_full_path(self, file_full_path: str) -> None:
        """
        Deletes a file from OneLake.
        Used only when MOVE_AFTER_COPY=true.
        """

        logging.info("Deleting source OneLake file after successful copy: %s", file_full_path)

        file_client = self.file_system_client.get_file_client(file_full_path)
        file_client.delete_file()

        logging.info("Source file deleted successfully: %s", file_full_path)

    def _build_target_file_path(
        self,
        source_file_path: str,
        source_folder_path: str,
        target_folder_path: str,
        recursive: bool
    ) -> str:
        """
        Builds target file path.

        Non-recursive:
        source: .../source/file.csv
        target: .../target/file.csv

        Recursive:
        source: .../source/sub1/file.csv
        target: .../target/sub1/file.csv
        """

        if not recursive:
            file_name = posixpath.basename(source_file_path)
            return f"{target_folder_path}/{file_name}"

        relative_path = source_file_path.replace(source_folder_path, "", 1).lstrip("/")
        return f"{target_folder_path}/{relative_path}"

    # ============================================================
    # Copy / move operation with validations
    # ============================================================

    def copy_folder_files(
        self,
        source_folder: str,
        target_folder: str,
        file_pattern: str = "*",
        expected_file_count: Optional[int] = None,
        move_after_copy: bool = False,
        recursive: bool = False,
        fail_if_no_files: bool = True
    ) -> Dict[str, Any]:
        """
        Copies or moves all matching files from source OneLake folder to target OneLake folder.

        Validations:
        - Source folder exists.
        - Target folder exists.
        - Source files are listed.
        - File count matches expected_file_count when provided.
        - Copied count equals source matched count.
        - Source file size equals target file size.
        - Source files are deleted only after successful copy validation when move_after_copy=True.

        Important:
        This method does NOT create any directory.
        """

        logging.info("Starting copy_folder_files operation.")
        logging.info("Source folder input: %s", source_folder)
        logging.info("Target folder input: %s", target_folder)
        logging.info("File pattern: %s", file_pattern)
        logging.info("Expected file count: %s", expected_file_count)
        logging.info("Move after copy: %s", move_after_copy)
        logging.info("Recursive: %s", recursive)
        logging.info("Fail if no files: %s", fail_if_no_files)

        source_directory_path = self._normalize_folder_path(source_folder)
        target_directory_path = self._normalize_folder_path(target_folder)

        logging.info("Normalized source path: %s", source_directory_path)
        logging.info("Normalized target path: %s", target_directory_path)

        # Validate both source and target directories. Do not create folders.
        self._validate_directory_exists(
            directory_path=source_directory_path,
            path_label="Source directory"
        )

        self._validate_directory_exists(
            directory_path=target_directory_path,
            path_label="Target directory"
        )

        all_source_files = self.list_files(source_folder, recursive=recursive)
        source_files = self._filter_files_by_pattern(all_source_files, file_pattern)

        source_file_count = len(source_files)

        if source_file_count == 0:
            message = f"No matching files found in source folder: {source_directory_path}"

            if fail_if_no_files:
                raise FileNotFoundError(message)

            logging.warning(message)

            return {
                "source_directory": source_directory_path,
                "target_directory": target_directory_path,
                "source_file_count": 0,
                "copied_file_count": 0,
                "deleted_source_file_count": 0,
                "move_after_copy": move_after_copy,
                "file_pattern": file_pattern,
                "files": []
            }

        if expected_file_count is not None:
            expected_file_count = int(expected_file_count)

            if source_file_count != expected_file_count:
                raise ValueError(
                    f"Source file count validation failed. "
                    f"Expected: {expected_file_count}, Actual: {source_file_count}, "
                    f"Source folder: {source_directory_path}"
                )

        copied_files = []

        # ------------------------------------------------------------
        # Copy files first. Do not delete source yet.
        # ------------------------------------------------------------
        for source_file_path in source_files:
            target_file_path = self._build_target_file_path(
                source_file_path=source_file_path,
                source_folder_path=source_directory_path,
                target_folder_path=target_directory_path,
                recursive=recursive
            )

            logging.info(
                "Copying OneLake file. Source: %s Target: %s",
                source_file_path,
                target_file_path
            )

            file_content = self.read_file_by_full_path(source_file_path)
            source_file_size = len(file_content)

            self.write_file_by_full_path(
                file_full_path=target_file_path,
                file_content=file_content
            )

            target_file_size = self.get_file_size_by_full_path(target_file_path)

            if source_file_size != target_file_size:
                raise ValueError(
                    f"File size validation failed for {posixpath.basename(source_file_path)}. "
                    f"Source size: {source_file_size}, Target size: {target_file_size}"
                )

            copied_files.append(
                {
                    "file_name": posixpath.basename(source_file_path),
                    "source_path": source_file_path,
                    "target_path": target_file_path,
                    "source_size_bytes": source_file_size,
                    "target_size_bytes": target_file_size,
                    "status": "copied"
                }
            )

        copied_file_count = len(copied_files)

        if copied_file_count != source_file_count:
            raise ValueError(
                f"Copied file count validation failed. "
                f"Source count: {source_file_count}, Copied count: {copied_file_count}"
            )

        # ------------------------------------------------------------
        # Delete source only after all files are copied and validated.
        # ------------------------------------------------------------
        deleted_source_file_count = 0

        if move_after_copy:
            for source_file_path in source_files:
                self.delete_file_by_full_path(source_file_path)
                deleted_source_file_count += 1

            for file_info in copied_files:
                file_info["status"] = "moved"

        logging.info(
            "copy_folder_files completed. Source count: %s, Copied count: %s, Deleted source count: %s",
            source_file_count,
            copied_file_count,
            deleted_source_file_count
        )

        return {
            "source_directory": source_directory_path,
            "target_directory": target_directory_path,
            "source_file_count": source_file_count,
            "copied_file_count": copied_file_count,
            "deleted_source_file_count": deleted_source_file_count,
            "move_after_copy": move_after_copy,
            "file_pattern": file_pattern,
            "files": copied_files
        }
