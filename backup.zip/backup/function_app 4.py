import json
import logging
import os
from datetime import datetime

import azure.functions as func
from azure.identity import ManagedIdentityCredential

from services.onelake_service import OneLakeService
# from services.sftp_service import SftpService


app = func.FunctionApp(http_auth_level=func.AuthLevel.FUNCTION)


# ============================================================
# Helper functions
# ============================================================

def to_bool(value) -> bool:
    """
    Converts string/bool value to boolean.
    """
    return str(value).strip().lower() in ["true", "1", "yes", "y"]



def get_int_or_none(value):
    """
    Converts value to int if provided, otherwise returns None.
    """
    if value is None or str(value).strip() == "":
        return None

    return int(value)



def get_managed_identity_credential():
    """
    Uses user-assigned managed identity when MANAGED_IDENTITY_CLIENT_ID is available.
    Otherwise uses system-assigned managed identity.
    """
    managed_identity_client_id = "dd81e28d-86ec-40ad-be60-129b99b8574f" #os.getenv("MANAGED_IDENTITY_CLIENT_ID")

    if managed_identity_client_id:
        logging.info("Using user-assigned managed identity.")
        return ManagedIdentityCredential(client_id=managed_identity_client_id)

    logging.info("Using system-assigned managed identity.")
    return ManagedIdentityCredential()



def get_year_month_week(processing_date: str):
    """
    Derives year/month/week folder from processing_date.

    Week logic:
    01-07 = week01
    08-14 = week02
    15-21 = week03
    22-28 = week04
    29-31 = week05

    Example:
    2026-06-10 -> 2026/06/week02
    """
    if processing_date is None or str(processing_date).strip() == "":
        raise ValueError("processing_date is required.")

    processing_dt = datetime.strptime(str(processing_date)[:10], "%Y-%m-%d")

    year = processing_dt.strftime("%Y")
    month = processing_dt.strftime("%m")
    week_no = ((processing_dt.day - 1) // 7) + 1
    week_folder = f"week{week_no:02d}"

    return year, month, week_folder



def build_weekly_folder(
    base_folder: str,
    year: str,
    month: str,
    week_folder: str,
    sub_folder: str = None
) -> str:
    """
    Builds weekly Lakehouse folder path.

    Example:
    base_folder = Files/processed/Dataverse
    year = 2026
    month = 06
    week_folder = week02

    Output:
    Files/processed/Dataverse/2026/06/week02
    """
    if base_folder is None or str(base_folder).strip() == "":
        raise ValueError("base_folder is required.")

    folder_path = (
        f"{str(base_folder).strip().strip('/')}/"
        f"{year}/{month}/{week_folder}"
    )

    if sub_folder is not None and str(sub_folder).strip() != "":
        folder_path = f"{folder_path}/{str(sub_folder).strip().strip('/')}"

    return folder_path


# ============================================================
# HTTP trigger called from Fabric Function Activity
# ============================================================

@app.route(route="move-weekly-onelake-files", methods=["POST"])
def move_onelake_files(req: func.HttpRequest) -> func.HttpResponse:
    """
    HTTP-triggered Azure Function.

    Called from Fabric Function Activity.

    Current scope:
    - Connect to Fabric OneLake using Function App Managed Identity.
    - Pick files from weekly source folder.
    - Copy or move files to weekly destination folder.
    - Validate source file count before movement.
    - Validate target folder exists before writing.
    - Validate copied file count and file size after movement.
    - Does NOT create any OneLake directory.
    - SFTP movement is disabled for now.

    Example source:
    Files/processed/Dataverse/2026/06/week02

    Example destination:
    Files/onelake-destination/Dataverse/2026/06/week02
    """

    logging.info("Started move-weekly-onelake-files HTTP function.")

    try:
        try:
            body = req.get_json()
        except ValueError:
            body = {}

        logging.info("Request body received: %s", json.dumps(body))

        # ------------------------------------------------------------
        # Runtime parameters from Fabric body
        # ------------------------------------------------------------
        processing_date = body.get("processing_date")

        source_base_folder = (
            body.get("source_base_folder")
            or os.getenv("ONELAKE_SOURCE_BASE_FOLDER")
            or os.getenv("ONELAKE_SOURCE_FOLDER")
        )

        target_base_folder = (
            body.get("target_base_folder")
            or os.getenv("ONELAKE_TARGET_BASE_FOLDER")
            or os.getenv("ONELAKE_TARGET_FOLDER")
        )

        source_sub_folder = body.get("source_sub_folder")
        target_sub_folder = body.get("target_sub_folder")

        file_pattern = body.get("file_pattern") or os.getenv("FILE_PATTERN", "*")

        expected_file_count = get_int_or_none(
            body.get("expected_file_count")
            or os.getenv("EXPECTED_FILE_COUNT")
        )

        move_after_copy = to_bool(
            body.get("move_after_copy", os.getenv("MOVE_AFTER_COPY", "false"))
        )

        recursive_copy = to_bool(
            body.get("recursive", os.getenv("RECURSIVE_COPY", "false"))
        )

        fail_if_no_files = to_bool(
            body.get("fail_if_no_files", os.getenv("FAIL_IF_NO_FILES", "true"))
        )

        # ------------------------------------------------------------
        # Environment variables from Azure Function App configuration
        # These can also be overridden from Fabric body if needed.
        # ------------------------------------------------------------
        fabric_workspace_name = (
            body.get("fabric_workspace_name")
            or os.getenv("FABRIC_WORKSPACE_NAME")
        )

        lakehouse_name = (
            body.get("lakehouse_name")
            or os.getenv("FABRIC_LAKEHOUSE_NAME")
        )

        if not fabric_workspace_name:
            raise ValueError("FABRIC_WORKSPACE_NAME is required in app settings or request body.")

        if not lakehouse_name:
            raise ValueError("FABRIC_LAKEHOUSE_NAME is required in app settings or request body.")

        if not source_base_folder:
            raise ValueError("source_base_folder or ONELAKE_SOURCE_FOLDER is required.")

        if not target_base_folder:
            raise ValueError("target_base_folder or ONELAKE_TARGET_FOLDER is required.")

        # ------------------------------------------------------------
        # Build weekly source and target paths
        # ------------------------------------------------------------
        year, month, week_folder = get_year_month_week(processing_date)

        source_folder = build_weekly_folder(
            base_folder=source_base_folder,
            year=year,
            month=month,
            week_folder=week_folder,
            sub_folder=source_sub_folder
        )

        target_folder = build_weekly_folder(
            base_folder=target_base_folder,
            year=year,
            month=month,
            week_folder=week_folder,
            sub_folder=target_sub_folder
        )

        logging.info("FABRIC_WORKSPACE_NAME: %s", fabric_workspace_name)
        logging.info("FABRIC_LAKEHOUSE_NAME: %s", lakehouse_name)
        logging.info("Processing date: %s", processing_date)
        logging.info("Year/month/week: %s/%s/%s", year, month, week_folder)
        logging.info("Source folder: %s", source_folder)
        logging.info("Target folder: %s", target_folder)
        logging.info("File pattern: %s", file_pattern)
        logging.info("Expected file count: %s", expected_file_count)
        logging.info("MOVE_AFTER_COPY: %s", move_after_copy)
        logging.info("RECURSIVE_COPY: %s", recursive_copy)
        logging.info("FAIL_IF_NO_FILES: %s", fail_if_no_files)

        # ------------------------------------------------------------
        # Connect to OneLake
        # ------------------------------------------------------------
        credential = get_managed_identity_credential()

        onelake_service = OneLakeService(
            credential=credential,
            workspace_name=fabric_workspace_name,
            lakehouse_name=lakehouse_name
        )

        # ------------------------------------------------------------
        # Copy/move files with validations.
        # Directory creation is intentionally disabled in service code.
        # ------------------------------------------------------------
        result = onelake_service.copy_folder_files(
            source_folder=source_folder,
            target_folder=target_folder,
            file_pattern=file_pattern,
            expected_file_count=expected_file_count,
            move_after_copy=move_after_copy,
            recursive=recursive_copy,
            fail_if_no_files=fail_if_no_files
        )

        response = {
            "status": "success",
            "message": "OneLake weekly file movement completed successfully.",
            "processing_date": processing_date,
            "year": year,
            "month": month,
            "week_folder": week_folder,
            "source_folder": source_folder,
            "target_folder": target_folder,
            "result": result
        }

        logging.info("Function completed successfully: %s", json.dumps(response))

        return func.HttpResponse(
            json.dumps(response, indent=2),
            status_code=200,
            mimetype="application/json"
        )

    except Exception as ex:
        logging.exception("move-weekly-onelake-files failed.")

        response = {
            "status": "failed",
            "error_message": str(ex)
        }

        return func.HttpResponse(
            json.dumps(response, indent=2),
            status_code=500,
            mimetype="application/json"
        )
