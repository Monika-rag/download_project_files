import io
import logging
import posixpath

import paramiko
from azure.keyvault.secrets import SecretClient


class SftpService:
    """
    Service class responsible for SFTP operations.

    Currently kept separate and not called from function_app.py
    until OneLake-to-OneLake movement is tested successfully.
    """

    def __init__(self, credential, key_vault_url: str):
        self.credential = credential
        self.key_vault_url = key_vault_url

        self.secret_client = SecretClient(
            vault_url=self.key_vault_url,
            credential=self.credential
        )

        self.sftp_host = self.secret_client.get_secret("sftp-host").value
        self.sftp_port = int(self.secret_client.get_secret("sftp-port").value)
        self.sftp_username = self.secret_client.get_secret("sftp-username").value
        self.sftp_password = self.secret_client.get_secret("sftp-password").value

    def upload_bytes(
        self,
        file_content: bytes,
        target_folder: str,
        file_name: str
    ) -> None:
        """
        Uploads byte content to SFTP target folder.
        """

        transport = None
        sftp = None

        target_file_path = posixpath.join(target_folder, file_name)

        try:
            logging.info("Connecting to SFTP server: %s", self.sftp_host)

            transport = paramiko.Transport((self.sftp_host, self.sftp_port))
            transport.connect(
                username=self.sftp_username,
                password=self.sftp_password
            )

            sftp = paramiko.SFTPClient.from_transport(transport)

            logging.info("Uploading file to SFTP path: %s", target_file_path)

            with io.BytesIO(file_content) as file_stream:
                sftp.putfo(file_stream, target_file_path)

            logging.info("SFTP upload completed: %s", target_file_path)

        finally:
            if sftp:
                sftp.close()

            if transport:
                transport.close()

            logging.info("SFTP connection closed.")
