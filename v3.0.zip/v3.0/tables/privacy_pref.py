import pandas as pd
from utils import (
    setup_logger,
    fetch_records,
    select_columns_dataframe,
    export_to_csv,
    select_and_rename_columns,
)
from config import TABLES
from PowerPlatform.Dataverse.client import DataverseClient

# Setup Logger
logger = setup_logger(__name__, "logs/privacy_pref.log")

# Table name for file export
TABLE_NAME = "Privacypreferences"

# Constant default variables for columns
CONSENT_METHOD = 1

# Mapping of the default values and additional columns
DEFAULT_COLUMN_VALUES = {
    "Consent method": CONSENT_METHOD,
}
# Table columns
USER_CONSENT_COLUMNS = [
    "mmhci_userconsentid",
    "_mmhci_personid_value",
    "_mmhci_consentpurposeid_value",
    "statuscode",
    "mmhci_consentprovided",
    "statecode",
    "mmhci_consentmethod",
]
CONSENT_PURPOSE_COLUMNS = ["mmhci_consentpurposeid", "mmhci_name"]

# Key columns for merging
USER_CONSENT_KEY = "_mmhci_consentpurposeid_value"
CONSENT_PURPOSE_KEY = "mmhci_consentpurposeid"

# DOH Mapping Extraction logic
USER_CONSENT_STATUS_DOH_MAPPING = {
    1: 1,  # Consent Granted : Consent Granted
    100000000: 2,  # Consent Declined : Consent Declined
    2: 2,  # Consent Revoked : Consent Declined
}
USER_CONSENT_FLAG_DOH_MAPPING = {
    0: 1,  # Active : Current
    1: 2,  # Inactive : Not Current
}
CONSENT_PURPOSE_DOH_MAPPING = {
    "D0FA4878-5B14-F111-8341-000D3A794D28": 1,  # Privacy, collection notice and terms of use : Primacy Purposes
    "18C6DF82-5B14-F111-8341-000D3A794D28": 2,  # Clinical trials : Secondary purposes
    "523EDD88-5B14-F111-8341-000D3A794D28": 2,  # Research and independent evaluations : Secondary purposes
    "AE4D8E90-5B14-F111-8341-000D3A794D28": "Other",  # Other : ??
    "509B9D6E-5C14-F111-8341-000D3A794D28": 1,  # Gp & other providers : Primary Purposes
}

# Mapping of DataFrame columns in order and to their corresponding names for CSV output
FINAL_COLUMNS_MAPPING = {
    "mmhci_userconsentid": "Privacy preference key",
    "_mmhci_personid_value": "Client key",
    "_mmhci_consentpurposeid_value": "Consent purpose",
    "statuscode": "Consent status",
    "mmhci_consentprovided": "Consent timestamp",
    "statecode": "Current flag",
    "mmhci_consentmethod": "Consent method",
}


def process_privacy_preferences_table(client: DataverseClient) -> pd.DataFrame:
    """
    Process the Privacy Preference Table by combining data from multiple dependent tables.

    Parameters:
        Privacy Preference: Dataverse object for fetching data.

    Returns:
        pd.DataFrame: Processed Privacy Preferences Table.
    """
    # Step 1: Fetch data from dependent tables
    try:
        logger.info("Fetching data from dependent tables...")
        user_consent_records = fetch_records(client, TABLES["user_consent"])
        mmhci_consentpurpose = fetch_records(client, TABLES["consent_purpose"])
    except Exception as e:
        logger.exception(f"Error fetching data from tables: {e}.")
        raise

    # Step 2: Convert records to DataFrames for transformations
    try:
        logger.info("Converting records to DataFrames...")
        df_user_consent = pd.DataFrame(user_consent_records)
        df_consent_purpose = pd.DataFrame(mmhci_consentpurpose)
        logger.info("DataFrames created successfully")
    except Exception as e:
        logger.exception(f"Error converting records to DataFrame: {e}")
        raise

    # Step 3: Clean and select columns directly using utility functions
    try:
        logger.info("Cleaning and selecting columns...")
        df_user_consent_clean = select_columns_dataframe(
            df_user_consent, USER_CONSENT_COLUMNS
        )
        df_consentpurpose_clean = select_columns_dataframe(
            df_consent_purpose, CONSENT_PURPOSE_COLUMNS
        )
        logger.info("Columns cleaned and selected successfully.")
    except Exception as e:
        logger.exception(f"Error cleaning and selecting columns: {e}")
        raise

    # Step 4: Merge tables
    try:
        logger.info("Merging tables...")
        df_merged = df_user_consent_clean.merge(
            df_consentpurpose_clean,
            how="left",
            left_on=USER_CONSENT_KEY,
            right_on=CONSENT_PURPOSE_KEY,
        )
        logger.info("Tables merged successfully.")
    except Exception as e:
        logger.exception(f"Error merging tables: {e}")
        raise
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          
    # Step 5: Select columns to keep in the final table and rename
    df_merged = select_and_rename_columns(df_merged, FINAL_COLUMNS_MAPPING)

    # Step 6: Apply extraction logic
    try:
        logger.info("Applying transformations...")
        df_merged["Consent timestamp"] = pd.to_datetime(
            df_merged["Consent timestamp"], utc=True, errors="coerce"
        ).dt.strftime("%Y-%m-%d %H:%M:%S")
        df_merged[FINAL_COLUMNS_MAPPING["statuscode"]] = df_merged[
            FINAL_COLUMNS_MAPPING["statuscode"]
        ].map(USER_CONSENT_STATUS_DOH_MAPPING)
        df_merged[FINAL_COLUMNS_MAPPING["statecode"]] = df_merged[
            FINAL_COLUMNS_MAPPING["statecode"]
        ].map(USER_CONSENT_FLAG_DOH_MAPPING)
        df_merged[FINAL_COLUMNS_MAPPING["_mmhci_consentpurposeid_value"]] = (
            df_merged[FINAL_COLUMNS_MAPPING["_mmhci_consentpurposeid_value"]]
            .str.upper()
            .map(CONSENT_PURPOSE_DOH_MAPPING)
        )
        logger.info("Transformations applied successfully.")
    except Exception as e:
        logger.exception(f"Error applying transformations: {e}")
        raise

    df_merged = df_merged.assign(**DEFAULT_COLUMN_VALUES)
    df_merged = df_merged.drop_duplicates()

    return df_merged


def export_privacy_prefences_table(client: DataverseClient) -> None:
    """
    Process and export the Table to a CSV file with dynamic naming.

    Parameters:
        client: Dataverse client object for fetching data.

    Returns:
        None
    """
    try:
        logger.info("Starting Practitioner Preference export...")
        # Process the table
        df_client = process_privacy_preferences_table(client)
        # Export the DataFrame to a CSV file
        export_to_csv(df_client, table_name=TABLE_NAME)

        logger.info("Privacy Preferences exported successfully.")
    except Exception as e:
        logger.error(
            f"An error occurred while exporting the Privacy Preferences table: {e}"
        )
        raise
