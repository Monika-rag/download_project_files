import pandas as pd
from utils import (
    setup_logger,
    fetch_records,
    select_columns_dataframe,
    export_to_csv,
    select_and_rename_columns,
)
from config import TABLES, IAR_DST_DOMAINS, AGE_GROUP, ORGANISATION_ID

logger = setup_logger(__name__, "logs/iar_dst.log")
TABLE_NAME = "IARDSTassessment"


def process_iar_dst_table(client):
    """
    Process the Client Table by combining data from multiple dependent tables.

    Parameters:
        client: Dataverse client object for fetching data.

    Returns:
        pd.DataFrame: Processed Client Table.
    """
    # Fetch data from dependent tables
    logger.info("Fetching data from dependent tables...")
    incoming_referral_records = fetch_records(client, TABLES["incoming_referral"])
    questionnaire_response = fetch_records(client, TABLES["questionnaire_response"])
    questionnaire_response_item_answer = fetch_records(
        client, TABLES["questionnaire_response_item_answer"]
    )

    # Convert to DataFrames
    df_incoming_referral = pd.DataFrame(incoming_referral_records)
    df_questionnaire_response = pd.DataFrame(questionnaire_response)
    df_questionnaire_response_item_answer = pd.DataFrame(
        questionnaire_response_item_answer
    )
    
    # filter incoming_referral to active
    df_incoming_referral = df_incoming_referral[df_incoming_referral["statecode"]== 0] # 0: Active


    # Select columns
    df_incoming_referral_clean = select_columns_dataframe(
        df_incoming_referral,
        [
            "mmhci_incomingreferralid",
            "mmhci_intakekey",
            "mmhci_useofothermentalhealthservice",
            "mmhci_iardstrecommendedlevelofcare",
            "_mmhci_organisationid_value",
            "mmhci_iardstpractitionerlevelofcare",
        ],
    )
    df_questionnaire_response_clean = select_columns_dataframe(
        df_questionnaire_response,
        [
            "mmhci_responsedate",
            "_mmhci_incomingreferralid_value",
            "msemr_questionnaireresponseid",
            "mmhci_agegroup",
        ],
    )
    df_questionnaire_response_item_answer_clean = select_columns_dataframe(
        df_questionnaire_response_item_answer,
        [
            "msemr_valueinteger",
            "_mmhci_questionnaireresponse_value",
            "mmhci_measurekey",
        ],
    )

    df_questionnaire_response_clean["mmhci_responsedate"] = pd.to_datetime(
        df_questionnaire_response_clean["mmhci_responsedate"], errors="coerce"
    )

    df_questionnaire_response_item_answer_clean["msemr_valueinteger"] = (
        df_questionnaire_response_item_answer_clean["msemr_valueinteger"].astype(
            "Int64"
        )
    )

    # Get latest questionnaire response per incoming referral ---
    df_latest_response = df_questionnaire_response_clean.sort_values(
        ["_mmhci_incomingreferralid_value", "mmhci_responsedate"]
    ).drop_duplicates(subset=["_mmhci_incomingreferralid_value"], keep="last")

    # Pivot item answers into domain columns (one row per response id) ---
    domain_measurekeys = set(IAR_DST_DOMAINS.values())
    measurekey_to_domaincol = {
        v: k for k, v in IAR_DST_DOMAINS.items()
    }  # reverse mapping

    df_item = df_questionnaire_response_item_answer_clean[
        df_questionnaire_response_item_answer_clean["mmhci_measurekey"].isin(
            domain_measurekeys
        )
    ].copy()

    df_item["domain_col"] = df_item["mmhci_measurekey"].map(measurekey_to_domaincol)

    df_domains_wide = df_item.pivot_table(
        index="_mmhci_questionnaireresponse_value",
        columns="domain_col",
        values="msemr_valueinteger",
        aggfunc="first",  # if duplicates exist, take first non-null
    ).reset_index()

    # Merge referral + latest response + pivoted domains ---
    df_merged = df_incoming_referral_clean.merge(
        df_latest_response,
        how="left",
        left_on="mmhci_incomingreferralid",
        right_on="_mmhci_incomingreferralid_value",
    ).merge(
        df_domains_wide,
        how="left",
        left_on="msemr_questionnaireresponseid",
        right_on="_mmhci_questionnaireresponse_value",
    )

    # Drop rows where incoming referral id is missing because it's a PK
    df_merged = df_merged.dropna(subset=["mmhci_incomingreferralid"])

    # Ensure all domain columns exist else create them
    for col in IAR_DST_DOMAINS.keys():
        if col not in df_merged.columns:
            df_merged[col] = pd.NA

    # Merge tables
    # df_merged = df_incoming_referral_clean.merge(df_questionnaire_response_clean, how="left", left_on="mmhci_incomingreferralid", right_on="_mmhci_incomingreferralid_value")
    # df_merged = df_merged.merge(df_questionnaire_response_item_answer_clean, how="left", left_on="msemr_questionnaireresponseid", right_on="_mmhci_questionnaireresponse_value")
    # Drop rows from intake key column where value = null (intake key is primary key)
    # df_merged = df_merged.dropna(subset=["mmhci_incomingreferralid"])

    # convert to integer
    # df_merged["msemr_valueinteger"] = df_merged["msemr_valueinteger"].astype("Int64")

    # Select and rename columns
    # for column_name, value in IAR_DST_DOMAINS.items():
    #     df_merged[column_name] = np.where(df_merged["mmhci_measurekey"] == value, df_merged["msemr_valueinteger"], None)

    # sort by datetime then drop duplicates, keepong only first of each id
    # df_merged["mmhci_responsedate"] = pd.to_datetime(df_merged["mmhci_responsedate"])
    # df_merged = df_merged.sort_values(
    #     by=["mmhci_incomingreferralid", "mmhci_responsedate"],
    # )

    # default value: 1: Other phone services
    df_merged["mmhci_useofothermentalhealthservice"] = 1

    # drop duplicate intake keys
    df_merged = df_merged.drop_duplicates(
        subset="mmhci_incomingreferralid", keep="last"
    )

    # if iar derived/practitioner level of care is 9 then set to None.
    df_merged["mmhci_iardstpractitionerlevelofcare"] = df_merged[
        "mmhci_iardstpractitionerlevelofcare"
    ].replace(9, pd.NA)

    # age group extraction logic
    df_merged["mmhci_agegroup"] = df_merged["mmhci_agegroup"].map(AGE_GROUP)

    df_merged["_mmhci_organisationid_value"] = ORGANISATION_ID

    # date format conversion
    df_merged["mmhci_responsedate"] = pd.to_datetime(
        df_merged["mmhci_responsedate"]
    ).dt.strftime("%Y-%m-%d")

    # Constant default variables for columns
    IAR_DST_PRACTITIONER_OVERRIDE_LEVEL_OF_CARE = None  # Default to blank

    # Mapping of the default values and additional columns
    DEFAULT_COLUMN_VALUES = {
        "IAR-DST - Practitioner override level of care": IAR_DST_PRACTITIONER_OVERRIDE_LEVEL_OF_CARE,
    }

    # TODO: derived level of care either practitioner level of care else recommended level of care else blank

    df_merged["mmhci_agegroup"] = df_merged["mmhci_agegroup"].astype("Int64")
    df_merged["IAR-DST - Domain 1"] = df_merged["IAR-DST - Domain 1"].astype("Int64")
    df_merged["IAR-DST - Domain 2"] = df_merged["IAR-DST - Domain 2"].astype("Int64")
    df_merged["IAR-DST - Domain 3"] = df_merged["IAR-DST - Domain 3"].astype("Int64")
    df_merged["IAR-DST - Domain 4"] = df_merged["IAR-DST - Domain 4"].astype("Int64")
    df_merged["IAR-DST - Domain 5"] = df_merged["IAR-DST - Domain 5"].astype("Int64")
    df_merged["IAR-DST - Domain 6"] = df_merged["IAR-DST - Domain 6"].astype("Int64")
    df_merged["IAR-DST - Domain 7"] = df_merged["IAR-DST - Domain 7"].astype("Int64")
    df_merged["IAR-DST - Domain 8"] = df_merged["IAR-DST - Domain 8"].astype("Int64")

    df_merged = df_merged.assign(**DEFAULT_COLUMN_VALUES)

    # use iardst recommended level of care if practitioner level of care is blank , else blank
    df_merged["mmhci_iardstpractitionerlevelofcare"] = (
        df_merged["mmhci_iardstpractitionerlevelofcare"]
        .replace("", pd.NA)
        .combine_first(df_merged["mmhci_iardstrecommendedlevelofcare"])
    )

    # derived level of care = practiitoner level of care else recommended level of care
    df_merged["derived_level_of_care"] = (
        df_merged["mmhci_iardstpractitionerlevelofcare"]
        .astype("string")
        .str.strip()
        .replace("", pd.NA)
        .combine_first(df_merged["mmhci_iardstrecommendedlevelofcare"])
    )

    columns_mapping = {
        "mmhci_incomingreferralid": "Intake key",
        "_mmhci_organisationid_value": "Service provider organisation key",
        "mmhci_useofothermentalhealthservice": "Assessment provider",
        "mmhci_responsedate": "Assessment date",
        "mmhci_agegroup": "IAR-DST - Version",
        "IAR-DST - Domain 1": "IAR-DST - Domain 1",
        "IAR-DST - Domain 2": "IAR-DST - Domain 2",
        "IAR-DST - Domain 3": "IAR-DST - Domain 3",
        "IAR-DST - Domain 4": "IAR-DST - Domain 4",
        "IAR-DST - Domain 5": "IAR-DST - Domain 5",
        "IAR-DST - Domain 6": "IAR-DST - Domain 6",
        "IAR-DST - Domain 7": "IAR-DST - Domain 7",
        "IAR-DST - Domain 8": "IAR-DST - Domain 8",
        "mmhci_iardstrecommendedlevelofcare": "IAR-DST - Recommended level of care",
        "mmhci_iardstpractitionerlevelofcare": "IAR-DST - Practitioner override level of care",
        "derived_level_of_care": "IAR-DST - Derived level of care",
    }
    df_merged = select_and_rename_columns(df_merged, columns_mapping)
    df_merged["Assessment date"] = df_merged["Assessment date"].fillna("")

    return df_merged


def export_iar_dst_table(client):
    """
    Process and export the Client Table to a CSV file.

    Parameters:
        client: Dataverse client object for fetching data.

    Returns:
        None
    """
    try:
        logger.info("Starting client table export...")

        df_intake = process_iar_dst_table(client)
        export_to_csv(df_intake, table_name=TABLE_NAME)
        logger.info("Client table exported successfully.")
    except Exception as e:
        logger.error(f"An error occurred while exporting the client table: {e}")
        raise  # Re-raise the exception after logger its
