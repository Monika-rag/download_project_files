import pandas as pd
from utils import (
    setup_logger,
    fetch_records,
    select_columns_dataframe,
    export_to_csv,
    select_and_rename_columns,
)
from config import TABLES, APPOINTMENT_TYPE, ORGANISATION_ID
from PowerPlatform.Dataverse.client import DataverseClient

# TODO: fix service contact being blown out (careplanactivityid)
# Setup logger
logger = setup_logger(__name__, "logs/service_contact.log")

# Table name for file export
TABLE_NAME = "Servicecontact"

# Constant default variables
TYPE_DEFAULT = 1
MODALITY = 4
DURATION_DEFAULT = 45
START_TIMESTAMP_DEFAULT = None
COMPLETION_TIMESTAMP_DEFAULT = None
COMPLETION_STATUS_DEFAULT = None
FEEDBACK_RATING_DEFAULT = None
FINAL_SERVICE_CONTACT_OF_LICBT_COURSE_DEFAULT = 3

# Table columns
CARE_PLAN_COLUMNS = [
    "msemr_careplanid",
    "_msemr_careplantemplate_value",
    "_msemr_ve_episodeofcare_value",
    "mmhci_drupal_program_id"
]
CARE_PLAN_ACTIVITY_COLUMNS = [
    "msemr_careplanactivityid",
    "_msemr_careplan_value",
    "msemr_activitystartdate",
    "mmhci_appointmentendtime",
    "msemr_activitydefinitiontype",
    "statuscode",
    "_msemr_careplanactivity_value",
]
# Rename columns as pd will automatically rename duplicate columns when merging
CARE_PLAN_ACTIVITY_COPY_COLUMNS = {
    "msemr_careplanactivityid": "msemr_careplanactivityid_copy",
    "_msemr_careplan_value": "_msemr_careplan_value_copy",
    "msemr_activitystartdate": "mmhci_activitystartdate_copy",
    "mmhci_appointmentendtime": "mmhci_appointmentendtime_copy",
    "msemr_activitydefinitiontype": "msemr_activitydefinitiontype_copy",
    "_msemr_careplanactivity_value": "_msemr_careplanactivity_value_copy",
}
CARE_PLAN_TEMPLATE_COLUMNS = ["msemr_careplantemplateid", "msemr_careplanidentifier", "mmhci_drupal_program_id"]
EPISODE_OF_CARE_COLUMNS = [
    "_msemr_organization_value",
    "msemr_episodeofcareid",
    "_mmhci_primarypractitioner_value",
]
BOOKABLE_RESOURCE_COLUMNS = ["bookableresourceid"]

DEFAULT_COLUMN_VALUES = {
    "Type": TYPE_DEFAULT,
    "Modality": MODALITY,
    "Duration": DURATION_DEFAULT,
    "Start timestamp": START_TIMESTAMP_DEFAULT,
    "Completion timestamp": COMPLETION_TIMESTAMP_DEFAULT,
    "Completion status": COMPLETION_STATUS_DEFAULT,
    "Feedback rating": FEEDBACK_RATING_DEFAULT,
    "Final service contact of LiCBT course": FINAL_SERVICE_CONTACT_OF_LICBT_COURSE_DEFAULT,
}

# Key columns for merging


def process_service_contact(client: DataverseClient) -> pd.DataFrame:
    """
    Process the Service Contact by combining data from multiple dependent tables.

    Parameters:
        client: Dataverse client object for fetching data.

    Returns:
        pd.DataFrame: Processed Service Contact.
    """
    # Step 1: Fetch data from dependent tables
    try:
        logger.info("Fetching data from dependent tables...")
        care_plan_activity_records = fetch_records(client, TABLES["care_plan_activity"])
        care_plan_records = fetch_records(client, TABLES["care_plan"])
        care_plan_template_records = fetch_records(client, TABLES["care_plan_template"])
        episode_of_care_records = fetch_records(client, TABLES["episode_of_care"])
        bookable_resource_records = fetch_records(client, TABLES["bookable_resource"])
        logger.info("Data fectched successfully from dependent tables.")
    except Exception as e:
        logger.exception(f"exception fetching data from tables: {e}")
        raise

    # Step 2: Convert records to DataFrames for transformations
    try:
        logger.info("Converting records to DataFrames...")
        df_care_plan = pd.DataFrame(care_plan_records)
        df_care_plan_activity = pd.DataFrame(care_plan_activity_records)
        df_care_plan_template = pd.DataFrame(care_plan_template_records)
        df_care_plan_activity_copy = pd.DataFrame(care_plan_activity_records)
        df_episode_of_care = pd.DataFrame(episode_of_care_records)
        df_bookable_resource = pd.DataFrame(bookable_resource_records)
        logger.info("DataFrames created successfully")
        # print(list(df_care_plan_activity.columns))
        # print("Care plan template ids count: ", df_care_plan["_msemr_careplantemplate_value"].notna().sum())
        # print("Care plan template id values: ", df_care_plan["_msemr_careplantemplate_value"].value_counts(dropna=True))
    except Exception as e:
        logger.exception(f"exception converting records to DataFrame: {e}")
        raise

    # Step 3: Clean and select columns directly using utility functions
    try:
        logger.info("Cleaning and selecting columns...")
        df_care_plan_clean = select_columns_dataframe(df_care_plan, CARE_PLAN_COLUMNS)
        df_care_plan_activity_clean = select_columns_dataframe(
            df_care_plan_activity, CARE_PLAN_ACTIVITY_COLUMNS
        )
        df_care_plan_activity_copy_clean = select_and_rename_columns(
            df_care_plan_activity_copy, CARE_PLAN_ACTIVITY_COPY_COLUMNS
        )
        # df_care_plan_template_clean = select_columns_dataframe(df_care_plan_template, CARE_PLAN_TEMPLATE_COLUMNS)
        df_episode_of_care_clean = select_columns_dataframe(
            df_episode_of_care, EPISODE_OF_CARE_COLUMNS
        )
        df_bookable_resource_clean = select_columns_dataframe(
            df_bookable_resource, BOOKABLE_RESOURCE_COLUMNS
        )
        df_care_plan_template_clean = select_columns_dataframe(
            df_care_plan_template, CARE_PLAN_TEMPLATE_COLUMNS
        )
        logger.info("Columns cleaned and selected successfully.")
    except Exception as e:
        logger.exception(f"exception cleaning and selecting columns: {e}")
        raise

    # Step 4: Filter out the care plan activity copy table to contain rows where definition type is equal to Module only before merging
    df_care_plan_activity_copy_clean["msemr_activitydefinitiontype_copy"] = (
        df_care_plan_activity_copy_clean["msemr_activitydefinitiontype_copy"].map(
            APPOINTMENT_TYPE
        )
    )
    df_care_plan_activity_copy_clean = df_care_plan_activity_copy_clean[
        df_care_plan_activity_copy_clean["msemr_activitydefinitiontype_copy"]
        == "Module"
    ]

    # Step 4: Merge tables
    try:
        logger.info("Merging tables...")
        # df_merged = df_care_plan_activity.merge(df_care_plan_clean, how="left", left_on="_msemr_careplan_value", right_on="msemr_careplanid")
        # df_merged = df_care_plan_activity_clean.merge(df_care_plan_activity_copy_clean, how="left", left_on="_msemr_careplan_value", right_on="_msemr_careplan_value_copy")
        df_merged = df_care_plan_activity_clean.merge(
            df_care_plan_clean,
            how="left",
            left_on="_msemr_careplan_value",
            right_on="msemr_careplanid",
        )
        df_merged = df_merged.merge(
            df_care_plan_template_clean,
            how="left",
            on="mmhci_drupal_program_id"
        )
        # df_merged =  df_merged.merge(df_care_plan_template_clean, how="left", left_on="_msemr_careplantemplate_value", right_on="msemr_careplantemplateid")
        df_merged = df_merged.merge(
            df_episode_of_care_clean,
            how="left",
            left_on="_msemr_ve_episodeofcare_value",
            right_on="msemr_episodeofcareid",
        )
        df_merged = df_merged.merge(
            df_bookable_resource_clean,
            how="left",
            left_on="_mmhci_primarypractitioner_value",
            right_on="bookableresourceid",
        )
        logger.info("Tables merged successfully.")
    except Exception as e:
        logger.exception(f"exception merging tables: {e}")
        raise

    # Step 5: Apply transformations and extraction logic to birthdate, CALD status and request for accessibility service
    try:
        logger.info("Applying transformations...")
        # Logic to filter the table to msemr_careplanactivityid where mmhci_activitydefinitiontype is equals to Module. This is the primary key
        df_merged["msemr_activitydefinitiontype"] = df_merged[
            "msemr_activitydefinitiontype"
        ].map(APPOINTMENT_TYPE)
        df_merged = df_merged[df_merged["msemr_activitydefinitiontype"] == "Module"]
        # df_merged["Duration"] = pd.to_datetime(df_merged["mmhci_appointmentendtime"]) - pd.to_datetime(df_merged["msemr_activitystartdate"])
        df_merged["msemr_activitystartdate"] = pd.to_datetime(
            df_merged["msemr_activitystartdate"]
        ).dt.strftime("%Y-%m-%d")
        df_merged = df_merged.assign(**DEFAULT_COLUMN_VALUES)
        logger.info("Transformations applied successfully.")
    except Exception as e:
        logger.exception(f"exception applying transformations: {e}")
        raise

    # Step 5: Apply transformations and extraction logic to birthdate, CALD status and request for accessibility service
    try:
        logger.info("Applying transformations...")

        # df_merged["Duration"] = pd.to_datetime(df_merged["mmhci_appointmentendtime"]) - pd.to_datetime(df_merged["msemr_activitystartdate"])
        df_merged["msemr_activitystartdate"] = pd.to_datetime(
            df_merged["msemr_activitystartdate"]
        ).dt.strftime("%Y-%m-%d")

        df_merged = df_merged.assign(**DEFAULT_COLUMN_VALUES)
        logger.info("Transformations applied successfully.")
    except Exception as e:
        logger.exception(f"exception applying transformations: {e}")
        raise

    # Service provider key
    df_merged["_msemr_organization_value"] = ORGANISATION_ID
    df_merged["Accessibility service"] = None
    df_merged["Completion status"] = None
    df_merged["Venue"] = None

    # Step 6: Select columns to keep in the final table and rename
    columns_mapping = {
        "msemr_careplanactivityid": "Service contact key",
        "_msemr_organization_value": "Service provider organisation key",
        "_msemr_careplan_value": "Course of LiCBT key",
        "bookableresourceid": "Practitioner key",
        "msemr_activitystartdate": "Date",
        "Type": "Type",
        "Modality": "Modality",
        "Venue": "Venue",
        "Duration": "Duration",
        "statuscode": "Client participation indicator",
        "Accessibility service": "Accessibility service",
        "msemr_careplantemplateid": "Workbook ID",
        "_msemr_careplanactivity_value": "Module ID",
        "Start timestamp": "Start timestamp",
        "Completion timestamp": "Completion timestamp",
        "Completion status": "Completion status",
        "Feedback rating": "Feedback rating",
        "Final service contact of LiCBT course": "Final service contact of LiCBT course",
    }

    df_merged = select_and_rename_columns(df_merged, columns_mapping)
    df_merged = df_merged.drop_duplicates()

    return df_merged


def export_service_contact(client):
    """
    Process and export the Table to a CSV file with dynamic naming.

    Parameters:
        client: Dataverse client object for fetching data.

    Returns:
        None
    """
    try:
        logger.info("Starting Service Contact export...")
        # Process the table
        df_client = process_service_contact(client)

        # Export the DataFrame to a CSV file
        export_to_csv(df_client, table_name=TABLE_NAME)

        logger.info("Service Contact exported successfully.")
    except Exception as e:
        logger.error(
            f"An exception occurred while exporting the Service Contact table: {e}"
        )
        raise
