import pandas as pd
from utils import setup_logger, fetch_records, export_to_csv, select_and_rename_columns, find_matching_column_across_dataframes
from config import TABLES

logger = setup_logger(__name__, "logs/outcomes.log")

TABLE_NAME = "Outcomes"

GAD_7_ANXIETY = [
    "Feeling nervous, anxious, or on edge",
    "Not being able to stop or control worrying",
    "Worrying too much about different things",
    "Trouble relaxing",
    "Being so restless that it's hard to sit still",
    "Becoming easily annoyed or irritable",
    "Feeling afraid as if something awful might happen",
]

PHQ_9_DEPRESSION = [
    "Little interest or pleasure in doing things?",
    "Feeling down, depressed, or hopeless?",
    "Trouble falling or staying asleep, or sleeping too much?",
    "Feeling tired or having little energy?",
    "Poor appetite or overeating?",
    "Feeling bad about yourself – or that you are a failure or have let yourself or your family down?",
    "Trouble concentrating on things, such as reading the newspaper or watching television?",
    "Moving or speaking so slowly that other people could have noticed? Or so fidgety or restless that you have been moving a lot more than usual?",
    "Thoughts that you would be better off dead, or thoughts of hurting yourself in some way?"
]

IAR_DST = [
    "domain1",
    "domain2",
    "domain3",
    "domain4",
    "domain5",
    "domain6",
    "domain7",
    "domain8"
]

OUTPUT_MEASURE = {
    "K10" : 1,
    "GAD-7" : 2,
    "GAD-7 Anxiety": 2,
    "PHQ-9" : 3,
    "PHQ-9 Depression" : 3,
    "IAR-DST" : 4,
    "Mood check" : 5
}

QUESTION_ORDER_MAP = {
    "GAD-7": {q: i + 1 for i, q in enumerate(GAD_7_ANXIETY)},
    "PHQ-9": {q: i + 1 for i, q in enumerate(PHQ_9_DEPRESSION)},
    "IAR-DST": {q: i + 1 for i, q in enumerate(IAR_DST)},
}

MEASURE_CANONICAL = {
    "GAD-7 Anxiety": "GAD-7",
    "PHQ-9 Depression": "PHQ-9",
    "IAR-DST": "IAR-DST",
    "K10": "K10",
    "Mood check": "Mood check",
}

REASON_FOR_COLLECTION_MAPPING = {
    4 : 1, # IAR-DST : Pre appointment
    1 : 2, # K10 : During LiCBT course
    2 : 2, # GAD-7 : During LiCBT course
    3 : 2, # PHQ-9: During LiCBT
}

# Configure logger
def process_outcomes(client):
    """
    Process the Client Table by combining data from multiple dependent tables.

    Parameters:
        client: Dataverse client object for fetching data.

    Returns:
        pd.DataFrame: Processed Client Table.
    """
    # Step 1: Fetch data from dependent tables
    try:
        logger.info("Fetching data from dependent tables...")
        incoming_referral_records = fetch_records(client, TABLES["incoming_referral"])
        care_plan_records = fetch_records(client, TABLES["care_plan"])
        episode_of_care_records = fetch_records(client, TABLES["episode_of_care"])
        questionnaire_response = fetch_records(client, TABLES["questionnaire_response"])
        questionnaire = fetch_records(client, TABLES["questionnaire"])
        questionnaireresponseitem=fetch_records(client,TABLES["questionnaire_response_item"])
        care_plan_activity_records = fetch_records(client, TABLES["care_plan_activity"])
        contact_records = fetch_records(client, TABLES["contact"])

        questionnaireresponseitemanswer = fetch_records(
            client, TABLES["questionnaire_response_item_answer"]
        )

        logger.info("Data fectched successfully from dependent tables.")
    except Exception as e:
        logger.exception(f"Error fetching data from tables: {e}")
        raise

    # Step 2: Convert records to DataFrames for transformations
    try:
        logger.info("Converting records to DataFrames...")
        df_incoming_referral = pd.DataFrame(incoming_referral_records)
        df_episode_of_care = pd.DataFrame(episode_of_care_records)
        df_care_plan = pd.DataFrame(care_plan_records)
        # print('[c for c in df_care_plan.columns if "episode" in c.lower()]')
        # print([c for c in df_care_plan.columns if "episode" in c.lower()])
        df_questionnaire_response = pd.DataFrame(questionnaire_response)
        df_care_plan_activity = pd.DataFrame(care_plan_activity_records)
        df_questionnaireresponseitemanswer = pd.DataFrame(
            questionnaireresponseitemanswer
        )
        df_questionnaire = pd.DataFrame(questionnaire)
        df_questionnaire_response_item = pd.DataFrame(questionnaireresponseitem)
        df_contact = pd.DataFrame(contact_records)
        # print(list(df_care_plan.columns))
        # print(list(df_care_plan.columns))

        logger.info("DataFrames created successfully")
    except Exception as e:
        logger.exception(f"Error converting records to DataFrame: {e}")
        raise

    # Step 3: Clean and select columns directly using utility functions
    try:
        logger.info("Cleaning and selecting columns...")
        df_incoming_referral_clean = select_and_rename_columns(
            df_incoming_referral,
            {
                "mmhci_incomingreferralid": "mmhci_incomingreferralid",
                "_mmhci_personid_value": "_mmhci_personid_value",
                "statecode" : "incoming_referral_state_code" #inactive/active column
            },
        )
        df_episode_of_care_clean = select_and_rename_columns(
            df_episode_of_care,
            {
                "statuscode": "statuscode",
                "_mmhci_incomingreferral_value": "mmhci_incomingreferralid",
                "_msemr_organization_value": "Service provider organisation key",
                "msemr_episodeofcareid": "msemr_episodeofcareid",
            },
        )
        df_care_plan_clean = select_and_rename_columns(
            df_care_plan,
            {
                "msemr_careplanid": "Course of LICBT Key",
                "_msemr_ve_episodeofcare_value": "_msemr_episodeofcare_value",
                "statuscode" : "statuscode",
                "createdon" : "createdon"
            },
        )
        df_questionnaire_response_item_clean = select_and_rename_columns(
            df_questionnaire_response_item,
            {
                "msemr_name" : "questionnaire_response_item_question",
                "msemr_questionnaireresponseitemid" : "msemr_questionnaireresponseitemid"
            }
        )
        df_care_plan_activity_clean = select_and_rename_columns(
            df_care_plan_activity, 
            {
                "msemr_careplanactivityid" : "Service contact key",
                "_msemr_careplan_value" : "_msemr_careplan_value",
            }
        )
        df_contact_clean = select_and_rename_columns(
            df_contact,
            {
                "contactid" : "Client key"
            }
        )

        logger.info("Columns cleaned and selected successfully.")
    except Exception as e:
        logger.exception(f"Error cleaning and selecting columns: {e}")
        raise

    # Step 4: Merge tables
    try:
        logger.info("Merging tables...")

        matching_columns = find_matching_column_across_dataframes(df_episode_of_care_clean, df_incoming_referral_clean, "mmhci_incomingreferralid")
        # print(matching_columns)
        df_base = df_incoming_referral_clean.merge(
            df_episode_of_care_clean, how="left", on="mmhci_incomingreferralid"
        )

        # right merge on contact here
        df_base = df_base.merge(
            df_contact_clean,
            how="right",
            left_on="_mmhci_personid_value",
            right_on="Client key"
        )

        # Sort based on status (inactive/active) and sort by createdon and grab lastest (last)
        # df_care_plan_clean = df_care_plan_clean.drop_duplicates(
        #     subset=["_msemr_episodeofcare_value"], keep="first"
        # )
        # Drop care plans that are not active
        # df_care_plan_clean = df_care_plan_clean[df_care_plan_clean["statuscode"] != 1]

        # Sort care plan based on createdon - grab latest (last)
        df_care_plan_clean = df_care_plan_clean.sort_values(
            ["_msemr_episodeofcare_value", "createdon"],
            ascending=[True, False]
        ).drop_duplicates(subset=["_msemr_episodeofcare_value"], keep="first")

        df_care_plan_clean = df_care_plan_clean.dropna(
            subset=["_msemr_episodeofcare_value"]
        )        

        df_base = df_base.merge(
            df_care_plan_clean,
            how="left",
            left_on="msemr_episodeofcareid",
            right_on="_msemr_episodeofcare_value",
            validate="many_to_one",
        )

        # merge with care plan activity to retrieve careplanactivityid for service contact key
        df_base = df_base.merge(
            df_care_plan_activity_clean,
            how="left",
            left_on= "Course of LICBT Key",
            right_on= "_msemr_careplan_value"
        )

        # Sort by creaton, drop incomingreferralid...
        # df_base = df_base.drop_duplicates(
        #     subset=["mmhci_incomingreferralid"], keep="first"
        # )
        df_base = df_base.sort_values(
            ["mmhci_incomingreferralid", "createdon"],
            ascending=[True, False]
        ).drop_duplicates(subset=["mmhci_incomingreferralid"], keep="first")

        # Only completed questionnnaire should be used here
        df_questionnaire_response = df_questionnaire_response[
            df_questionnaire_response["statuscode"] == 1 # Completed?
        ]

        df_qr = df_questionnaire_response.merge(
            df_questionnaire,
            left_on="_msemr_questionnaire_value",
            right_on="msemr_questionnaireid",
            how="left",
        )
        df_qr = df_questionnaire_response[
            [
                "msemr_questionnaireresponseid",
                "_mmhci_incomingreferralid_value",
                "mmhci_responsedate",
                "mmhci_totalscore",
                "msemr_name",
                "_msemr_questionnaire_value",
            ]
        ].rename(
            columns={
                "msemr_questionnaireresponseid": "questionnaireresponseid",
                "_mmhci_incomingreferralid_value": "mmhci_incomingreferralid",
                "mmhci_responsedate": "Date",
                "mmhci_totalscore": "Outcome score",
                "msemr_name": "Outcome measure type",
            }
        )

        df_qr = df_qr.merge(
            df_questionnaire,
            left_on="_msemr_questionnaire_value",
            right_on="msemr_questionnaireid",
            how="left",
        )

        # TODO: Crosscheck this step
        # df_base = df_base.drop_duplicates(
        #     subset=["mmhci_incomingreferralid"], keep="first"
        # )

        df_base = df_qr.merge(df_base, how="left", on="mmhci_incomingreferralid")
        # ------------this is needed to get measure key for question level-------------------
        # msemr_questionnairename
        # ---------- Answer-level: build Outcome response and pivot into columns ----------
        # print(df_questionnaireresponseitemanswer.head)
        # return df_questionnaireresponseitemanswer
        df_outcome_answers = df_questionnaireresponseitemanswer[
            [
                "_mmhci_questionnaireresponse_value",
                "_msemr_questionnaireresponseitem_value", #Question text id
                # "_msemr_questionnaireresponseitemname", #Question text
                "msemr_name",
                "mmhci_measurekey",
                "msemr_valueinteger",
                "msemr_valuedecimal",
                "msemr_valuestring",
            ]
        ].rename(
            columns={"_mmhci_questionnaireresponse_value": "questionnaireresponseid"}
        )

        # Need to merge on df_outcome answers with questionnaire reseponse item
        df_outcome_answers = df_outcome_answers.merge(
            df_questionnaire_response_item_clean,
            how="left",
            left_on="_msemr_questionnaireresponseitem_value",
            right_on="msemr_questionnaireresponseitemid"
        )

        df_outcome_answers = df_outcome_answers[
            [
                "questionnaireresponseid",
                "_msemr_questionnaireresponseitem_value", #Question text?
                # "_msemr_questionnaireresponseitemname", #Question text
                "questionnaire_response_item_question",
                "msemr_name",
                "mmhci_measurekey",
                "msemr_valueinteger",
                "msemr_valuedecimal",
                "msemr_valuestring",
            ]
        ].rename(
            columns={
                     "questionnaire_response_item_question": "question_text" # question text
                     }
        )
        # One response value column (integer/decimal/string)
        df_outcome_answers["Outcome response"] = (
            df_outcome_answers["msemr_valueinteger"]
            .combine_first(df_outcome_answers["msemr_valuedecimal"])
            .combine_first(df_outcome_answers["msemr_valuestring"])
        )

        # Join for reordering of questions
        df_qr["Outcome measure type"] = df_qr["Outcome measure type"].astype(str).str.strip()
        df_qr["Outcome measure type"] = df_qr["Outcome measure type"].map(MEASURE_CANONICAL).fillna(df_qr["Outcome measure type"])
        df_outcome_answers = df_outcome_answers.merge(
            df_qr[["questionnaireresponseid", "Outcome measure type"]],
            on="questionnaireresponseid",
            how="left",
        )

        def map_question_order(row):
            return QUESTION_ORDER_MAP.get(
                row["Outcome measure type"], {}
            ).get(row["question_text"])
            
        df_outcome_answers["question_order"] = df_outcome_answers.apply(
            map_question_order, axis=1
        )


        mapped_measures = set(QUESTION_ORDER_MAP.keys())
        mask_mapped = df_outcome_answers["Outcome measure type"].isin(mapped_measures)

        if df_outcome_answers.loc[mask_mapped, "question_order"].isna().any():
            unmapped = df_outcome_answers.loc[
                mask_mapped & df_outcome_answers["question_order"].isna(),
                ["Outcome measure type", "question_text"]
            ].drop_duplicates()

            # raise ValueError(f"Unmapped questionnaire questions detected:\n{unmapped}")

        # for debugging
        df_outcome_answers["question_with_answer"] = (
            "Q"
            + df_outcome_answers["question_order"].astype("Int64").astype(str)
            + ". "
            + df_outcome_answers["question_text"].astype(str)
            + " → "
            + df_outcome_answers["Outcome response"].astype(str)
        )

        # Build a readable answer for debugging
        df_outcome_answers["Outcome response display"] = (
            df_outcome_answers["Outcome response"].astype(str)
            + " ("
            + df_outcome_answers["msemr_name"].astype(str)  # answer label text
            + ")"
        )


        # Pivot key WITHOUT measurekey (because measurekey is null)
        df_outcome_answers["pivot_question"] = df_outcome_answers[
            "msemr_name"
        ].combine_first(df_outcome_answers["_msemr_questionnaireresponseitem_value"])
        
        before = len(df_outcome_answers)
        df_outcome_answers = df_outcome_answers.dropna(subset=["question_order"])
        after = len(df_outcome_answers)
        logger.info(f"Dropped {before-after} rows due to missing question_order (remaining {after}).")

        df_outcome_answers = df_outcome_answers.drop_duplicates(
            subset=["questionnaireresponseid", "question_order"]
        )
        
        df_outcome_pivot = (
            df_outcome_answers
            .pivot_table(
                index="questionnaireresponseid",
                columns="question_order",
                values="Outcome response",
                aggfunc="first",
            )
            .reset_index()
        )

        df_outcome_answers = df_outcome_answers.dropna(subset=["question_order"]).copy()
        df_outcome_answers["question_order"] = df_outcome_answers["question_order"].astype(int)
        rename_cols = {}
        for c in df_outcome_pivot.columns:
            if c == "questionnaireresponseid":
                continue
            try:
                q = int(float(c))  # handles 1, 1.0, np.int64, "1", "1.0"
                rename_cols[c] = f"Outcome measure question {q} response"
            except (TypeError, ValueError):
                # leave non-numeric columns untouched
                pass

        df_outcome_pivot = df_outcome_pivot.rename(columns=rename_cols)
        # print("Pivot columns after rename:", df_outcome_pivot.columns.tolist()[:20])
        # print("Non-null pivot cells:", df_outcome_pivot.drop(columns=["questionnaireresponseid"], errors="ignore").notna().sum().sum())

        df_outcome_pivot.columns.name = None

        # ---------- Final report = base + pivoted answers ----------
        df_report = df_base.merge(
            df_outcome_pivot, how="left", on="questionnaireresponseid"
        )
        df_report["Service provider organisation key"] = "SVHA-MMHCI-01"

        logger.info("Tables merged successfully.")
    except Exception as e:
        logger.exception(f"Error merging tables: {e}")
        raise

    df_report["Measure key"] = df_report["questionnaireresponseid"]

    df_report = df_report.rename(
        columns={
            "Course of LICBT Key": "Course of LiCBT key",
            "Outcome score": "Outcome measure score",
            "msemr_name": "Outcome measure type",
        }
    ) 

    # filter incoming_referral to active
    df_report = df_report[df_report["incoming_referral_state_code"]== 0] # 0: Active

    # print(df_outcome_answers["Outcome measure type"].value_counts().head(10))
    # print(df_outcome_answers["question_order"].notna().sum(), "mapped out of", len(df_outcome_answers))
    final_columns = [
        "Measure key",
        "Service provider organisation key",
        "Course of LiCBT key",
        "Client key",
        "Service contact key",
        "Date",
        "Reason for collection",
        "Outcome measure type",
        "Outcome measure question 1 response",
        "Outcome measure question 2 response",
        "Outcome measure question 3 response",
        "Outcome measure question 4 response",
        "Outcome measure question 5 response",
        "Outcome measure question 6 response",
        "Outcome measure question 7 response",
        "Outcome measure question 8 response",
        "Outcome measure question 9 response",
        "Outcome measure question 10 response",
        "Outcome measure score",
    ]

    # keep only columns that actually exist (prevents KeyError)
    df_report = df_report.loc[:, ~df_report.columns.duplicated()]
    df_report = df_report.loc[:, ~df_report.columns.duplicated()]
    df_report = df_report.reindex(columns=final_columns)  # missing columns created with NaN

    # mapping outcome measuretype numeric values

    df_report["Outcome measure type"] = (
        df_report["Outcome measure type"].astype(str).str.strip()
    )

    df_report["Outcome measure type"] = (
        df_report["Outcome measure type"]
        .str.extract(r"(K10|GAD-7 Anxiety|PHQ-9 Depression|IAR-DST|Mood check)", expand=False)
        .fillna(df_report["Outcome measure type"])
    )

    s = df_report["Outcome measure type"].astype("string").str.strip()
    df_report["Outcome measure type"] = (
        pd.to_numeric(s.map(OUTPUT_MEASURE), errors="coerce").astype("Int64")
    )

    # Step 5: Apply transformations and extraction logic to birthdate, CALD status and request for accessibility service
    try:
        logger.info("Applying transformations...")
        # if "msemr_planenddate" in df_merged.columns:
        #     df_merged["msemr_planenddate"] = pd.to_datetime(df_merged["msemr_planenddate"]).dt.strftime('%Y-%m-%d')

        logger.info("Transformations applied successfully.")
    except Exception as e:
        logger.exception(f"Error applying transformations: {e}")
        raise

    # Changing date format to yyyy-mm-dd
    if "Date" in df_report.columns:
        df_report["Date"] = pd.to_datetime(df_report["Date"]).dt.strftime("%Y-%m-%d")

    df_report["Outcome measure question 1 response"] = df_report[
        "Outcome measure question 1 response"
    ].astype("Int64")
    df_report["Outcome measure question 2 response"] = df_report[
        "Outcome measure question 2 response"
    ].astype("Int64")
    df_report["Outcome measure question 3 response"] = df_report[
        "Outcome measure question 3 response"
    ].astype("Int64")
    df_report["Outcome measure question 4 response"] = df_report[
        "Outcome measure question 4 response"
    ].astype("Int64")
    df_report["Outcome measure question 5 response"] = df_report[
        "Outcome measure question 5 response"
    ].astype("Int64")
    df_report["Outcome measure question 6 response"] = df_report[
        "Outcome measure question 6 response"
    ].astype("Int64")
    df_report["Outcome measure question 7 response"] = df_report[
        "Outcome measure question 7 response"
    ].astype("Int64")
    df_report["Outcome measure question 8 response"] = df_report[
        "Outcome measure question 8 response"
    ].astype("Int64")
    df_report["Outcome measure question 9 response"] = df_report[
        "Outcome measure question 9 response"
    ].astype("Int64")
    df_report["Outcome measure question 10 response"] = df_report[
        "Outcome measure question 10 response"
    ].astype("Int64")
    df_report["Outcome measure score"] = df_report["Outcome measure score"].astype(
        "Int64"
    )
    s = df_report["Outcome measure type"]
    if pd.api.types.is_numeric_dtype(s):
        df_report["Outcome measure type"] = s.astype("Int64")

    df_report["Reason for collection"] = (
        df_report["Outcome measure type"]
        .map(REASON_FOR_COLLECTION_MAPPING).astype("Int64")
    )
    
    # drop duplicate rows
    df_report = df_report.drop_duplicates()
    return df_report


def export_outcomes(client):
    """
    Process and export the Client Table to a CSV file.

    Parameters:
        client: Dataverse client object for fetching data.

    Returns:
        None
    """
    try:
        logger.info("Starting Outcomes export...")
        df_client = process_outcomes(client)
        export_to_csv(df_client, table_name=TABLE_NAME)
        logger.info("Outcomes table exported successfully.")
    except Exception as e:
        logger.error(
            f"An exception occurred while exporting the Outcomes table: {e}"
        )
        raise