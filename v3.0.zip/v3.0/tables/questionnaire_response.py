import pandas as pd
from utils import (
    setup_logger,
    fetch_records,
    select_columns_dataframe,
    export_to_csv,
    select_and_rename_columns,
)
from config import TABLES
from PowerPlatform.Dataverse.client import DataverseClient

# Setup logger
logger = setup_logger(__name__, "logs/questionnaire_response.processing.log")

# Table name for file export
TABLE_NAME = "Questionnaireresponse"

# Constant default variables
QUESTIONNAIRE_RESPONSE = None

# Table columns
QUESTIONNAIRE_COLUMNS = ["msemr_questionnaireid", "msemr_version"]
QUESTIONNAIRE_RESPONSE_COLUMNS = [
    "msemr_questionnaireresponseid",
    "_msemr_questionnaire_value",
]
QUESTIONNAIRE_RESPONSE_ITEM_COLUMNS = [
    "msemr_questionnaireresponseitemid",
    "_msemr_questionnaireresponse_value",
]
QUESTIONNAIRE_RESPONSE_ITEM_ANSWER_COLUMNS = [
    "msemr_questionnaireresponseitemanswerid",
    "_mmhci_questionnaireresponse_value",
    "_msemr_questionnaireresponseitem_value",
]

# Key columns for merging
QUESTIONNAIRE_KEY = "msemr_questionnaireid"
QUESTIONNAIRE_RESPONSE_KEY = {
    "pk_questionnaire_response_id": "msemr_questionnaireresponseid",
    "fk_questionnaire_id": "_msemr_questionnaire_value",
}
QUESTIONNAIRE_RESPONSE_ITEM_KEY = "_msemr_questionnaireresponse_value"
QUESTIONNAIRE_RESPONSE_ITEM_ANSWER_KEY = {
    "fk_questionnaire_response_item_id": "_msemr_questionnaireresponseitem_value",
    "fk_questionnaire_response_id": "_mmhci_questionnaireresponse_value",
}

# TODO: Questionnaire response to be retrieved from database
ADDITIONAL_COLUMNS = {"Response": QUESTIONNAIRE_RESPONSE}

# Mapping of DataFrame columns in order and to their corresponding names for CSV output
FINAL_COLUMNS_MAPPING = {
    "response_key": "Response key",
    "msemr_questionnaireresponseid": "Questionnaire session key",
    "msemr_questionnaireresponseitemid": "Question ID",
    "msemr_questionnaireid": "Questionnaire version",
    "msemr_questionnaireresponseitemanswerid": "Unique question key",
    "Response": "Response",
}


def process_questionnaire_response(client: DataverseClient) -> pd.DataFrame:
    """
    Process the Questionnaire Response table by extracting, transforming and loading data from multiple dependent tables.

    Parameters:
        client: Dataverse client object for fetching data.

    Returns:
        pd.DataFrame: Processed Questionnaire Response Table.
    """
    # Step 1: Fetch data from dependent tables
    try:
        logger.info("Fetching data from dependent tables...")
        questionnaire_response_item_answer_records = fetch_records(
            client, TABLES["questionnaire_response_item_answer"]
        )
        questionnaire_records = fetch_records(client, TABLES["questionnaire"])
        questionnaire_response_item_records = fetch_records(
            client, TABLES["questionnaire_response_item"]
        )
        questionnaire_response_records = fetch_records(
            client, TABLES["questionnaire_response"]
        )
        logger.info("Data fectched successfully from dependent tables.")
    except Exception as e:
        logger.exception(f"Error fetching data from tables: {e}")
        raise

    # Step 2: Convert records to DataFrames for transformations
    try:
        logger.info("Converting records to DataFrames...")
        df_questionnaire_response_item_answer = pd.DataFrame(
            questionnaire_response_item_answer_records
        )
        df_questionnaire = pd.DataFrame(questionnaire_records)
        df_questionnaire_response_item = pd.DataFrame(
            questionnaire_response_item_records
        )
        df_questionnaire_response = pd.DataFrame(questionnaire_response_records)
        logger.info("Successfully converted records to DataFrames")
    except Exception as e:
        logger.exception(f"Error converting records to DataFrame: {e}")
        raise

    # Step 3: Clean, select and rename columns
    try:
        logger.info("Cleaning and selecting columns...")
        df_questionnaire_response_item_answer_clean = select_columns_dataframe(
            df_questionnaire_response_item_answer,
            QUESTIONNAIRE_RESPONSE_ITEM_ANSWER_COLUMNS,
        )
        df_questionnaire_clean = select_columns_dataframe(
            df_questionnaire, QUESTIONNAIRE_COLUMNS
        )
        df_questionnaire_response_item_clean = select_columns_dataframe(
            df_questionnaire_response_item, QUESTIONNAIRE_RESPONSE_ITEM_COLUMNS
        )
        df_questionnaire_response_clean = select_columns_dataframe(
            df_questionnaire_response, QUESTIONNAIRE_RESPONSE_COLUMNS
        )
        logger.info("Columns cleaned and selected successfully")
    except Exception as e:
        logger.exception(f"Error cleaning and selecting columns: {e}")
        raise

    # Step 4: Merge tables
    try:
        logger.info("Merging tables...")
        df_merged = df_questionnaire_response_item_answer_clean.merge(
            df_questionnaire_response_clean,
            how="left",
            left_on=QUESTIONNAIRE_RESPONSE_ITEM_ANSWER_KEY[
                "fk_questionnaire_response_id"
            ],
            right_on=QUESTIONNAIRE_RESPONSE_KEY["pk_questionnaire_response_id"],
        )
        df_merged = df_merged.merge(
            df_questionnaire_clean,
            how="left",
            left_on=QUESTIONNAIRE_RESPONSE_KEY["fk_questionnaire_id"],
            right_on=QUESTIONNAIRE_KEY,
        )
        df_merged = df_merged.merge(
            df_questionnaire_response_item_clean,
            how="left",
            left_on=QUESTIONNAIRE_RESPONSE_ITEM_ANSWER_KEY[
                "fk_questionnaire_response_item_id"
            ],
            right_on=QUESTIONNAIRE_RESPONSE_ITEM_KEY,
        )
        # Create response key column, and assign composite key
        df_merged["response_key"] = (
            df_merged["msemr_questionnaireresponseitemanswerid"].astype(str)
            + "_"
            + df_merged["msemr_questionnaireresponseid"].astype(str)
        )
        logger.info("Tables merged successfully")
    except Exception as e:
        logger.exception(f"Error merging tables: {e}")
        raise

    # Step 5: Apply transformations
    # Adding in an additional column and default value
    df_merged = df_merged.assign(**ADDITIONAL_COLUMNS)
    df_merged = select_and_rename_columns(df_merged, FINAL_COLUMNS_MAPPING)
    # delete all rows
    df_merged = df_merged.iloc[0:0]
    return df_merged


def export_questionnaire_response(client: DataverseClient) -> None:
    """
    Process and export the Table to a CSV file with dynamic naming.

    Parameters:
        client: Dataverse client object for fetching data.

    Returns:
        None
    """
    try:
        logger.info("Starting Questionnaire Response export...")
        # Process the table
        df_client = process_questionnaire_response(client)
        # Export the DataFrame to a CSV file
        export_to_csv(df_client, table_name=TABLE_NAME)
        logger.info("Questionnaire Response exported successfully.")
    except Exception as e:
        logger.error(
            f"An exception occurred while exporting the Questionnaire Response table: {e}"
        )
        raise
