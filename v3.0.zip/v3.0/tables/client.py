import pandas as pd
from utils import (
    setup_logger,
    fetch_records,
    select_columns_dataframe,
    export_to_csv,
    select_and_rename_columns,
)
from config import TABLES

logger = setup_logger(__name__, "logs/client.log")
# TODO: Duplicate client ID
TABLE_NAME = "Client"

CALD_STATUS_DEFAULT = 3
GENDER_DEFAULT = 0
PREFERRED_LANGUAGE_DEFAULT = 9999
COUNTRY_OF_BIRTH_DEFAULT = 9999

# Table columns
INCOMING_REFERRAL_COLUMNS = [
    "_mmhci_personid_value",
    "_mmhci_organisationid_value",
    "mmhci_birthdate",
    "_mmhci_gender_value",
    "mmhci_intersex",
    "_mmhci_sexualorientationid_value",
    "mmhci_atsistatus",
    "_mmhci_countryofbirthid_value",
    "_mmhci_languageathome_value",
    "mmhci_address1_postalcode",
    "mmhci_state",
    "mmhci_slk",
    "statecode",
]
CONTACT_COLUMNS = [
    "contactid",
    "mmhci_proficiencyinspokenenglish",
    "mmhci_disabilitystatus",
    "mmhci_requestforaccessibilityservice",
    "mmhci_sex",
]
GENDER_COLUMNS = {
    "mmhci_code": "mmhci_gender_code",
    "mmhci_name": "mmhci_gender_name",
    "mmhci_genderid": "mmhci_genderid",
}
LANGUAGE_COLUMNS = {
    "mmhci_code": "mmhci_language_code",
    "mmhci_name": "mmhci_language_name",
    "mmhci_languageid": "mmhci_languageid",
}
SEXUAL_ORIENTATION_COLUMNS = {
    "mmhci_code": "mmhci_sexual_orientation_code",
    "mmhci_name": "mmmhci_sexual_orientation_name",
    "mmhci_sexualorientationid": "mmhci_sexualorientationid",
}
BIRTH_COUNTRY_COLUMNS = {
    "mmhci_code": "mmhci_birth_country_code",
    "mmhci_name": "mmhci_birth_country_name",
    "mmhci_birthcountryid": "mmhci_birthcountryid",
}

# Column keys used for merging
INCOMING_REFERRAL_KEY = {
    "fk_gender_id": "_mmhci_gender_value",
    "fk_person_id": "_mmhci_personid_value",
    "fk_language_at_home_id": "_mmhci_languageathome_value",
    "fk_sexual_orientation_id": "_mmhci_sexualorientationid_value",
    "fk_country_of_birth_id": "_mmhci_countryofbirthid_value",
}

GENDER_KEY = "mmhci_genderid"
CONTACT_KEY = "contactid"
LANGUAGE_KEY = "mmhci_languageid"
SEXUAL_ORIENTATION_KEY = "mmhci_sexualorientationid"
BIRTH_COUNTRY_KEY = "mmhci_birthcountryid"

# DOH mapping/extraction logic
ACCESSIBILITY_SERVICE_DOH_MAPPING = {False: 2, True: 1, None: 2}
SEX_DOH_MAPPING = {
    1: 1,  # Male : Male
    2: 2,  # Female : Female
    3: 3,  # Other : Other
    None: 9,  # Not stated
}

# Country codes from dataverse table (1101: Australia, 1201: New Zealand, 8104: United states of America, 2102: England )
NON_CALD_COUNTRIES = {1101, 1201, 8104, 2102}  # set for faster lookup
NON_CALD_LANGUAGE = "English"


def calculate_cald_status(country: int, language: str) -> int:
    """
    Calculate CALD (Culturally and Linguistically Diverse) status based on country and language.

    Parameters:
        country: Birth country code.
        language: Language value.

    Returns:
        int: CALD status (1: Yes, 2: No, 3: Prefer not to answer).
    """
    try:
        if pd.isna(country) or pd.isna(language):
            return 3  # Prefer not to answer
        elif country in NON_CALD_COUNTRIES or language == NON_CALD_LANGUAGE:
            return 2  # No (Not CALD)
        else:
            return 1  # Yes (CALD)

    except Exception as e:
        logger.exception(f"Error calculating CALD status: {e}")
        raise

    except Exception as e:
        logger.exception(f"Error calculating CALD status: {e}")
        raise


def process_client_table(client):
    """
    Process the Client Table by combining data from multiple dependent tables.

    Parameters:
        client: Dataverse client object for fetching data.

    Returns:
        pd.DataFrame: Processed Client Table.
    """
    # Step 1: Fetch data from dependent tables
    try:
        logger.info("Fetching data from dependent tables...")
        incoming_referral_records = fetch_records(client, TABLES["incoming_referral"])
        contact_records = fetch_records(client, TABLES["contact"])
        gender_records = fetch_records(client, TABLES["gender"])
        language_records = fetch_records(client, TABLES["language"])
        sexual_orientation_records = fetch_records(client, TABLES["sexual_orientation"])
        birth_country_records = fetch_records(client, TABLES["birth_country"])
        logger.info("Data fectched successfully from dependent tables.")
    except Exception as e:
        logger.exception(f"Error fetching data from tables: {e}")
        raise

    # Step 2: Convert records to DataFrames for transformations
    try:
        logger.info("Converting records to DataFrames...")
        df_incoming_referral = pd.DataFrame(incoming_referral_records)
        df_contact = pd.DataFrame(contact_records)
        df_gender = pd.DataFrame(gender_records)
        df_language = pd.DataFrame(language_records)
        df_sexual_orientation = pd.DataFrame(sexual_orientation_records)
        df_birth_country = pd.DataFrame(birth_country_records)
        logger.info("DataFrames created successfully")
    except Exception as e:
        logger.exception(f"Error converting records to DataFrame: {e}")
        raise

    # Step 3: Clean and select columns directly using utility functions
    try:
        logger.info("Cleaning and selecting columns...")
        df_incoming_referral_clean = select_columns_dataframe(
            df_incoming_referral, INCOMING_REFERRAL_COLUMNS
        )
        df_contact_clean = select_columns_dataframe(df_contact, CONTACT_COLUMNS)
        df_gender_clean = select_and_rename_columns(df_gender, GENDER_COLUMNS)
        df_language_clean = select_and_rename_columns(df_language, LANGUAGE_COLUMNS)
        df_sexual_orientation_clean = select_and_rename_columns(
            df_sexual_orientation, SEXUAL_ORIENTATION_COLUMNS
        )
        df_birth_country_clean = select_and_rename_columns(
            df_birth_country, BIRTH_COUNTRY_COLUMNS
        )
        logger.info("Columns cleaned and selected successfully.")
    except Exception as e:
        logger.exception(f"Error cleaning and selecting columns: {e}")
        raise

    # Step 3.5 Filter incoming referral to active
    df_incoming_referral = df_incoming_referral[df_incoming_referral["statecode"]== 0] # 0: Active

    # Step 4: Merge tables
    try:
        logger.info("Merging tables...")
        df_merged = df_incoming_referral_clean.merge(
            df_gender_clean,
            how="left",
            left_on=INCOMING_REFERRAL_KEY["fk_gender_id"],
            right_on=GENDER_KEY,
        )
        # Right join on Contact table
        df_merged = df_merged.merge(
            df_contact_clean,
            how="right",
            left_on=INCOMING_REFERRAL_KEY["fk_person_id"],
            right_on=CONTACT_KEY,
        )
        df_merged = df_merged.merge(
            df_language_clean,
            how="left",
            left_on=INCOMING_REFERRAL_KEY["fk_language_at_home_id"],
            right_on=LANGUAGE_KEY,
        )
        df_merged = df_merged.merge(
            df_sexual_orientation_clean,
            how="left",
            left_on=INCOMING_REFERRAL_KEY["fk_sexual_orientation_id"],
            right_on=SEXUAL_ORIENTATION_KEY,
        )
        df_merged = df_merged.merge(
            df_birth_country_clean,
            how="left",
            left_on=INCOMING_REFERRAL_KEY["fk_country_of_birth_id"],
            right_on=BIRTH_COUNTRY_KEY,
        )
        logger.info("Tables merged successfully.")
    except Exception as e:
        logger.exception(f"Error merging tables: {e}")
        raise

    # Step 5: Apply transformations and extraction logic to birthdate, CALD status and request for accessibility service
    try:
        logger.info("Applying transformations...")
        # birth date format transformed to yyyy-mm-dd
        if "mmhci_birthdate" in df_merged.columns:
            df_merged["mmhci_birthdate"] = pd.to_datetime(
                df_merged["mmhci_birthdate"]
            ).dt.strftime("%Y-%m-%d")

        # Apply CALD status extraction logic
        df_merged["CALD status"] = [
            calculate_cald_status(country, language)
            for country, language in zip(
                df_merged["mmhci_birth_country_code"], df_merged["mmhci_language_code"]
            )
        ]
        # Apply Request of Accessibility service logic
        df_merged["mmhci_requestforaccessibilityservice"] = df_merged[
            "mmhci_requestforaccessibilityservice"
        ].map(ACCESSIBILITY_SERVICE_DOH_MAPPING)

        # Convert to integer first
        df_merged["mmhci_gender_code"] = df_merged["mmhci_gender_code"].astype("Int64")
        # Apply extraction logic for mmhci_sex
        df_merged["mmhci_sex"] = (
            df_merged["mmhci_gender_code"]
            .map({1: 1, 2: 2, 3: 3})  # Male  # Female  # Other
            .fillna(9)
            .astype(int)
        )

        # Convert to integer first
        df_merged["mmhci_intersex"] = df_merged["mmhci_intersex"].astype("Int64")
        # Apply extraction logic for mmhci_intersex
        df_merged["mmhci_intersex"] = (
            df_merged["mmhci_intersex"]
            .map(
                {
                    1: 1,  # Yes
                    2: 2,  # No
                    3: 4,  # Don't know
                    9: 3,  # Prefer not to answer
                }
            )
            .fillna(9)
            .astype(int)
        )

        # Convert to integer first
        df_merged["mmhci_sexual_orientation_code"] = df_merged[
            "mmhci_sexual_orientation_code"
        ].astype("Int64")
        # Apply extraction logic for mmhci_sexualorientation_code
        df_merged["mmhci_sexual_orientation_code"] = (
            df_merged["mmhci_sexual_orientation_code"]
            .map({1: 1, 2: 2, 3: 3, 4: 4, 5: 5, 9: 6})
            .fillna(9)
            .astype(int)
        )

        # Extraction logic for disability service
        df_merged["mmhci_disabilitystatus"] = (
            df_merged["mmhci_disabilitystatus"]
            .map({True: 1, False: 2})
            .fillna(3)
            .astype(int)
        )

        # Default na/blank values to 9
        df_merged["mmhci_atsistatus"] = (
            df_merged["mmhci_atsistatus"].fillna(9).astype("Int64")
        )
        df_merged["mmhci_proficiencyinspokenenglish"] = (
            df_merged["mmhci_proficiencyinspokenenglish"].fillna(9).astype("Int64")
        )
        df_merged["mmhci_state"] = df_merged["mmhci_state"].fillna(9).astype("Int64")
        df_merged["mmhci_gender_code"] = (
            df_merged["mmhci_gender_code"].fillna(GENDER_DEFAULT).astype("Int64")
        )
        s = df_merged["mmhci_language_code"]
        if pd.api.types.is_numeric_dtype(s):
            df_merged["mmhci_language_code"] = s.astype("Int64")
        df_merged["mmhci_birth_country_code"] = (
            df_merged["mmhci_birth_country_code"]
            .fillna(COUNTRY_OF_BIRTH_DEFAULT)
            .astype("Int64")
        )
        df_merged["mmhci_requestforaccessibilityservice"] = df_merged[
            "mmhci_requestforaccessibilityservice"
        ].astype("Int64")
        df_merged["mmhci_birth_country_code"] = df_merged[
            "mmhci_birth_country_code"
        ].astype("Int64")

        logger.info("Transformations applied successfully.")
    except Exception as e:
        logger.exception(f"Error applying transformations: {e}")
        raise

    # Service provider organisation key
    df_merged["_mmhci_organisationid_value"] = "SVHA-MMHCI-01"

    # Add additional columns
    df_merged["Healthcare card status"] = None
    df_merged["Main language spoken at home"] = None
    df_merged["Medical history"] = None
    df_merged["Medicare number"] = None

    # Step 6: Select columns to keep in the final table and rename
    columns_mapping = {
        "contactid": "Client key",
        "_mmhci_organisationid_value": "Service provider organisation key",
        "mmhci_slk": "Statistical linkage key",
        "mmhci_birthdate": "Date of birth",
        "mmhci_sex": "Sex",
        "mmhci_gender_code": "Gender",
        "mmhci_intersex": "Variations of sex characteristics",
        "mmhci_sexual_orientation_code": "Sexual orientation",
        "mmhci_atsistatus": "Aboriginal and Torres Strait Islander Status",
        "mmhci_birth_country_code": "Country of birth",
        "mmhci_language_code": "Preferred language",
        "Main language spoken at home": "Main language spoken at home",
        "mmhci_proficiencyinspokenenglish": "Proficiency in spoken English",
        "mmhci_address1_postalcode": "Client postcode of residence",
        "mmhci_state": "Client state of residence",
        "Medical history": "Medical history",
        "mmhci_requestforaccessibilityservice": "Request for accessibility service",
        "Healthcare card status": "Healthcare card status",
        "Medicare number": "Medicare number",
        "CALD status": "CALD status",
        "mmhci_disabilitystatus": "Disability status",
    }

    df_merged = select_and_rename_columns(df_merged, columns_mapping)
    df_merged = df_merged.drop_duplicates()

    return df_merged


def export_client_table(client):
    """
    Process and export the Client Table to a CSV file with dynamic naming.

    Parameters:
        client: Dataverse client object for fetching data.

    Returns:
        None
    """
    try:
        logger.info("Starting client table export...")
        # Process the client table
        df_client = process_client_table(client)

        # Export the DataFrame to a CSV file
        export_to_csv(df_client, table_name=TABLE_NAME)

        logger.info("Client table exported successfully.")
    except Exception as e:
        logger.error(f"An exception occurred while exporting the client table: {e}")
        raise
