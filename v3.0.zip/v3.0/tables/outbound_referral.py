import pandas as pd
import numpy as np
from utils import (
    fetch_records,
    select_columns_dataframe,
    export_to_csv,
    select_and_rename_columns,
    setup_logger,
)
from config import TABLES, REFERRAL_STAGE

TABLE_NAME = "Outboundreferral"

logger = setup_logger(__name__, "logs/outbound_referral.log")


FINAL_COLUMNS = {
    "Referral key": None,
    "Intake key": None,
    "Client key": None,
    "Course of LiCBT key": None,
    "Service provider organisation key": None,
    "Referral stage": None,
    "Date referred to other service": None,
    "Organisation type referred to": None,
    "Referred to Organisation path": None,
}

def process_outbound_referral(client):
    """
    Process the Outbound Referral Table by combining data from multiple dependent tables.

    Parameters:
        client: Dataverse client object for fetching data.

    Returns:
        pd.DataFrame: Processed Client Table.
    """

    LICBT_COMPLETION_STATUS_DOH_MAPPING = {
        100000001: 0,
        1: 2,
        100000002: 0,
        2: 6,
        100000009: 2,
        100000003: 1,
        100000006: 6,
        100000007: 6,
        100000005: 5,
        None: 7,
    }

    # Step 1: Fetch data from dependent tables
    try:
        logger.info("Fetching data from dependent tables...")
        # outbound_referral_records = fetch_records(client, TABLES["outbound_referral"])
        episode_of_care_records = fetch_records(client, TABLES["episode_of_care"])
        care_plan_records = fetch_records(client, TABLES["care_plan"])
        incoming_referral_records = fetch_records(client, TABLES["incoming_referral"])
        logger.info("Data fectched successfully from dependent tables.")
    except Exception as e:
        logger.exception(f"Error fetching data from tables: {e}")
        raise

    # Step 2: Convert records to DataFrames for transformations
    try:
        logger.info("Converting records to DataFrames...")
        ## Unable to use outbound referral as it's not designed for Release 2
        # df_outbound_referral = pd.DataFrame(outbound_referral_records)
        df_episode_of_care = pd.DataFrame(episode_of_care_records)
        df_care_plan = pd.DataFrame(care_plan_records)
        df_incoming_referral = pd.DataFrame(incoming_referral_records)
        logger.info("DataFrames created successfully")
    except Exception as e:
        logger.exception(f"Error converting records to DataFrame: {e}")
        raise

    # filter incoming_referral to active
    df_incoming_referral = df_incoming_referral[df_incoming_referral["statecode"]== 0] # 0: Active

    # Print statements to check the available columns

    # Step 3: Clean and select columns directly using utility functions
    try:
        logger.info("Cleaning and selecting columns...")
        df_episode_of_care_clean = select_columns_dataframe(
            df_episode_of_care,
            [
                "msemr_episodeofcareid",
                "statuscode",
                "_mmhci_incomingreferral_value",
                "modifiedon",
            ],
        )
        df_care_plan_clean = select_columns_dataframe(
            df_care_plan,
            [
                "_msemr_episodeofcare_value",
                "msemr_careplanid",
            ],
        )

        df_incoming_referral_clean = select_columns_dataframe(
            df_incoming_referral,
            [
                "mmhci_intakekey",
                "mmhci_incomingreferralid",
                "_mmhci_organisationid_value",
                "_mmhci_personid_value",
            ],
        )

        logger.info("Columns cleaned and selected successfully.")
    except Exception as e:
        logger.exception(f"Error cleaning and selecting columns: {e}")
        raise

    # Step 4: Merge tables
    try:
        logger.info("Merging tables...")
        df_merged = df_incoming_referral_clean.merge(
            df_episode_of_care_clean,
            how="left",
            left_on="mmhci_incomingreferralid",
            right_on="_mmhci_incomingreferral_value",
        )
        df_merged = df_merged.merge(
            df_care_plan_clean,
            how="left",
            left_on="msemr_episodeofcareid",
            right_on="_msemr_episodeofcare_value",
        )
        ## Create referral key by merging modifiedon, status code
        df_merged["referral_key"] = (
            df_merged["modifiedon"].astype(str)
            + "_"
            + df_merged["statuscode"].astype(str)
        )
        # Map the option set integer values to the DOH mapping
        df_merged["type_of_org"] = df_merged["statuscode"].map(
            LICBT_COMPLETION_STATUS_DOH_MAPPING
        )
        # Extraction logic for organisation type referred to TODO: refactor code, store values in enums/variables for readability and maintainability
        # if statuscode = 5 (stepped-up) then change it to 1 else
        df_merged["type_of_org"] = np.where(df_merged["statuscode"] == 5, 1, 0)
        # drop rows where not stepped up
        df_merged = df_merged[df_merged["type_of_org"] != 0]
        # TODO: filter to stepped up only

        # Extraction logic for referral stage
        df_merged["statuscode"] = df_merged["statuscode"].map(REFERRAL_STAGE)

        df_merged["_mmhci_organisationid_value"] = "SVHA-MMHCI-01"
        df_merged["statuscode"] = df_merged["statuscode"].astype("Int64")

        logger.info("Tables merged successfully.")
    except Exception as e:
        logger.exception(f"Error merging tables: {e}")
        raise

    # Step 5: Apply transformations and extraction logic to birthdate, CALD status and request for accessibility service
    try:
        logger.info("Applying transformations...")
        logger.info("Transformations applied successfully.")
    except Exception as e:
        logger.exception(f"Error applying transformations: {e}")
        raise

    # Constant default variables for columns
    REFFERED_TO_ORGANISATION_PATH = None  # Default to blank
    # Mapping of the default values and additional columns
    DEFAULT_COLUMN_VALUES = {
        "Referred to Organisation path": REFFERED_TO_ORGANISATION_PATH,
    }
    # Step 6: Select columns to keep in the final table and rename
    columns_mapping = {
        "referral_key": "Referral key",
        "mmhci_intakekey": "Intake key",
        "_mmhci_personid_value": "Client key",
        "msemr_careplanid": "Course of LiCBT key",
        "_mmhci_organisationid_value": "Service provider organisation key",
        "statuscode": "Referral stage",
        "modifiedon": "Date referred to other service",
        "type_of_org": "Organisation type referred to",
    }
    # Referred to Organisation path

    # Outbound referral to default to blank for R2
    columns_mapping_values = {
        "Referral key": None,
        "Intake key": None,
        "Client key": None,
        "Course of LiCBT key": None,
        "Service provider organisation key": None,
        "Referral stage": None,
        "Date referred to other service": None,
        "Organisation type referred to": None,
    }

    df_renamed_columns = select_and_rename_columns(df_merged, columns_mapping)

    # Changing date format to yyyy-mm-dd
    if "Date referred to other service" in df_renamed_columns.columns:
        df_renamed_columns["Date referred to other service"] = pd.to_datetime(
            df_renamed_columns["Date referred to other service"]
        ).dt.strftime("%Y-%m-%d")

    df_renamed_columns = df_renamed_columns.assign(**DEFAULT_COLUMN_VALUES)
    df_renamed_columns = df_renamed_columns.assign(**columns_mapping_values)
    
    df_final = (
        df_renamed_columns
        .reindex(columns=FINAL_COLUMNS.keys())
        .assign(**FINAL_COLUMNS)
    )
    df_merged = df_merged.drop_duplicates()

    return df_final


def export_outbound_referral(client):
    """
    Process and export the Table to a CSV file with dynamic naming.

    Parameters:
        client: Dataverse client object for fetching data.

    Returns:
        None
    """
    try:
        logger.info("Starting Course of LiCBT export...")
        # Process the table
        df_outbound_referral = process_outbound_referral(client)

        # Export the DataFrame to a CSV file
        export_to_csv(df_outbound_referral, table_name=TABLE_NAME)

        logger.info("Course of LiCBT table exported successfully.")
    except Exception as e:
        logger.exception(
            f"An exception occurred while exporting the Course of LiCBT table: {e}"
        )
        raise
