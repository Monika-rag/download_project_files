import pandas as pd
from utils import (
    setup_logger,
    fetch_records,
    select_columns_dataframe,
    export_to_csv,
    select_and_rename_columns,
)
from config import TABLES
from PowerPlatform.Dataverse.client import DataverseClient

# Setup Logger
logger = setup_logger(__name__, "logs/questionnaire_material.log")

# Table name for file export
TABLE_NAME = "Questionnairematerial"
# Constant default variables for columns
QUESTION = None  # Default to blank
QUESTIONNAIRE_VERSION_START_DATE = "2026-03-30"
QUESTIONNAIRE_VERSION_END_DATE = "2029-03-30"

# Mapping of the default values and additional columns
DEFAULT_COLUMN_VALUES = {
    "Question": QUESTION,
    "Questionnaire version start date": QUESTIONNAIRE_VERSION_START_DATE,
    "Questionnaire version end date": QUESTIONNAIRE_VERSION_END_DATE,
    "Question ID": None,
}
# Table columns and their corresponding names to be renamed to
QUESTIONNAIRE_COLUMNS = {
    "msemr_questionnaireid": "Questionnaire version",
    # "msemr_version" : "Questionnaire version",
    "msemr_effectiveperiodstart": "Questionnaire version start date",
    "msemr_effectiveperiodend": "Questionnaire version end date",
    "msemr_name": "Questionnaire type",
}
QUESTIONNAIRE_RESPONSE_COLUMNS = {
    # "mmhci_questionnairetype" : "Questionnaire type",
    "_msemr_questionnaire_value": "_msemr_questionnaire_value",
    "msemr_questionnaireresponseid": "msemr_questionnaireresponseid",
}

QUESTIONNAIRE_RESPONSE_ITEM_COLUMNS = {
    "msemr_questionnaireresponseitemid": "Question ID",
    "_msemr_questionnaireresponse_value": "_msemr_questionnaireresponse_value",
}
QUESTIONNAIRE_RESPONSE_ITEM_ANSWER_COLUMNS = {
    "msemr_questionnaireresponseitemanswerid": "Unique question key",
    "_mmhci_questionnaireresponse_value": "_mmhci_questionnaireresponse_value",
    "_msemr_questionnaireresponseitem_value": "_msemr_questionnaireresponseitem_value",
}

# Key columns for merging
QUESTIONNAIRE_RESPONSE_ITEM_ANSWER_KEY = {
    "fk_questionnaire_response_item_id": "_msemr_questionnaireresponseitem_value",
    "fk_questionnaire_response_id": "_mmhci_questionnaireresponse_value",
}
QUESTIONNAIRE_RESPONSE_KEY = {
    "pk_questionnaire_response_id": "msemr_questionnaireresponseid",
    "fk_questionnaire_id": "_msemr_questionnaire_value",
}
QUESTIONNAIRE_KEY = "Questionnaire version"
QUESTIONNAIRE_RESPONSE_ITEM_KEY = "Question ID"

QUESTIONNAIRE_TYPE_DOH_MAPPING = {
    "GAD-7 Anxiety": 2,
    "PHQ-9 Depression": 2,
    "K10": 2,
    "IAR-DST": 1,
}

# Final selected columns for CSV output
FINAL_COLUMNS = [
    "Questionnaire type",
    "Questionnaire version",
    "Questionnaire version start date",
    "Questionnaire version end date",
    "Unique question key",
    "Question ID",
]


def process_questionnaire_material(client: DataverseClient) -> pd.DataFrame:
    """
    Process the Questionnaire Material table by extracting, transforming and loading data from multiple dependent tables.

    Parameters:
        client: Dataverse client object for fetching data.

    Returns:
        pd.DataFrame: Processed Practitioner Preference Table.
    """
    # Step 1: Fetch data from dependent tables
    try:
        logger.info("Fetching data from deependent tables...")
        questionnaire_response_records = fetch_records(
            client, TABLES["questionnaire_response"]
        )
        questionnaire_records = fetch_records(client, TABLES["questionnaire"])
        questionnaire_response_item_answer_records = fetch_records(
            client, TABLES["questionnaire_response_item_answer"]
        )
        question_response_item_records = fetch_records(
            client, TABLES["questionnaire_response_item"]
        )
        logger.info("Data fectched successfully from dependent tables.")
    except Exception as e:
        logger.exception(f"Error fetching data from tables: {e}")
        raise

    # Step 2: Convert records to DataFrames for transformations
    try:
        logger.info("Converting records to DataFrames...")
        df_questionnaire_response = pd.DataFrame(questionnaire_response_records)
        df_questionnaire = pd.DataFrame(questionnaire_records)
        df_questionnaire_response_item_answer = pd.DataFrame(
            questionnaire_response_item_answer_records
        )
        df_questionnaire_response_item = pd.DataFrame(question_response_item_records)
        logger.info("DataFrames created successfully")
    except Exception as e:
        logger.exception(f"Error converting records to DataFrame: {e}")
        raise

    # Step 3: Clean, select and rename columns
    try:
        logger.info("Cleaning and selecting columns...")
        df_questionnaire_response_clean = select_and_rename_columns(
            df_questionnaire_response, QUESTIONNAIRE_RESPONSE_COLUMNS
        )
        df_questionnaire_clean = select_and_rename_columns(
            df_questionnaire, QUESTIONNAIRE_COLUMNS
        )
        df_questionnaire_response_item_answer_clean = select_and_rename_columns(
            df_questionnaire_response_item_answer,
            QUESTIONNAIRE_RESPONSE_ITEM_ANSWER_COLUMNS,
        )
        df_questionnaire_response_item_clean = select_and_rename_columns(
            df_questionnaire_response_item, QUESTIONNAIRE_RESPONSE_ITEM_COLUMNS
        )
        logger.info("Tables merged successfully.")
    except Exception as e:
        logger.exception(f"Error cleaning and selecting columns: {e}")
        raise

    # Step 4: Merge tables
    try:
        logger.info("Merging tables...")
        df_merged = df_questionnaire_response_item_answer_clean.merge(
            df_questionnaire_response_clean,
            how="left",
            left_on=QUESTIONNAIRE_RESPONSE_ITEM_ANSWER_KEY[
                "fk_questionnaire_response_id"
            ],
            right_on=QUESTIONNAIRE_RESPONSE_KEY["pk_questionnaire_response_id"],
        )
        df_merged = df_merged.merge(
            df_questionnaire_clean,
            how="left",
            left_on=QUESTIONNAIRE_RESPONSE_KEY["fk_questionnaire_id"],
            right_on=QUESTIONNAIRE_KEY,
        )
        df_merged = df_merged.merge(
            df_questionnaire_response_item_clean,
            how="left",
            left_on=QUESTIONNAIRE_RESPONSE_ITEM_ANSWER_KEY[
                "fk_questionnaire_response_item_id"
            ],
            right_on=QUESTIONNAIRE_RESPONSE_ITEM_KEY,
        )
        logger.info("Tables merged successfully.")
    except Exception as e:
        logger.exception(f"Error merging tables: {e}")
        raise

    # Step 5: Select columns to keep in the final table
    df_merged["Questionnaire version start date"] = pd.to_datetime(
        df_merged["Questionnaire version start date"]
    ).dt.strftime("%Y-%m-%d")
    df_merged["Questionnaire version end date"] = pd.to_datetime(
        df_merged["Questionnaire version end date"]
    ).dt.strftime("%Y-%m-%d")

    df_merged = select_columns_dataframe(df_merged, FINAL_COLUMNS)
    df_merged["Questionnaire type"] = (
        df_merged["Questionnaire type"]
        .map(QUESTIONNAIRE_TYPE_DOH_MAPPING)
        .astype("Int64")
    )
    df_merged = df_merged.assign(**DEFAULT_COLUMN_VALUES)
    df_merged = df_merged[df_merged["Questionnaire version"].notna()]
    # delete all rows
    df_merged = df_merged.iloc[0:0]
    return df_merged


def export_questionnaire_material(client: DataverseClient) -> None:
    """
    Process and export the Table to a CSV file with dynamic naming.

    Parameters:
        client: Dataverse client object for fetching data.

    Returns:
        None
    """
    try:
        logger.info("Starting Questionnaire Material export...")
        # Process the table
        df_client = process_questionnaire_material(client)
        # Export the DataFrame to a CSV file
        export_to_csv(df_client, table_name=TABLE_NAME)
        logger.info("Questionnaire material exported successfully.")
    except Exception as e:
        logger.error(
            f"An exception occurred while exporting the Questionnaire material table: {e}"
        )
        raise
