import pandas as pd
from utils import setup_logger, fetch_records, export_to_csv, select_and_rename_columns
from config import TABLES, INTAKE_REGISTRATION_STATUS_DOH_MAPPING, ORGANISATION_ID

# Setup logger
logger = setup_logger(__name__, "logs/intake.log")

# Table name for file export
TABLE_NAME = "Intake"

SUICIDAL_REFERRAL_FLAG_DEFAULT = 3  # Unknown
USER_CONSENT_INACTIVE_STATE_CODE = 1  # Inactive

# Table columns and renamed
INCOMING_REFERRAL_COLUMNS = {
    "mmhci_incomingreferralid": "Intake key",
    "_mmhci_organisationid_value": "Service provider organisation key",
    "_mmhci_personid_value": "Client key",
    "mmhci_referraldate": "Referral date",
    "_mmhci_referrertypeid_value": "Referrer organisation type",
    "mmhci_dateclientcontactedintake": "Date client contacted intake",
    "mmhci_suicidereferralflag": "Suicide referral flag",
    "statuscode": "Registration status",
}

USER_CONSENT_COLUMNS = {
    "mmhci_userconsentid": "Privacy preference key",
    "_mmhci_personid_value": "Consent Client key",
    "_mmhci_eocid_value": "_mmhci_eocid_value",
    "statecode": "state_code",  # inactive/active values
}
EPISODE_OF_CARE_COLUMNS = ["_mmhci_incomingreferral_value", "msemr_episodeofcareid"]

# Keys for merging
INCOMING_REFERRAL_KEY = "Intake key"  # mmhci_incomingreferralid used as intake key
EPISODE_OF_CARE_KEY = {
    "pk_episode_of_care_id": "msemr_episodeofcareid",
    "fk_incoming_referral_id": "_mmhci_incomingreferral_value",
}
USER_CONSENT_KEY = "_mmhci_eocid_value"

# Default values
DEFAULT_COLUMN_VALUES = {
    "Primary presenting concern": None,
    "Secondary presenting concern": None,
    "User follow up": None,
}

# Final order
DESIRED_COLUMN_ORDER = [
    "Intake key",
    "Service provider organisation key",
    "Client key",
    "Privacy preference key",
    "Referral date",
    "Referrer organisation type",
    "Date client contacted intake",
    "Primary presenting concern",
    "Secondary presenting concern",
    "User follow up",
    "Suicide referral flag",
    "Registration status",
]


def process_intake_table(client):
    """
    Process the Client Table by combining data from multiple dependent tables.

    Parameters:
        client: Dataverse client object for fetching data.

    Returns:
        pd.DataFrame: Processed Client Table.
    """
    # Fetch data from dependent tables
    logger.info("Fetching data from dependent tables...")
    incoming_referral_records = fetch_records(client, TABLES["incoming_referral"])
    episode_of_care_records = fetch_records(client, TABLES["episode_of_care"])
    user_consent_records = fetch_records(client, TABLES["user_consent"])

    # Convert to DataFrames
    df_incoming_referral = pd.DataFrame(incoming_referral_records)
    df_episode_of_care = pd.DataFrame(episode_of_care_records)
    df_user_consent = pd.DataFrame(user_consent_records)

    # filter incoming_referral to active
    df_incoming_referral = df_incoming_referral[df_incoming_referral["statecode"]== 0] # 0: Active

    # suicide referral flag default to 3

    df_incoming_referral_clean = select_and_rename_columns(
        df_incoming_referral, INCOMING_REFERRAL_COLUMNS
    )
    df_user_consent_clean = select_and_rename_columns(
        df_user_consent, USER_CONSENT_COLUMNS
    )

    try:
        logger.info("Merging tables...")
        df_merged = df_incoming_referral_clean.merge(
            df_episode_of_care,
            how="left",
            left_on=INCOMING_REFERRAL_KEY,
            right_on=EPISODE_OF_CARE_KEY["fk_incoming_referral_id"],
        )
        df_merged = df_merged.merge(
            df_user_consent_clean,
            how="left",
            left_on=EPISODE_OF_CARE_KEY["pk_episode_of_care_id"],
            right_on=USER_CONSENT_KEY,
        )
        logger.info("Tables merged successfully.")
    except Exception as e:
        logger.error(f"Error merging tables: {e}")
        raise

    # Drop rows where statecode = 1 (inactive)
    df_merged = df_merged[
        df_merged[USER_CONSENT_COLUMNS["statecode"]] != USER_CONSENT_INACTIVE_STATE_CODE
    ]
    # Additional column and default values
    df_merged = df_merged.assign(**DEFAULT_COLUMN_VALUES)
    # Organising columns in desired order
    desired_order = DESIRED_COLUMN_ORDER
    df_merged = df_merged.reindex(columns=desired_order)

    # Changing date format to yyyy-mm-dd
    df_merged[INCOMING_REFERRAL_COLUMNS["mmhci_referraldate"]] = pd.to_datetime(
        df_merged[INCOMING_REFERRAL_COLUMNS["mmhci_referraldate"]], errors="coerce"
    ).dt.strftime("%Y-%m-%d")
    df_merged[INCOMING_REFERRAL_COLUMNS["mmhci_dateclientcontactedintake"]] = (
        pd.to_datetime(
            df_merged[INCOMING_REFERRAL_COLUMNS["mmhci_dateclientcontactedintake"]]
        ).dt.strftime("%Y-%m-%d")
    )

    # sort by date time and drop duplicates
    df_merged = df_merged.sort_values(
        by=["Intake key", "Referral date"],
    )
    # drop duplicate intake keys
    df_merged = df_merged.drop_duplicates(subset="Intake key", keep="last")

    # drop null intake keys
    df_merged = df_merged.dropna(subset=["Intake key"])

    # Add logic gor missing referrer org
    df_merged["Referrer organisation type"] = df_merged[
        "Referrer organisation type"
    ].fillna("99: Self-referral")

    # Mapping for registration status
    df_merged["Registration status"] = (
        df_merged["Registration status"]
        .map(INTAKE_REGISTRATION_STATUS_DOH_MAPPING)
        .astype("Int64")
    )
    df_merged["Service provider organisation key"] = ORGANISATION_ID
    df_merged["Suicide referral flag"] = df_merged["Suicide referral flag"].astype(
        "Int64"
    )
    df_merged["Suicide referral flag"] = SUICIDAL_REFERRAL_FLAG_DEFAULT
    df_merged = df_merged.drop_duplicates()

    return df_merged


def export_intake_table(client):
    """
    Process and export the Client Table to a CSV file.

    Parameters:
        client: Dataverse client object for fetching data.

    Returns:
        None
    """
    try:
        logger.info("Starting client table export...")

        df_intake = process_intake_table(client)
        export_to_csv(df_intake, table_name=TABLE_NAME)
        logger.info("Client table exported successfully.")
    except Exception as e:
        logger.exception(f"An error occurred while exporting the client table: {e}")
        raise  # Re-raise the exception after logger its
