import pandas as pd
from utils import (
    setup_logger,
    fetch_records,
    select_columns_dataframe,
    export_to_csv,
    select_and_rename_columns,
)
from config import TABLES
from PowerPlatform.Dataverse.client import DataverseClient

# Setup logger
logger = setup_logger(__name__, "logs/practitioner_pref.processing.log")

# Table name for file export
TABLE_NAME = "Practitionerpreferences"

# Constant default variables for columns
CURRENT_FLAG = None  # Default to blank
# Mapping of the default values and additional columns
DEFAULT_COLUMN_VALUES = {
    "Sex": None,
    "Gender": None,
    "Variations of sex characteristics": None,
    "Sexual orientation": None,
    "Aboriginal and Torres Strait Islander status": None,
    "Language spoken": None,
    "Age group": None,
    "Current flag": CURRENT_FLAG,
}
# Table Columns
PRACTITIONER_PREF_COLUMNS = ["mmhci_practitionerpreferenceid", "createdon"]
EPISODE_OF_CARE_COLUMNS = ["_msemr_patient_value", "_mmhci_primarypractitioner_value"]

# Key columns for merging
PRACTITIONER_PREF_KEY = "mmhci_practitionerpreferenceid"
EPISODE_OF_CARE_KEY = "_mmhci_primarypractitioner_value"


# Mapping of DataFrame columns in order and to their corresponding names for CSV output
# FINAL_COLUMNS_MAPPING = {
#     "mmhci_practitionerpreferenceid": "Practitioner preference key",
#     "_msemr_patient_value": "Client key",
#     "createdon": "Preference timestamp",
# }

FINAL_COLUMNS_MAPPING = {
    "Practitioner preference key" : None,
    "Client key": None,
    "Preference timestamp" : None,
    "Sex": None,
    "Gender": None,
    "Variations of sex characteristics": None,
    "Sexual orientation": None,
    "Aboriginal and Torres Strait Islander status": None,
    "Language spoken": None,
    "Age group": None,
    "Current flag": None,
}


def process_practitioner_pref(client: DataverseClient) -> pd.DataFrame:
    """
    Process the Practitioner Preference Table by extracting, transforming and loading data from multiple dependent tables.

    Parameters:
        client: Dataverse client object for fetching data.

    Returns:
        pd.DataFrame: Processed Practitioner Preference Table.
    """
    # Step 1: Fetch data from dependent tables
    try:
        logger.info("Fetching data from dependent tables...")
        practitioner_pref_records = fetch_records(
            client, TABLES["practitioner_preference"]
        )
        episode_of_care_records = fetch_records(client, TABLES["episode_of_care"])
        logger.info("Data fectched successfully from dependent tables.")
    except Exception as e:
        logger.exception(f"Error fetching data from tables: {e}")
        raise

    # Step 2: Convert records to DataFrames for transformations
    try:
        logger.info("Converting records to DataFrames...")
        df_practitioner_pref_records = pd.DataFrame(practitioner_pref_records)
        df_episode_of_care_records = pd.DataFrame(episode_of_care_records)
        logger.info("DataFrames created successfully")
    except Exception as e:
        logger.exception(f"Error converting records to DataFrame: {e}")
        raise

    # Step 3: Clean and select columns directly using utility functions
    try:
        logger.info("Cleaning and selecting columns...")
        df_practitioner_pref_records_clean = select_columns_dataframe(
            df_practitioner_pref_records, PRACTITIONER_PREF_COLUMNS
        )
        df_episode_of_care_records_clean = select_columns_dataframe(
            df_episode_of_care_records, EPISODE_OF_CARE_COLUMNS
        )
        logger.info("Columns cleaned and selected successfully.")
    except Exception as e:
        logger.exception(f"Error cleaning and selecting columns: {e}")
        raise

    # Step 4: Merge tables
    try:
        logger.info("Merging tables...")
        df_merged = df_practitioner_pref_records_clean.merge(
            df_episode_of_care_records_clean,
            how="left",
            left_on=PRACTITIONER_PREF_KEY,
            right_on=EPISODE_OF_CARE_KEY,
        )
        logger.info("Tables merged successfully.")
    except Exception as e:
        logger.exception(f"Error merging tables: {e}")
        raise

    # Step 5: Apply transformations
    df_merged["createdon"] = pd.to_datetime(
        df_merged["createdon"], utc=True, errors="coerce"
    ).dt.strftime("%Y-%m-%d %H:%M:%S")
    # Step 6: Select columns to keep in the final table and rename
    # df_merged = select_and_rename_columns(df_merged, FINAL_COLUMNS_MAPPING)

    # df_merged = df_merged.assign(**DEFAULT_COLUMN_VALUES)
    df_final = (
        df_merged
        .reindex(columns=FINAL_COLUMNS_MAPPING.keys())
        .assign(**FINAL_COLUMNS_MAPPING)
    )

    df_final = df_final.iloc[0:0]
    df_merged = df_merged.drop_duplicates()

    return df_final


def export_practitioner_pref(client: DataverseClient) -> None:
    """
    Process and export the Table to a CSV file with dynamic naming.

    Parameters:
        client: Dataverse client object for fetching data.

    Returns:
        None
    """
    try:
        logger.info("Starting Practitioner Preference export...")
        # Process the table
        df_client = process_practitioner_pref(client)
        # Export the DataFrame to a CSV file
        export_to_csv(df_client, table_name=TABLE_NAME)
        logger.info("Course of Practitioner Preference exported successfully.")
    except Exception as e:
        logger.error(
            f"An error occurred while exporting the Practitioner Preference table: {e}"
        )
        raise
