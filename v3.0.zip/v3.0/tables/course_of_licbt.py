import pandas as pd
from utils import (
    setup_logger,
    fetch_records,
    select_columns_dataframe,
    export_to_csv,
    select_and_rename_columns,
)
from config import TABLES, ORGANISATION_ID
from PowerPlatform.Dataverse.client import DataverseClient

# Setup logger
logger = setup_logger(__name__, "logs/course_of_licbt.log")

# Table name for file export
TABLE_NAME = "CourseofLiCBT"

# Table columns
CARE_PLAN_COLUMNS = {
    "msemr_careplanid": "msemr_careplanid",
    "_msemr_episodeofcare_value": "_msemr_episodeofcare_value",
    "_msemr_careplantemplate_value": "_msemr_careplantemplate_value",
    "_msemr_patientidentifier_value": "_msemr_patientidentifier_value",
    "msemr_planenddate": "msemr_planenddate",
    "_msemr_ve_episodeofcare_value": "_msemr_ve_episodeofcare_value",
    "statuscode": "care_plan_status_code",
    "mmhci_drupal_program_id" : "care_plan_mmhci_drupal_program_id",
}
USER_CONSENT_COLUMNS = ["_mmhci_personid_value", "mmhci_userconsentid"]
CARE_PLAN_TEMPLATE_COLUMNS = ["msemr_careplantemplateid", "mmhci_drupal_program_id"]
EPISODE_OF_CARE_COLUMNS = [
    "statuscode",
    "_msemr_organization_value",
    "msemr_episodeofcareid",
]

EPISODE_OF_CARE_STATUS_CODE_COLUMN = "statuscode"
EPISODE_OF_CARE_ORGANISATION_COLUMN = "_msemr_organization_value"

# Key columns for merging
CARE_PLAN_KEY = {
    "fk_care_plan_template_id": "care_plan_mmhci_drupal_program_id",
    "fk_episode_of_care_id": "_msemr_ve_episodeofcare_value",
    "fk_patient_identifier_id": "_msemr_patientidentifier_value",
}
CARE_PLAN_TEMPLATE_KEY = "mmhci_drupal_program_id"
EPISODE_OF_CARE_KEY = "msemr_episodeofcareid"
USER_CONSENT_KEY = "_mmhci_personid_value"

# DOH extraction logic mapping
# TODO: Add extraction logic comment to understand the values
LICBT_COMPLETION_STATUS_DOH_MAPPING = {
    100000001: 0,
    1: 2,
    100000002: 0,
    2: 6,
    100000009: 2,
    100000003: 1,
    100000006: 6,
    100000007: 6,
    100000005: 5,
    None: 7,
}

# Final mapping
FINAL_COLUMNS_MAPPING = {
    "msemr_careplanid": "Course of LiCBT key",
    "_msemr_organization_value": "Service provider organisation key",
    "_msemr_patientidentifier_value": "Client key",
    "mmhci_userconsentid": "Privacy preference key",
    "msemr_careplantemplateid": "Workbook ID",
    "msemr_planenddate": "Course of LiCBT end date",
    "statuscode": "Course of LiCBT completion status",
    # "msemr_episodeofcareid" : "episode of care id",
    # "care_plan_status_code" : "Care Plan Status"
}

def process_course_of_licbt(client: DataverseClient) -> pd.DataFrame:
    """
    Process the Course of LiCBT by combining data from multiple dependent tables.

    Parameters:
        client: Dataverse client object for fetching data.

    Returns:
        pd.DataFrame: Processed Course of LiCBT Table.
    """
    # Step 1: Fetch data from dependent tables
    try:
        logger.info("Fetching data from dependent tables...")
        care_plan_records = fetch_records(client, TABLES["care_plan"])
        user_consent_records = fetch_records(client, TABLES["user_consent"])
        care_plan_template_records = fetch_records(client, TABLES["care_plan_template"])
        episode_of_care_records = fetch_records(client, TABLES["episode_of_care"])
        logger.info("Data fectched successfully from dependent tables.")
    except Exception as e:
        logger.exception(f"Error fetching data from tables: {e}")
        raise

    # Step 2: Convert records to DataFrames for transformations
    try:
        logger.info("Converting records to DataFrames...")
        df_care_plan = pd.DataFrame(care_plan_records)
        df_user_consent = pd.DataFrame(user_consent_records)
        df_care_plan_template = pd.DataFrame(care_plan_template_records)
        df_episode_of_care = pd.DataFrame(episode_of_care_records)
        logger.info("DataFrames created successfully")
    except Exception as e:
        logger.exception(f"Error converting records to DataFrame: {e}")
        raise

    # Step 3: Clean and select columns directly using utility functions
    try:
        logger.info("Cleaning and selecting columns...")
        df_care_plan_clean = select_and_rename_columns(df_care_plan, CARE_PLAN_COLUMNS)
        df_user_consent_clean = select_columns_dataframe(
            df_user_consent, USER_CONSENT_COLUMNS
        )
        df_care_plan_template_clean = select_columns_dataframe(
            df_care_plan_template, CARE_PLAN_TEMPLATE_COLUMNS
        )
        df_episode_of_care_clean = select_columns_dataframe(
            df_episode_of_care, EPISODE_OF_CARE_COLUMNS
        )
        logger.info("Columns cleaned and selected successfully.")
    except Exception as e:
        logger.exception(f"Error cleaning and selecting columns: {e}")
        raise

    # Step 4: Merge tables
    try:
        logger.info("Merging tables...")
        df_merged = df_care_plan_clean.merge(
            df_care_plan_template_clean,
            how="left",
            left_on=CARE_PLAN_KEY["fk_care_plan_template_id"],
            right_on=CARE_PLAN_TEMPLATE_KEY,
        )
        df_merged = df_merged.merge(
            df_episode_of_care_clean,
            how="left",
            left_on=CARE_PLAN_KEY["fk_episode_of_care_id"],
            right_on=EPISODE_OF_CARE_KEY,
        )
        df_merged = df_merged.merge(
            df_user_consent_clean,
            how="left",
            left_on=CARE_PLAN_KEY["fk_patient_identifier_id"],
            right_on=USER_CONSENT_KEY,
        )
        logger.info("Tables merged successfully.")
    except Exception as e:
        logger.exception(f"Error merging tables: {e}")
        raise

    # Step 5: Apply transformations and extraction logic to birthdate, CALD status and request for accessibility service
    try:
        logger.info("Applying transformations...")
        if CARE_PLAN_COLUMNS["msemr_planenddate"] in df_merged.columns:
            df_merged[CARE_PLAN_COLUMNS["msemr_planenddate"]] = pd.to_datetime(
                df_merged[CARE_PLAN_COLUMNS["msemr_planenddate"]]
            ).dt.strftime("%Y-%m-%d")
        # extraction logic for status code referral stage
        df_merged[EPISODE_OF_CARE_STATUS_CODE_COLUMN] = df_merged[
            EPISODE_OF_CARE_STATUS_CODE_COLUMN
        ].map(LICBT_COMPLETION_STATUS_DOH_MAPPING)
        df_merged[EPISODE_OF_CARE_STATUS_CODE_COLUMN] = df_merged[
            EPISODE_OF_CARE_STATUS_CODE_COLUMN
        ].astype("Int64")
        df_merged[EPISODE_OF_CARE_ORGANISATION_COLUMN] = ORGANISATION_ID
        logger.info("Transformations applied successfully.")
    except Exception as e:
        logger.exception(f"Error applying transformations: {e}")
        raise

    # Step 6: Select columns to keep in the final table and rename
    df_merged = select_and_rename_columns(df_merged, FINAL_COLUMNS_MAPPING)
    df_merged = df_merged.drop_duplicates()

    return df_merged


def export_course_of_licbt(client: DataverseClient) -> None:
    """
    Process and export the Course of LiCBT Table to a CSV file with dynamic naming.

    Parameters:
        client: Dataverse client object for fetching data.

    Returns:
        None
    """
    try:
        logger.info("Starting Course of LiCBT export...")
        # Process the table
        df_client = process_course_of_licbt(client)
        # Export the DataFrame to a CSV file
        export_to_csv(df_client, table_name=TABLE_NAME)

        logger.info("Course of LiCBT table exported successfully.")
    except Exception as e:
        logger.error(
            f"An exception occurred while exporting the Course of LiCBT table: {e}"
        )
        raise
