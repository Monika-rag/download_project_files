import pandas as pd
from utils import (
    setup_logger,
    fetch_records,
    select_columns_dataframe,
    export_to_csv,
    select_and_rename_columns,
)
from config import TABLES, ORGANISATION_ID
from PowerPlatform.Dataverse.client import DataverseClient

# Setup logger
logger = setup_logger(__name__, "logs/practitioner.log")

# Table name for file export
TABLE_NAME = "Questionnairesession"

# Constant default variables for columns
CHECK_IN_AWARENESS_PATHWAY_DEFAULT = 4

# Table Columns
QUESTIONNAIRE_RESPONSE = [
    "msemr_status",
    "_msemr_source_value",
    "mmhci_responsedate",
    "msemr_questionnaireresponseid",
    "_owningbusinessunit_value",
    "mmhci_questionnairetype",
    "_mmhci_incomingreferralid_value",
    "msemr_name",
]
INCOMING_REFERRAL_COLUMNS = ["mmhci_incomingreferralid"]
ENCOUNTER_COLUMNS = [
    "_mmhci_incomingreferralid_value",
    "msemr_encounterid",
    "_mmhci_careplanactivity_value",
]
CARE_PLAN_COLUMNS = ["_msemr_ve_episodeofcare_value", "msemr_careplanid"]
CARE_PLAN_ACTIVITY_COLUMNS = ["msemr_careplanactivityid", "_msemr_careplan_value"]
EPISODE_OF_CARE_COLUMNS = ["msemr_episodeofcareid", "_mmhci_incomingreferral_value"]

QUESTIONNAIRE_COMPLETION_STATUS = "msemr_status"
QUESTIONNAIRE_DATE = "mmhci_responsedate"

# Table Keys
INCOMING_REFERRAL_KEY = {"pk_incoming_referral_id": "mmhci_incomingreferralid"}
QUESTIONNAIRE_RESPONE_KEY = {
    "fk_incoming_referral_id": "_mmhci_incomingreferralid_value"
}
# ENCOUNTER_KEY = {
#     "fk_incoming_referral_id" : "_mmhci_incomingreferralid_value",
#     "pk_encounter_id" : "msemr_encounterid"
# }
CARE_PLAN_KEY = {"fk_episode_of_care_id": "_msemr_ve_episodeofcare_value"}
CARE_PLAN_ACTIVITY_KEY = {
    "pk_care_plan_activity_id": "msemr_careplanactivityid",
    "fk_care_plan_id": "_msemr_careplan_value",
}
EPISODE_OF_CARE_KEY = {
    "pk_episode_of_care_id": "msemr_episodeofcareid",
    "fk_incoming_referral_id": "_mmhci_incomingreferral_value",
}

# Mapping of the default values and additional columns
DEFAULT_COLUMN_VALUES = {
    "Check In awareness pathway": CHECK_IN_AWARENESS_PATHWAY_DEFAULT,
    "Questionnaire type": None,
    "Course of LiCBT": None,
    "Service provider organisation key": ORGANISATION_ID,
}

# Mapping of DataFrame columns in order and to their corresponding names for CSV output
FINAL_COLUMNS_MAPPING = {
    "msemr_questionnaireresponseid": "Questionnaire session key",
    "mmhci_responsedate": "Questionnaire date",
    "Service provider organisation key": "Service provider organisation key",
    "_msemr_source_value": "Client key",
    "_mmhci_incomingreferralid_value": "Intake key",
    "msemr_careplanid": "Course of LiCBT key",
    "msemr_name": "Questionnaire type",
    "msemr_status": "Questionnaire completion status",
    "Check In awareness pathway": "Check In awareness pathway",
}

QUESTIONNAIRE_TYPE_DOH_MAPPING = {
    "GAD-7 Anxiety": 2,
    "PHQ-9 Depression": 2,
    "K10": 2,
    "IAR-DST": 1,
}

# DOH Extraction logic mapping
# TODO: Add the other statuses in
QUESTIONNAIRE_SESSION_COMPLETION_STATUS_DOH_MAPPING = {
    935000001: 2  # Completed : Completed
}


def process_questionnaire_session(client: DataverseClient) -> pd.DataFrame:
    """
    Process the Questionnaire Session Table by extracting, transforming and loading data from multiple dependent tables.

    Parameters:
        client: Dataverse client object for fetching data.

    Returns:
        pd.DataFrame: Processed Questionnaire Session Table.
    """
    # Step 1: Fetch data from dependent tables
    try:
        logger.info("Fetching data from dependent tables...")
        questionnaire_response_records = fetch_records(
            client, TABLES["questionnaire_response"]
        )
        care_plan_records = fetch_records(client, TABLES["care_plan"])
        # care_plan_activity_records = fetch_records(client, TABLES["care_plan_activity"])
        # questionnaire_records = fetch_records(client, TABLES["questionnaire"])
        incoming_referral_records = fetch_records(client, TABLES["incoming_referral"])
        # encounter_records = fetch_records(client, TABLES["encounter"])
        episode_of_care_records = fetch_records(client, TABLES["episode_of_care"])
        logger.info("Data fectched successfully from dependent tables.")
    except Exception as e:
        logger.exception(f"exception fetching data from tables: {e}")
        raise

    # Step 2: Convert records to DataFrames for transformations
    try:
        logger.info("Converting records to DataFrames...")
        df_questionnaire_response = pd.DataFrame(questionnaire_response_records)
        df_care_plan = pd.DataFrame(care_plan_records)
        # df_care_plan_activity = pd.DataFrame(care_plan_activity_records)
        # df_questionnaire = pd.DataFrame(questionnaire_records)
        df_incoming_referral = pd.DataFrame(incoming_referral_records)
        # df_encounter = pd.DataFrame(encounter_records)
        df_episode_of_care = pd.DataFrame(episode_of_care_records)
        logger.info("DataFrames created successfully")
    except Exception as e:
        logger.exception(f"exception converting records to DataFrame: {e}")
        raise

    # filter incoming_referral to active
    df_incoming_referral = df_incoming_referral[df_incoming_referral["statecode"]== 0] # 0: Active

    # Step 3: Clean, select and rename columns
    try:
        logger.info("Cleaning and selecting columns...")
        df_questionnaire_response_clean = select_columns_dataframe(
            df_questionnaire_response, QUESTIONNAIRE_RESPONSE
        )
        df_incoming_referral_clean = select_columns_dataframe(
            df_incoming_referral, INCOMING_REFERRAL_COLUMNS
        )
        df_care_plan_clean = select_columns_dataframe(df_care_plan, CARE_PLAN_COLUMNS)
        df_episode_of_care_clean = select_columns_dataframe(
            df_episode_of_care, EPISODE_OF_CARE_COLUMNS
        )
        logger.info("Columns cleaned and selected successfully")
    except Exception as e:
        logger.exception(f"exception cleaning and selecting columns: {e}")
        raise

    # Step 3.5: Drop duplicates
    # before = len(df_episode_of_care_clean)
    # TODO: Need to sort before dropping
    df_episode_of_care_clean = df_episode_of_care_clean.drop_duplicates(
        subset=["msemr_episodeofcareid", "_mmhci_incomingreferral_value"]
    )
    # after = len(df_episode_of_care_clean)
    # print("EOC rows removed:", before - after)
    # before = len(df_care_plan)
    # df_care_plan_clean = df_care_plan_clean.drop_duplicates(
    #     subset=["_msemr_ve_episodeofcare_value", "msemr_careplanid"]
    # )
    # after = len(df_care_plan)
    # print("care plan rows removed:", before - after)
    # before = len(df_questionnaire_response_clean)
    # df_questionnaire_response_clean = df_questionnaire_response_clean.drop_duplicates()
    # after = len(df_questionnaire_response_clean)
    # print("Questionnaire response rows", before)

    # Step 4: Merge tables
    try:
        logger.info("Merging tables...")
        df_merged = df_questionnaire_response_clean.merge(
            df_incoming_referral_clean,
            how="left",
            left_on=QUESTIONNAIRE_RESPONE_KEY["fk_incoming_referral_id"],
            right_on=INCOMING_REFERRAL_KEY["pk_incoming_referral_id"],
        )
        df_merged = df_merged.merge(
            df_episode_of_care_clean,
            how="left",
            left_on=INCOMING_REFERRAL_KEY["pk_incoming_referral_id"],
            right_on=EPISODE_OF_CARE_KEY["fk_incoming_referral_id"],
        )
        df_merged = df_merged.merge(
            df_care_plan_clean,
            how="left",
            left_on=EPISODE_OF_CARE_KEY["pk_episode_of_care_id"],
            right_on=CARE_PLAN_KEY["fk_episode_of_care_id"],
        )
        logger.info("Tables merged successfully")
    except Exception as e:
        logger.exception(f"Error merging tables: {e}")
        raise

    # before = len(df_merged)
    # df_merged = df_merged.drop_duplicates()
    # after = len(df_merged)
    # print("df merged rows removed", before-after)

    # Step 5: Apply transformations
    try:
        logger.info("Applying transformations...")
        # Change date format
        df_merged[QUESTIONNAIRE_DATE] = pd.to_datetime(
            df_merged[QUESTIONNAIRE_DATE]
        ).dt.strftime("%Y-%m-%d")
        # Mapping
        df_merged[QUESTIONNAIRE_COMPLETION_STATUS] = df_merged[
            QUESTIONNAIRE_COMPLETION_STATUS
        ].astype("Int64")
        df_merged[QUESTIONNAIRE_COMPLETION_STATUS] = df_merged[
            QUESTIONNAIRE_COMPLETION_STATUS
        ].map(QUESTIONNAIRE_SESSION_COMPLETION_STATUS_DOH_MAPPING)
        df_merged[QUESTIONNAIRE_COMPLETION_STATUS] = df_merged[
            QUESTIONNAIRE_COMPLETION_STATUS
        ].astype("Int64")
        df_merged[QUESTIONNAIRE_COMPLETION_STATUS] = df_merged[
            QUESTIONNAIRE_COMPLETION_STATUS
        ].fillna(0)
        # Default value and additional column
        df_merged = df_merged.assign(**DEFAULT_COLUMN_VALUES)
        logger.info("Transformations applied successfully.")
    except Exception as e:
        logger.exception(f"Error applying transformations: {e}")
        raise

    df_merged = select_and_rename_columns(df_merged, FINAL_COLUMNS_MAPPING)
    df_merged["Questionnaire type"] = (
        df_merged["Questionnaire type"]
        .map(QUESTIONNAIRE_TYPE_DOH_MAPPING)
        .astype("Int64")
    )
    df_merged = df_merged.drop_duplicates()
    # delete all rows
    df_merged = df_merged.iloc[0:0]

    return df_merged


def export_questionnaire_session(client):
    """
    Process and export the Table to a CSV file with dynamic naming.

    Parameters:
        client: Dataverse client object for fetching data.

    Returns:
        None
    """
    try:
        logger.info("Starting Questionnaire Material export...")
        # Process the table
        df_client = process_questionnaire_session(client)
        # Export the DataFrame to a CSV file
        export_to_csv(df_client, table_name=TABLE_NAME)

        logger.info("Questionnaire_material exported successfully.")
    except Exception as e:
        logger.error(
            f"An exception occurred while exporting the Questionnaire material table: {e}"
        )
        raise
