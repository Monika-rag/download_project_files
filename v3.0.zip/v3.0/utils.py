import pandas as pd
import os
from datetime import datetime
import logging
import csv
from azure.identity import ClientSecretCredential, InteractiveBrowserCredential
# from azure.keyvault.secrets import SecretClient
# from azure.identity import DefaultAzureCredential
from PowerPlatform.Dataverse.client import DataverseClient
from pathlib import Path
from config import OUTPUT_FOLDER

# Interactive authentication through microsoft TODO: Update to utilise token for automation in the future
def authenticate_client_old(env_url: str):
    """
    Authenticate with Dataverse using InteractiveBrowserCredential.

    Parameters:
        env_url (str): Dataverse environment URL.

    Returns:
        DataverseClient: Authenticated Dataverse client object.
    """
    logging.info("Opening browser to login (read-only access)...")
    credential = InteractiveBrowserCredential()
    return DataverseClient(env_url, credential)


# def authenticate_client(env_url: str, client_secret: str) -> DataverseClient:
#     """
#     Authenticate with Dataverse.

#     mode="sp" -> Service Principal (headless, production)
#     mode="interactive" -> Browser login (local dev)

#     If mode="sp", you must provide:
#       - tenant id (env var AZURE_TENANT_ID)
#       - client id (env var AZURE_CLIENT_ID)
#       - client secret (argument client_secret OR env var AZURE_CLIENT_SECRET)
#     """
#     credential = DefaultAzureCredential()
#     client = SecretClient(vault_url=os.environ["VAULT_URL"], credential=credential)

#     # fetch secret
#     secret = client.get_secret("dataverse-secret-name")

#     tenant_id = os.environ["AZURE_TENANT_ID"]
#     client_id = os.environ["AZURE_CLIENT_ID"]
#     secret = os.environ["AZURE_CLIENT_SECRET"]

#     logging.info("Authenticating to Dataverse using Service Principal (non-interactive)...")
#     credential = ClientSecretCredential(
#         tenant_id=tenant_id,
#         client_id=client_id,
#         client_secret=secret
#     )
#     return DataverseClient(env_url, credential)


def fetch_records(client, table_name: str) -> list:
    """
    Fetch records from a Dataverse table.

    Parameters:
        client: Dataverse client object.
        table_name (str): Name of the table to fetch records from.

    Returns:
        list: List of records fetched from the table.
    """
    logging.info(f"Fetching records from '{table_name}'...")
    batches = client.records.get(table_name)
    records = []
    for batch in batches:
        records.extend(batch)
    logging.info(f"Retrieved {len(records)} records from '{table_name}'.")
    return records

def select_columns_dataframe(df: pd.DataFrame, columns_to_keep: list) -> pd.DataFrame:
    """
    Clean the DataFrame by removing metadata columns and selecting specific columns.

    Parameters:
        df (pd.DataFrame): Input DataFrame.
        columns_to_keep (list): List of columns to retain.

    Returns:
        pd.DataFrame: Cleaned DataFrame with selected columns.
    """
    if df.empty:
        return df
    # Remove metadata columns (e.g., columns starting with "@")
    df_clean = df.loc[:, ~df.columns.str.startswith("@")]
    # Select only the specified columns
    return df_clean[[col for col in columns_to_keep if col in df_clean.columns]]

def select_and_rename_columns(df: pd.DataFrame, columns_mapping: dict) -> pd.DataFrame:
    """
    Select and rename columns in a DataFrame

    Parameters:
        df (pd.DataFrame): Input DataFrame.
        columns_mapping (dict): Dictionary mapping old column names to new column names

    Returns:
        pd.DataFrame: DataFrame with selected and renamed columns
    """
    if df.empty:
        return df
    
    # Remove metadata columns (e.g., columns starting with "@")
    df = df.loc[:, ~df.columns.str.startswith("@")]
    # Select columns based on keys in the mapping
    selected_columns = list(columns_mapping.keys())
    df_selected = df[selected_columns]
    # Rename columns based on the mapping
    df_renamed = df_selected.rename(columns=columns_mapping)
    return df_renamed

def export_to_csv(df: pd.DataFrame, table_name: str):
    """
    Export DataFrame to a CSV file with dynamic naming format: MMHCI_table_name_DDMMYYY_HH_MM_SS.csv.

    Parameters:
        df (pd.DataFrame): DataFrame to export.
        table_name (str): Name of the table being processed.
        output_folder (str): Folder to save the CSV file.

    Returns:
        None
    """

    now = datetime.now()
    today_folder = now.strftime("%Y-%m-%d")
    timestamp = now.strftime("%Y%m%d_%H%M%S")
    timestamp_trailer = now.strftime("%Y%m%d")

    dir_path = os.path.join(OUTPUT_FOLDER, today_folder)
    os.makedirs(dir_path, exist_ok=True)

    file_name = f"{table_name}.csv"
    file_path = os.path.join(dir_path, file_name)

    df.to_csv(file_path, index=False, encoding="utf-8")
    logging.info("Exported %s rows to %s", len(df), file_path)

    # Trailer right beside the CSV
    trailer_file_name = f"trailer{timestamp_trailer}.csv"
    trailer_file_path = os.path.join(dir_path, trailer_file_name)

    write_trailer_record(trailer_file_path, file_path, len(df))

    return file_path

def find_matching_column_across_dataframes(df_to_search, target_df, target_column):
    """
    Find columns in one DataFrame where any row matches the values in a target column from another DataFrame.

    Parameters:
        df_to_search (pd.DataFrame): The DataFrame to search for matching columns.
        target_df (pd.DataFrame): The DataFrame containing the target column.
        target_column (str): The name of the column in the target DataFrame to compare against.

    Returns:
        list: A list of column names in df_to_search that have matching rows with the target column in target_df.
    """
    if target_column not in target_df.columns:
        raise ValueError(f"Target column '{target_column}' does not exist in the target DataFrame.")
    
    matching_columns = []
    target_values = target_df[target_column].dropna().unique() 
    
    for column in df_to_search.columns:
        # Check if any value in the current column matches a value in the target column
        if df_to_search[column].isin(target_values).any():
            matching_columns.append(column)
    
    return matching_columns

def find_matching_value_column(df_to_search, target_value: str):
    """
    """
    matching_columns = []
    for column in df_to_search.columns:
        if (df_to_search[column] == (target_value)).any():
            matching_columns.append(column)

def setup_logger(name: str, log_filename: str):
    """
    Set up a logger that logs to both a file and console.

    Args:
        name (str): Logger name (usually __name__).
        log_filename (str): Path to the log file.

    Returns:
        logging.Logger: Configured logger
    """
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    logger.propagate = False

    # Avoid adding multiple handlers if already set
    if not logger.hasHandlers():
        # Ensure log folder exists
        Path(log_filename).parent.mkdir(parents=True, exist_ok=True)

        # File handler
        fh = logging.FileHandler(log_filename)
        fh.setLevel(logging.INFO)

        # Console handler
        ch = logging.StreamHandler()
        ch.setLevel(logging.INFO)

        # Formatter
        formatter = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
        fh.setFormatter(formatter)
        ch.setFormatter(formatter)

        # Add handlers
        logger.addHandler(fh)
        logger.addHandler(ch)

    return logger

def log_df_snapshot(logger, df, name: str, n: int = 5) -> None:
    """
    Log a small dataframe snapshot at ERROR level for fast diagnosis.
    """
    if df is None:
        logger.error("[%s] dataframe is None", name)
        return

    try:
        logger.error("[%s] shape=%s", name, df.shape)
        logger.error("[%s] columns=%s", name, df.columns.tolist())
        logger.error("[%s] head(%d):\n%s", name, n, df.head(n).to_string(index=False))
    except Exception as snap_err:
        logger.error("[%s] failed to log snapshot: %s", name, snap_err)

def write_trailer_record(trailer_file_path: str, output_file_path: str, row_count: int):
    try:
        # 1. Input validation
        if not trailer_file_path:
            raise ValueError("Trailer file path is empty or None.")

        if not output_file_path:
            raise ValueError("Output file path is empty or None.")

        if row_count is None or row_count < 0:
            raise ValueError(f"Invalid row count provided: {row_count}")

        # 2. Check output file exists
        if not os.path.exists(output_file_path):
            raise FileNotFoundError(
                f"Output file does not exist, cannot write trailer record: {output_file_path}"
            )
        
        # 3. Ensure trailer directory exists
        trailer_dir = os.path.dirname(trailer_file_path)
        if trailer_dir:
            os.makedirs(trailer_dir, exist_ok=True)

        # 4. Write trailer record
        output_file_name = os.path.basename(output_file_path)

        write_header = (
            not os.path.exists(trailer_file_path)
            or os.path.getsize(trailer_file_path) == 0
        )

        with open(trailer_file_path, "a", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)

            if write_header:
                writer.writerow(["output_file_name", "row_count"])

            writer.writerow([output_file_name, row_count])

        logging.info(
            f"Trailer updated successfully | File: {output_file_name} | Rows: {row_count}"
        )

    except Exception as e:
        logging.error(
            f"Failed to write trailer record for output file '{output_file_path}': {e}"
        )
        raise

def require_columns(df: pd.DataFrame, required: list[str], df_name: str) -> None:
    """
    Verify columns exists in the DataFrame
    """
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise KeyError(f"{df_name} is missing required columns: {missing}. "
                       f" Available columns: {list(df.columns)}")