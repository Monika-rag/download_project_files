#!/bin/bash

echo "Starting dependency installation..."

# Check if requirements.txt exists
if [ ! -f requirements.txt ]; then
    echo "Error: requirements.txt file not found!"
    exit 1
fi

# Install dependencies using python3 -m pip
echo "Installing dependencies from requirements.txt using python3 -m pip..."
python3 -m pip install -r requirements.txt

# Check if the installation was successful
if [ $? -eq 0 ]; then
    echo "All dependencies installed successfully."
else
    echo "Error occurred while installing dependencies."
    exit 1
fi