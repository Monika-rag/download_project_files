from utils import authenticate_client_old, setup_logger

from tables.client import export_client_table
from tables.questionnaire_material import export_questionnaire_material
from tables.privacy_pref import export_privacy_prefences_table
from tables.course_of_licbt import export_course_of_licbt
from tables.service_contact import export_service_contact
from tables.practitioner_pref import export_practitioner_pref
from tables.practitioner import export_practitioner
from tables.questionnaire_session import export_questionnaire_session
from tables.questionnaire_response import export_questionnaire_response
from tables.intake import export_intake_table
from tables.iar_dst import export_iar_dst_table
from tables.outbound_referral import export_outbound_referral
from tables.outcomes import export_outcomes
import traceback 
import sys
from config import R2_SIT_ENV_URL, R2_PROD_ENV_URL

# Setup Logger
logger = setup_logger(__name__, "logs/main.processing.log")

# for print messages
GREEN = "\033[32m"
RED = "\033[31m"
YELLOW = "\033[33m"
BOLD = "\033[1m"
RESET = "\033[0m"


def main() -> None:
    # 1) Authenticate 
    logger.info("Authenticating client...")
    try:
        client = authenticate_client_old(R2_SIT_ENV_URL)
        logger.info(f"{GREEN}{BOLD}Client authenticated successfully{RESET}")
    except Exception:
        logger.exception(f"{RED}{BOLD}Authentication failed. Stopping pipeline.{RESET}")
        raise 

    exports = [
        ("intake", export_intake_table),
        ("client", export_client_table),
        ("privacy_preferences", export_privacy_prefences_table),
        ("iar_dst", export_iar_dst_table),
        ("course_of_licbt", export_course_of_licbt),
        ("service_contact", export_service_contact),
        ("practitioner_pref", export_practitioner_pref),
        ("practitioner", export_practitioner),
        ("questionnaire_material", export_questionnaire_material),
        ("questionnaire_session", export_questionnaire_session),
        ("questionnaire_response", export_questionnaire_response),
        ("outcomes", export_outcomes),
        ("outbound_referral", export_outbound_referral),
    ]

    # 2) Run all exports; collect errors instead of stopping
    errors = []

    logger.info("Starting table exports (%d total)...", len(exports))

    for name, fn in exports:
        logger.info(f"{YELLOW}{BOLD}=== START export: %s ==={RESET}", name)
        try:
            fn(client)
            logger.info(f"{GREEN}{BOLD}=== SUCCESS export: %s ==={RESET}", name)
        except Exception as e:
            # log traceback for debugging
            logger.exception(f"{RED}{BOLD}=== FAILED export: %s ==={RESET}", name)

            # collect for end-of-run summary
            errors.append({
                "name": name,
                "error": repr(e),
                "traceback": traceback.format_exc()
            })
        finally:
            logger.info(f"{GREEN}{BOLD}=== END export: %s ==={RESET}", name)

    # 3) If anything failed, raise error at end
    if errors:
        logger.error(f"{RED}{BOLD}Pipeline completed with %d failure(s).{RESET}", len(errors))

        summary_lines = [f"{len(errors)} export(s) failed:"]
        for err in errors:
            summary_lines.append(f"\n--- {err['name']} ---")
            summary_lines.append(err["error"])
            summary_lines.append(err["traceback"])

        raise RuntimeError("\n".join(summary_lines))

    logger.info(f"{YELLOW}{BOLD}All tables exported successfully (0 failures).{RESET}")


if __name__ == "__main__":
    try:
        main()
    except Exception:
        logger.exception("Run failed.")
        sys.exit(1)
