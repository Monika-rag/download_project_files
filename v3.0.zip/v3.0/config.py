# Configuration for Dataverse environment and table names
R2_SIT_ENV_URL= "https://orgad765dff.crm6.dynamics.com"
R2_PROD_ENV_URL= "https://mmhci.crm6.dynamics.com"

# Table names
TABLES = {
    "incoming_referral": "mmhci_incomingreferral",
    "contact": "contact",
    "gender": "mmhci_gender",
    "language": "mmhci_language",
    "birth_country": "mmhci_birthcountry",
    "sexual_orientation": "mmhci_sexualorientation",
    "questionnaire_response" : "msemr_questionnaireresponse",
    "questionnaire_response_item" : "msemr_questionnaireresponseitem",
    "questionnaire" : "msemr_questionnaire",
    "questionnaire_response_item_answer" : "msemr_questionnaireresponseitemanswer",
    "questionnaire_item" : "msemr_questionnaireitem",
    "care_plan" : "msemr_careplan",
    "user_consent" : "mmhci_userconsent",
    "care_plan_template" : "msemr_careplantemplate",
    "episode_of_care" : "msemr_episodeofcare",
    "care_plan_activity" : "msemr_careplanactivity",
    "care_plan_activity_template" : "msemr_careplanactivitytemplate",
    "care_plan_goal_template" : "msemr_careplangoaltemplate",
    "bookable_resource" : "bookableresource",
    "practitioner_preference" : "mmhci_practitionerpreference",
    "system_user" : "systemuser",
    "practitioner_qualification" : "msemr_practitionerqualification",
    "organisation" : "account",
    "consent_purpose" : "mmhci_consentpurpose",
    "encounter" : "msemr_encounter"
}

ORGANISATION_ID = "SVHA-MMHCI-01"

LICBT_COMPLETION_STATUS = {
    100000001 : "Registered",
    1 : "Awaiting Registration",
    100000002: "In Service",
    2 : "Inappropriate Referral",
    100000009 : "Initial Appt Cancelled",
    100000003 : "Completed",
    100000006 : "Decided to leave early",
    100000007 : "Other",
    100000005: "Stepped-up",
    # course status not available : 7
    None : "Course Status Not Available"
}

QUESTIONNAIRE_SESSION_COMPLETION_STATUS = {
    935000001 : "Completed"

}

INCOMING_REFERRAL_STATE_CODE = {
    0 : "Active",
    1 : "Inactive"
}

# referral stage mapping for outbound_referral
REFERRAL_STAGE = {
    100000001 : 0, # "Registered",
    1 : None, #"Awaiting Registration",
    100000002: 1, #"In Service",
    2 : None, #"Inappropriate Referral",
    100000009 : None,#"Initial Appt Cancelled",
    100000003 : 2,#"Completed",
    100000006 : None, #"Decided to leave early",
    100000007 : None, #"Other",
    100000005: 2, #"Stepped-up",
    # course status not available : 7
    None : None
}

# Left side is variable name, right side is string value from dataverse
IAR_DST_DOMAINS = {
    "IAR-DST - Domain 1" : "domain1",
    "IAR-DST - Domain 2" : "domain2",
    "IAR-DST - Domain 3" : "domain3",
    "IAR-DST - Domain 4" : "domain4",
    "IAR-DST - Domain 5" : "domain5",
    "IAR-DST - Domain 6" : "domain6",
    "IAR-DST - Domain 7" : "domain7",
    "IAR-DST - Domain 8" : "domain8"
}

# Below constants are the option set values and what they map to - use this as reference. The actual DOH mapping configuration is within the table script files
# mmhci_userconsent (table), statuscode (column name) - consent status from user consent table
USER_CONSENT_STATUS = {
    1 : "Consent Granted",
    100000000 : "Consent Declined",
    2 : "Consent Revoked"
}

USER_CONSENT_FLAG = {
    0 : "Active",
    1: "Inactive"
}

APPOINTMENT_TYPE = {
    935000000 : "Appointment",
    935000001 : "Module"
}

INTAKE_REGISTRATION_STATUS = {
    1 : "Registered",
    100000011 : "Draft",
    100000014 : "Require Data Missing - Cancelled",
    100000008 : "Awaiting Registration",
    100000012 : "Required Data Missing",
    100000002 : "Admin Review Required",
    100000003 : "Clinical Review Required",
    2 : "Inactive",
    100000007 : "Clinical Review Complete - Rejected",
    100000005 : "Admin Review Complete - Rejected"
}

INTAKE_REGISTRATION_STATUS_DOH_MAPPING = {
    1 : 1, #"Registered",
    100000011 : 0, #"Draft",
    100000014 : 0, #"Require Data Missing - Cancelled",
    100000008 : 0, #"Awaiting Registration",
    100000012 : 0, #"Required Data Missing",
    100000002 : 0, #"Admin Review Required",
    100000003 : 0, #"Clinical Review Required",
    2 : 0, #"Inactive",
    100000007 : 0, #"Clinical Review Complete - Rejected",
    100000005 : 0, #"Admin Review Complete - Rejected"
}

# for intake table
PRIVACY_CONSENT_STATUS = {
    0 : "Active",
    1: "Inactive"
}

# for IAR DST extraction logic
AGE_GROUP = {
    "15-25" : 2, 
    "Above 16" : 3,
    "adolescent" : 2, 
    "adult" :  3,
}

# Output file paths
OUTPUT_FOLDER = "output"