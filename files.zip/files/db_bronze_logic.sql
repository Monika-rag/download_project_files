SELECT *
FROM {{ source('your_source', 'assignment') }};

-- models/bronze_payment.sql
SELECT *
FROM {{ source('your_source', 'taskcombinedcosts') }};

-- models/bronze_order.sql
SELECT *
FROM {{ source('your_source', 'vnt_core_data_processing_history') }};



CREATE TABLE delta_table_name
USING DELTA
LOCATION 'abfss://<ADLS_ACCOUNT_NAME>@<ADLS_FILE_SYSTEM>.dfs.core.windows.net/<PATH_TO_FILE_OR_FOLDER>'
OPTIONS (
  format 'parquet', -- Specify the file format (e.g., parquet, csv, json, etc.)
  header 'true' -- Specify if the file(s) contain header row(s)
);