-- models/silver_deduplication.sql

-- This model performs deduplication on the silver layer data
-- Replace `my_silver_table` with the name of your silver layer table

WITH deduplicated_data_assign AS (
    SELECT
        *,
        ROW_NUMBER() OVER (PARTITION BY business_key01 ORDER BY ods_created_on DESC) AS row_num
    FROM
        {{ ref('bronze_assignment') }}
),

stg_assign as (

SELECT
    *
FROM
    deduplicated_data_assign
WHERE
    row_num = 1;
	
),	

WITH deduplicated_data_task AS (
    SELECT
        *,
        ROW_NUMBER() OVER (PARTITION BY business_key01 ORDER BY ods_created_on DESC) AS row_num
    FROM
        {{ ref('bronze_taskcombinedcosts') }}
),

stg_task as (

SELECT
    *
FROM
    deduplicated_data_task
WHERE
    row_num = 1;
	
),	

WITH deduplicated_data_processing AS (
    SELECT
        *,
        ROW_NUMBER() OVER (PARTITION BY business_key01 ORDER BY created_on DESC) AS row_num
    FROM
        {{ ref('bronze_vnt_core_data_processing_history') }}
)

stg_processing as (

SELECT
    *
FROM
    deduplicated_data_processing
WHERE
    row_num = 1;
	
)	

final as (

    select
        assign.ods_id,
        assign.processing_id,
        assign.processing_id_item,
        assign.ods_created_by,
        assign.ods_created_on,
        assign.ods_updated_by,
        assign.businesskey_01,
		assign.assignment_action,
        assign.assignment_destination,
		assign.assignment_messageid,
		assign.assignment_assignment_objecttype,
		task.taskcombinedcosts_action,
		task.taskcombinedcosts_messageid,
		task.taskcombinedcosts_task_key,
		task.taskcombinedcosts_task_number,
		procs.action,
		procs.object,
		procs.businesskey_mapping,
		procs.source_payload,
		procs.payload,
		procs.status,
		procs.batch_start_dt,
		procs.batch_end_dt,
		procs.archive_delete_schedule_datetime_AEST
		
		
    from stg_assign assign

    left join stg_task task 
        on assign.ods_id = task.ods_id and assign.business_key01 = task.business_key01

    left join stg_processing procs
        on  task.processing_id = procs.processing_id and task.business_key01 = procs.business_key01

)

select * from final
	