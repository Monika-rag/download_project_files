POC :

We have created a Bronze , silver , gold layer architecture Demo to build the ETL pipeline. Here we have created two notebooks , one for sql connection and extract the data from table and write it into file on adls Bronze layer then second notebook to read the Bronze layer data and apply column selection then write the data into sql warehouse for further processing. These two notebooks has one configuration file for all required parameters and we have create one job/worflow for these notebook tasks.

We have created two airflow Dags which are responsible to trigger the Bronze layer load and after that we can trigger the Silver and Gold layer DAG which is having call of DBT models. We have parameterized the airflow dags based on config file.

Silver layer DBT model is having the logic to remove the duplicate data and create a silver table in Sql warehouse and load the resulted data in delta format.(combination of schema + sql)

Gold layer DBT model is having the logic to aggreagate the data based on requirement and create a gold table in Sql warehouse and load the resulted data in delta format.(combination of schema + sql)

format of a file/table we can mention in schema file.


Delta tables are a key feature of Delta Lake, an open-source storage layer that brings ACID (Atomicity, Consistency, Isolation, Durability) transactions to Apache Spark and big data workloads. Delta tables provide several benefits for data management and analytics.


Airflow Monitoring :

After creating dags and placing them inside Dag folder we will see the Dags in Airflow UI. We can trigger the DAG directly and track the execution through the UI itself. It will show the sequence execution of the ETL process. We can schedule the DAG based on the requirement, for this we need to add this parameter in Dag script. We can rerun the Dag through UI as well it will start from failure point.We can directly see the logs through UI itself and also Airflow will store the logs inside logs folder.


