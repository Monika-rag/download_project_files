For Infrastructure setup we have installed Docker on our machine which we can do on VM as well and for this atleast we need 4GB RAM in our system to run the Docker images.

Airflow  :

Airflow is an open-source platform used to schedule, and monitor workflows programatically. It allows users to define workflows as Directed Acyclic Graphs (DAGs), where each node in the graph represents a task that can be executed independently. Airflow provides a rich set of features for managing dependencies between tasks, scheduling task execution, retrying tasks on failure, monitoring task status, and handling dynamic task generation.

DBT : 
"data build tool," is an open-source command-line tool which helps to transform data in the data warehouses using SQL. It is mainly for the transformation of data. dbt allows to write SQL queries to transform data directly within the data warehouse.dbt manages dependencies between different SQL files and models, ensuring that transformations are executed in the correct order based on their dependencies.dbt supports incremental processing, allows to efficiently update only the data that has changed since the last run. This helps reduce processing time and optimize data transformation pipelines.

Modularization and Reusability: dbt encourages modularization and reusability of code through the use of macros, reusable SQL snippets, and Jinja templating. This enables users to build and maintain scalable data transformation pipelines with ease.

We should have python on our machine and we can install python versin from 3.8 onwards, we have tested this setup with python 3.8 and 3.11

We have pulled the docker-compose.yml file for airflow which will have all the required configuration for this setup.

We can initialize airflow image which will create few containers for airflow to execute the DAGs. like webserver, scheduler, database etc and also creates few required directories like DAG where we can keep our dag files for execution.

We need to install the airflow databricks library inside container so that we can get the connection type as Databricks in our Airflow UI.

We have created a connection through UI for databricks by passing the connection id (unique name), databricks host url and token which will be invisible after saving the connection.

We have documented each and every step for this setup for future reference.

DBT : 
"data build tool," is an open-source command-line tool which helps to transform data in the data warehouses using SQL. It is mainly for the transformation of data. dbt allows to write SQL queries to transform data directly within the data warehouse.dbt manages dependencies between different SQL files and models, ensuring that transformations are executed in the correct order based on their dependencies.dbt supports incremental processing, allows to efficiently update only the data that has changed since the last run. This helps reduce processing time and optimize data transformation pipelines.

Modularization and Reusability: dbt encourages modularization and reusability of code through the use of macros, reusable SQL snippets, and Jinja templating. This enables users to build and maintain scalable data transformation pipelines with ease.

We have pulled the dbt-core image inside the docker and build this image for any required dependency.

Then run the dbt container by giving mount directories for the development purpose.

DBT creates few directories like seeds(we can keep the files through which we want to load the table), tests(keep the test sql files to check the not null or unique values) , models(all execution models should be store in this directory for execution).

We can trigger DBT models through DAG by creating a DAG file in airflow for this we need to add the DBT container and image details.
We can create table/view by using the DBT models.

We can write merge query as well if required.

