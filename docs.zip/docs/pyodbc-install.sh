#!/bin/bash

# Import Microsoft GPG key
curl https://packages.microsoft.com/keys/microsoft.asc | sudo apt-key add -

# Add Microsoft SQL Server repository to the list
curl https://packages.microsoft.com/config/ubuntu/22.04/prod.list | sudo tee /etc/apt/sources.list.d/mssql-release.list

# Update the package index
sudo apt-get update

# Install the Microsoft ODBC driver
sudo ACCEPT_EULA=Y apt-get -q -y install msodbcsql17