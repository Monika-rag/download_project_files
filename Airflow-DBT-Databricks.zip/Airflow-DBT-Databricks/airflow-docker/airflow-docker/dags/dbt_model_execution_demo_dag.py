#Required library import
from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.bash_operator import BashOperator
from airflow.operators.docker_operator import DockerOperator
from docker.types import Mount
import json

# Read the config file
config_file_path = '/opt/airflow/config/config.json'

# Load the JSON configuration file
with open(config_file_path, 'r') as f:
    config = json.load(f)
    
    
# Parse the retry_delay value and extract the numeric part
retry_delay = config['default_args']['retry_delay']

#Dag default arguments
default_args = {
    'owner': config['default_args']['owner'],
    'depends_on_past': config['default_args']['depends_on_past'],
    'email_on_failure': config['default_args']['email_on_failure'],
    'email_on_retry': config['default_args']['email_on_retry'],
    'retries': config['default_args']['retries'],
    'retry_delay': timedelta(minutes=retry_delay)
}
        

# Define your DAG using the configuration parameters
with DAG('dbt_model_execution_demo_dag',start_date = datetime.now(), default_args= default_args, schedule_interval= timedelta(minutes=5), catchup=False) as dag:

    Dag_start_task = BashOperator(
        task_id='Dag_Start_Date',
        bash_command='date'
    )

#Task for Silver model/layer execution
    Silver_layer_exec = DockerOperator(
        task_id='docker_silver_model_run',
        image= config['default_args']['image_name'],
        container_name= config['default_args']['container_name'],
        api_version= config['default_args']['api_version'],
        auto_remove= config['default_args']['auto_remove'],
        command= f"dbt run --model {config['default_args']['silver_model_file']}", 
        docker_url= config['default_args']['docker_url'],
        network_mode= config['default_args']['network_mode'],
        mounts=[
            Mount(
                source= config['default_args']['mnt_source_project'],
                target= config['default_args']['target_project'],
                type= config['default_args']['mnt_type'],
            ),
            Mount(
                source= config['default_args']['mnt_source_profiles'],
                target= config['default_args']['target_profiles'],
                type= config['default_args']['mnt_type'],
            )
        ],
        mount_tmp_dir=False
    )

#Task for Gold model/layer execution
    Gold_layer_exec = DockerOperator(
        task_id='docker_gold_model_run',
        image=config['default_args']['image_name'],
        container_name= config['default_args']['container_name'],
        api_version= config['default_args']['api_version'],
        auto_remove= config['default_args']['auto_remove'],
        command = f"dbt run --model {config['default_args']['gold_model_file']}",
        docker_url= config['default_args']['docker_url'],
        network_mode= config['default_args']['network_mode'],
        mounts=[
            Mount(
                source= config['default_args']['mnt_source_project'],
                target= config['default_args']['target_project'],
                type=config['default_args']['mnt_type'],
            ),
            Mount(
                source= config['default_args']['mnt_source_profiles'],
                target= config['default_args']['target_profiles'],
                type= config['default_args']['mnt_type'],
            )
        ],
        mount_tmp_dir=False
    )

#Define sequence of task execution/Dependency
    Dag_start_task >> Silver_layer_exec >> Gold_layer_exec