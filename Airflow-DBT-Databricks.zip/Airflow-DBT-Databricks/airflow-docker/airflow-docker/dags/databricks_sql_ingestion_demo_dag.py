#Required library import
import json
from airflow import DAG
from airflow.providers.databricks.operators.databricks import DatabricksRunNowOperator
from airflow.utils.dates import days_ago
from datetime import datetime, timedelta

# Read the config file
config_file_path = '/opt/airflow/config/config.json'

# Load the JSON configuration file
with open(config_file_path, 'r') as f:
    config = json.load(f)
    
    
# Parse the retry_delay value and extract the numeric part
retry_delay = config['default_args']['retry_delay']


# Dag default arguments
default_args = {
    'owner': config['default_args']['owner'],
    'depends_on_past': config['default_args']['depends_on_past'],
    'email_on_failure': config['default_args']['email_on_failure'],
    'email_on_retry': config['default_args']['email_on_retry'],
    'retries': config['default_args']['retries'],
    'retry_delay': timedelta(minutes=retry_delay)
}

# Define your DAG using the configuration parameters
with DAG('databricks_sql_ingestion_demo_dag',
  start_date = datetime.now(),
  schedule_interval = None,
  default_args = default_args,
  ) as dag:

#Databricks task creation
  SQL_Ingestion_Task = DatabricksRunNowOperator(
    task_id = 'SQL_Ingestion',
    databricks_conn_id = config['default_args']['databricks_conn_id'],
    job_id = config['default_args']['databricks_job_id']
  )