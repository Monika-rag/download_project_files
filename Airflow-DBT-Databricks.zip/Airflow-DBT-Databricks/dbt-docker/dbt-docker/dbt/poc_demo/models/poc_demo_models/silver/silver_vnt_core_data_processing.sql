-- This model performs deduplication on the bronze layer data and load the resulted data into silver table

{{ config(
    materialized= 'table',
	incremental_strategy= 'append',
    location_root = '/mnt/raw/ODS_POC/Silver'
) }}

WITH deduplicated_data_assign AS (
    SELECT
        *,
        ROW_NUMBER() OVER (PARTITION BY businesskey_01 ORDER BY ods_created_on DESC) AS row_num
    FROM
       {{ source('test_db','bronze_assignment') }}
),

stg_assign as (

SELECT
    *
FROM
    deduplicated_data_assign
WHERE
    row_num = 1
	
),	

deduplicated_data_task AS (
    SELECT
        *,
        ROW_NUMBER() OVER (PARTITION BY businesskey_01 ORDER BY ods_created_on DESC) AS row_num
    FROM
        {{ source('test_db','bronze_taskcombinedcosts') }}
),

stg_task as (

SELECT
    *
FROM
    deduplicated_data_task
WHERE
    row_num = 1
	
),	

deduplicated_data_processing AS (
    SELECT
        *,
        ROW_NUMBER() OVER (PARTITION BY businesskey_01 ORDER BY created_on DESC) AS row_num
    FROM
        {{ source('test_db','bronze_vnt_core_data_processing_history') }}
),

stg_processing as (

SELECT
    *
FROM
    deduplicated_data_processing
WHERE
    row_num = 1
	
),
silver_vnt_core_data_processing as (

    select
        assign.ods_id,
        assign.processing_id,
        assign.processing_id_item,
        assign.ods_created_by,
        assign.ods_created_on,
        assign.ods_updated_by,
        assign.businesskey_01,
		assign.assignment_action,
        assign.assignment_destination,
		assign.assignment_messageid,
		assign.assignment_assignment_objecttype,
		task.taskcombinedcosts_action,
		task.taskcombinedcosts_messageid,
		task.taskcombinedcosts_task_key,
		task.taskcombinedcosts_task_number,
		procs.action,
		procs.object,
		procs.businesskey_mapping,
		procs.source_payload,
		procs.payload,
		procs.status,
		procs.batch_start_dt,
		procs.batch_end_dt,
		procs.archive_delete_schedule_datetime_AEST
		
		
    from stg_assign assign

    left join stg_task task 
        on assign.ods_id = task.ods_id and assign.businesskey_01 = task.businesskey_01

    left join stg_processing procs
        on  task.processing_id = procs.processing_id and task.businesskey_01 = procs.businesskey_01

)

select * from silver_vnt_core_data_processing
	