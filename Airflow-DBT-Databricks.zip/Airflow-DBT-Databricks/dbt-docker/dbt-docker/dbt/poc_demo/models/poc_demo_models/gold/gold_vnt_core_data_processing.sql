---This model performs aggregation on the silver layer data and load the aggregated data into gold layer
{{ config(
    materialized= 'table',
	incremental_strategy= 'append',
    location_root= '/mnt/raw/ODS_POC/Gold'
) }}

WITH gold_vnt_core_data_processing as (

    SELECT
        slv.ods_id,
        slv.processing_id,
        slv.processing_id_item,
        slv.ods_created_by,
        slv.ods_created_on,
        slv.ods_updated_by,
        slv.businesskey_01,
		slv.assignment_action,
        slv.assignment_destination,
		slv.assignment_messageid,
		slv.assignment_assignment_objecttype,
		slv.taskcombinedcosts_action,
		slv.taskcombinedcosts_messageid,
		slv.taskcombinedcosts_task_key,
		slv.taskcombinedcosts_task_number,
		slv.action,
		slv.object,
		slv.businesskey_mapping,
		slv.source_payload,
		slv.payload,
		slv.status,
		slv.batch_start_dt,
		slv.batch_end_dt,
		slv.archive_delete_schedule_datetime_AEST,
    MAX(ods_created_on) AS ods_created_on_dt,
    COUNT(*) AS num_of_task
FROM
     {{  source('test_db','silver_vnt_core_data_processing') }} slv
GROUP BY
    ods_id,
    processing_id,
    businesskey_01,
	processing_id_item,
    ods_created_by,
    ods_created_on,
    ods_updated_by,
    businesskey_01,
	assignment_action,
    assignment_destination,
	assignment_messageid,
	assignment_assignment_objecttype,
	taskcombinedcosts_action,
	taskcombinedcosts_messageid,
	taskcombinedcosts_task_key,
	taskcombinedcosts_task_number,
	action,
	object,
	businesskey_mapping,
	source_payload,
	payload,
	status,
	batch_start_dt,
	batch_end_dt,
	archive_delete_schedule_datetime_AEST

)

select * from gold_vnt_core_data_processing