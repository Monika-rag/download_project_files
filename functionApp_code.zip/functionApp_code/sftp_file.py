import io
import logging
import posixpath

import paramiko
from azure.keyvault.secrets import SecretClient


class SftpService:
    """
    Service class responsible for SFTP operations.
    """

    def __init__(self, credential, key_vault_url: str):
        self.credential = credential
        self.key_vault_url = key_vault_url

        self.secret_client = SecretClient(
            vault_url=self.key_vault_url,
            credential=self.credential
        )

        self.sftp_host = self.secret_client.get_secret("sftp-host").value

        try:
            self.sftp_port = int(self.secret_client.get_secret("sftp-port").value)
        except Exception:
            self.sftp_port = 22

        self.sftp_username = self.secret_client.get_secret("sftp-username").value
        self.sftp_password = self.secret_client.get_secret("sftp-password").value

    def _ensure_remote_directory_exists(self, sftp, target_folder: str) -> None:
        """
        Creates SFTP target folder recursively if it does not exist.

        Example:
        /inbound/svha/2026/06/week02
        """

        if not target_folder or str(target_folder).strip() == "":
            raise ValueError("target_folder is required.")

        target_folder = target_folder.strip().replace("\\", "/")

        if target_folder == "/":
            return

        folders = target_folder.strip("/").split("/")
        current_path = ""

        if target_folder.startswith("/"):
            current_path = "/"

        for folder in folders:
            if current_path == "/":
                current_path = posixpath.join(current_path, folder)
            else:
                current_path = posixpath.join(current_path, folder)

            try:
                sftp.stat(current_path)
                logging.info("SFTP directory already exists: %s", current_path)
            except FileNotFoundError:
                logging.info("Creating SFTP directory: %s", current_path)
                sftp.mkdir(current_path)

    def upload_bytes(
        self,
        file_content: bytes,
        target_folder: str,
        file_name: str,
        create_target_folder: bool = False,
        overwrite: bool = True
    ) -> dict:
        """
        Uploads byte content to SFTP target folder.

        If create_target_folder=True:
        - creates target folder recursively if missing.

        If overwrite=False:
        - fails if target file already exists.
        """

        transport = None
        sftp = None

        target_folder = target_folder.strip().replace("\\", "/")
        target_file_path = posixpath.join(target_folder, file_name)

        try:
            logging.info("Connecting to SFTP server: %s:%s", self.sftp_host, self.sftp_port)

            transport = paramiko.Transport((self.sftp_host, self.sftp_port))
            transport.connect(
                username=self.sftp_username,
                password=self.sftp_password
            )

            sftp = paramiko.SFTPClient.from_transport(transport)

            if create_target_folder:
                self._ensure_remote_directory_exists(
                    sftp=sftp,
                    target_folder=target_folder
                )

            if not overwrite:
                try:
                    sftp.stat(target_file_path)
                    raise FileExistsError(f"SFTP file already exists: {target_file_path}")
                except FileNotFoundError:
                    pass

            logging.info("Uploading file to SFTP path: %s", target_file_path)

            with io.BytesIO(file_content) as file_stream:
                sftp.putfo(file_stream, target_file_path)

            uploaded_file_size = sftp.stat(target_file_path).st_size

            if uploaded_file_size != len(file_content):
                raise ValueError(
                    f"SFTP upload size validation failed for {target_file_path}. "
                    f"Source size: {len(file_content)}, Uploaded size: {uploaded_file_size}"
                )

            logging.info("SFTP upload completed: %s", target_file_path)

            return {
                "file_name": file_name,
                "sftp_path": target_file_path,
                "source_size_bytes": len(file_content),
                "uploaded_size_bytes": uploaded_file_size,
                "status": "uploaded"
            }

        finally:
            if sftp:
                sftp.close()

            if transport:
                transport.close()

            logging.info("SFTP connection closed.")