# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {}
# META }

# CELL ********************

# ============================================================
# File    : practitioner_dataverse_spn.py
# Purpose : Fetch Practitioner data from Dataverse using SPN,
#           transform it, and write output to Fabric Lakehouse
# ============================================================

import json
import logging
import os
from datetime import datetime
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd
import requests


# ============================================================
# 1. Runtime parameters
# ============================================================

# In Fabric Notebook, you can override these as notebook parameters.
KEY_VAULT_URL = "https://kv-crm-mmhci-tst-ae-01.vault.azure.net/"
#sp-fabric-to-dataverse-si
TENANT_ID_SECRET_NAME = "dataverse-tenant-id"
CLIENT_ID_SECRET_NAME = "dataverse-client-id"
CLIENT_SECRET_SECRET_NAME = "dataverse-client-secret"
DATAVERSE_URL_SECRET_NAME = "dataverse-url"

OUTPUT_LAKEHOUSE_FOLDER = "Files/processed/Dataverse/practitioner"
OUTPUT_TABLE_NAME = "edap_practitioner"

# If you want CSV output also
WRITE_CSV_OUTPUT = True

# If you want Lakehouse Delta table output also
WRITE_DELTA_TABLE = True


# ============================================================
# 2. Practitioner transformation constants
#    Adapted from your attached tables/practitioner.py
# ============================================================

ORGANISATION_ID = "SVHA-MMHCI"

TABLES = {
    "bookable_resource": "bookableresources",
    "system_user": "systemusers",
    "role": "roles",
    "system_user_roles": "systemuserrolescollection"
}

CATEGORY_DEFAULT = 99
ABORIGINAL_AND_TORRES_STRAIT_ISLANDER_CULTURAL_TRAINING_DEFAULT = 8
COMPLETED_MENTAL_HEALTH_FIRST_AID_TRAINING_DEFAULT = 8
ACTIVE_DEFAULT = 1
LEVEL_OF_CLINICAL_QUALIFICATION_DEFAULT = None
YEAR_OF_QUALIFICATION_DEFAULT = None
EMPLOYMENT_START_DEFAULT = "2026-03-30"
EMPLOYMENT_END_DEFAULT = None

BOOKABLE_RESOURCE_COLUMNS = ["bookableresourceid", "_userid_value"]
SYSTEM_USER_COLUMNS = ["systemuserid", "organizationid"]
SYSTEM_USER_ROLE_COLUMNS = ["systemuserid", "roleid", "systemuserroleid"]
ROLE_COLUMNS = ["roleid", "name"]

BOOKABLE_RESOURCE_KEY = "_userid_value"
SYSTEM_USER_KEY = "systemuserid"
SYSTEM_USER_ROLE_KEY = "systemuserid"

DEFAULT_COLUMN_VALUES = {
    "Category": CATEGORY_DEFAULT,
    "Aboriginal and Torres Strait Islander cultural training": ABORIGINAL_AND_TORRES_STRAIT_ISLANDER_CULTURAL_TRAINING_DEFAULT,
    "Completed Mental Health First Aid training": COMPLETED_MENTAL_HEALTH_FIRST_AID_TRAINING_DEFAULT,
    "Active": ACTIVE_DEFAULT,
    "Level of clinical qualification": LEVEL_OF_CLINICAL_QUALIFICATION_DEFAULT,
    "Year of qualification": YEAR_OF_QUALIFICATION_DEFAULT,
    "Employment start": EMPLOYMENT_START_DEFAULT,
    "Employment end": EMPLOYMENT_END_DEFAULT,
    "Year of birth": None,
    "Sex": None,
    "Gender": None,
    "Variations of sex characteristics": None,
    "Sexual orientation": None,
    "Aboriginal and Torres Strait Islander status": None,
    "Language spoken": None,
    "Experience assisting with mental ill-health episodes prior to working on program": None,
    "organizationid": ORGANISATION_ID,
}

FINAL_COLUMNS_MAPPING = {
    "bookableresourceid": "Staff key",
    "organizationid": "Service provider organisation key",
    "systemuserid": "Base staff key",
    "Category": "Category",
    "name": "Clinical role",
    "Aboriginal and Torres Strait Islander cultural training": "Aboriginal and Torres Strait Islander cultural training",
    "Completed Mental Health First Aid training": "Completed Mental Health First Aid training",
    "Year of birth": "Year of birth",
    "Sex": "Sex",
    "Gender": "Gender",
    "Variations of sex characteristics": "Variations of sex characteristics",
    "Sexual orientation": "Sexual orientation",
    "Aboriginal and Torres Strait Islander status": "Aboriginal and Torres Strait Islander status",
    "Language spoken": "Language spoken",
    "Experience assisting with mental ill-health episodes prior to working on program": "Experience assisting with mental ill-health episodes prior to working on program",
    "Active": "Active",
    "Level of clinical qualification": "Level of clinical qualification",
    "Year of qualification": "Year of qualification",
    "Employment start": "Employment start",
    "Employment end": "Employment end",
}


# ============================================================
# 3. Logging
# ============================================================

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)

logger = logging.getLogger("practitioner_dataverse_spn")


# ============================================================
# 4. Secret handling
# ============================================================

def get_secret_from_key_vault(vault_url: str, secret_name: str) -> str:
    """
    Gets a secret from Azure Key Vault in Fabric.

    Preferred in Fabric:
    notebookutils.credentials.getSecret(vault_url, secret_name)

    Fallback:
    azure-keyvault-secrets + azure-identity if available.
    """

    try:
        # Fabric NotebookUtils path
        from notebookutils import mssparkutils

        secret_value = mssparkutils.credentials.getSecret(vault_url, secret_name)
        if secret_value:
            return secret_value

    except Exception as fabric_secret_error:
        logger.warning(
            "Could not read secret using notebookutils. Trying Azure SDK. Error: %s",
            str(fabric_secret_error)
        )

    try:
        from azure.identity import DefaultAzureCredential
        from azure.keyvault.secrets import SecretClient

        credential = DefaultAzureCredential()
        secret_client = SecretClient(vault_url=vault_url, credential=credential)

        return secret_client.get_secret(secret_name).value

    except Exception as azure_sdk_error:
        raise RuntimeError(
            f"Failed to retrieve secret '{secret_name}' from Key Vault. "
            f"Please check Key Vault URL, permissions, and Fabric identity access. "
            f"Error: {str(azure_sdk_error)}"
        )


# ============================================================
# 5. Dataverse authentication
# ============================================================

def get_dataverse_access_token(
    tenant_id: str,
    client_id: str,
    client_secret: str,
    dataverse_url: str
) -> str:
    """
    Gets OAuth token for Dataverse using SPN/client credentials.
    """

    token_url = f"https://login.microsoftonline.com/{tenant_id}/oauth2/v2.0/token"

    payload = {
        "client_id": client_id,
        "client_secret": client_secret,
        "grant_type": "client_credentials",
        "scope": f"{dataverse_url.rstrip('/')}/.default"
    }

    response = requests.post(token_url, data=payload, timeout=60)

    if response.status_code != 200:
        raise RuntimeError(
            f"Failed to get Dataverse token. "
            f"Status={response.status_code}, Response={response.text}"
        )

    return response.json()["access_token"]


# ============================================================
# 6. Dataverse Web API fetch with pagination
# ============================================================

def fetch_dataverse_records(
    dataverse_url: str,
    access_token: str,
    entity_set_name: str,
    select_columns: Optional[List[str]] = None,
    filter_query: Optional[str] = None,
    page_size: int = 5000
) -> List[Dict[str, Any]]:
    """
    Fetches all records from a Dataverse table/entity set using Web API.
    Handles @odata.nextLink pagination.
    """

    dataverse_url = dataverse_url.rstrip("/")

    query_parts = []

    if select_columns:
        query_parts.append("$select=" + ",".join(select_columns))

    if filter_query:
        query_parts.append("$filter=" + filter_query)

    query_string = "&".join(query_parts)

    if query_string:
        url = f"{dataverse_url}/api/data/v9.2/{entity_set_name}?{query_string}"
    else:
        url = f"{dataverse_url}/api/data/v9.2/{entity_set_name}"

    headers = {
        "Authorization": f"Bearer {access_token}",
        "Accept": "application/json",
        "OData-MaxVersion": "4.0",
        "OData-Version": "4.0",
        "Content-Type": "application/json",
        "Prefer": f"odata.maxpagesize={page_size}"
    }

    all_records: List[Dict[str, Any]] = []

    while url:
        logger.info("Fetching Dataverse URL: %s", url)

        response = requests.get(url, headers=headers, timeout=120)

        if response.status_code != 200:
            raise RuntimeError(
                f"Dataverse fetch failed for entity '{entity_set_name}'. "
                f"Status={response.status_code}, Response={response.text}"
            )

        payload = response.json()
        records = payload.get("value", [])

        all_records.extend(records)

        url = payload.get("@odata.nextLink")

    logger.info(
        "Fetched %s records from Dataverse entity set '%s'",
        len(all_records),
        entity_set_name
    )

    return all_records


# ============================================================
# 7. DataFrame helper functions
# ============================================================

def remove_metadata_columns(df: pd.DataFrame) -> pd.DataFrame:
    """
    Removes OData metadata columns returned by Dataverse.
    """

    if df.empty:
        return df

    return df.loc[:, ~df.columns.str.startswith("@")]


def require_columns(df: pd.DataFrame, required_columns: List[str], table_name: str) -> None:
    """
    Validates required columns exist.
    """

    missing_columns = [column for column in required_columns if column not in df.columns]

    if missing_columns:
        raise KeyError(
            f"Missing required columns in table '{table_name}': {missing_columns}. "
            f"Available columns: {df.columns.tolist()}"
        )


def select_columns_dataframe(df: pd.DataFrame, columns_to_keep: List[str]) -> pd.DataFrame:
    """
    Selects required columns safely after removing metadata columns.
    """

    if df.empty:
        return df

    df_clean = remove_metadata_columns(df)

    existing_columns = [column for column in columns_to_keep if column in df_clean.columns]

    return df_clean[existing_columns].copy()


def select_and_rename_columns(df: pd.DataFrame, columns_mapping: Dict[str, str]) -> pd.DataFrame:
    """
    Selects and renames final columns.
    Adds missing columns as null so export does not fail.
    """

    df_clean = remove_metadata_columns(df)

    for source_column in columns_mapping.keys():
        if source_column not in df_clean.columns:
            df_clean[source_column] = None

    df_selected = df_clean[list(columns_mapping.keys())].copy()

    return df_selected.rename(columns=columns_mapping)


# ============================================================
# 8. Practitioner transformation
# ============================================================

def process_practitioner_from_dataverse(
    dataverse_url: str,
    access_token: str
) -> pd.DataFrame:
    """
    Fetches dependent Dataverse tables and prepares Practitioner output.
    """

    logger.info("Fetching dependent Dataverse tables for Practitioner...")

    bookable_resource_records = fetch_dataverse_records(
        dataverse_url=dataverse_url,
        access_token=access_token,
        entity_set_name=TABLES["bookable_resource"],
        select_columns=BOOKABLE_RESOURCE_COLUMNS
    )

    system_user_records = fetch_dataverse_records(
        dataverse_url=dataverse_url,
        access_token=access_token,
        entity_set_name=TABLES["system_user"],
        select_columns=SYSTEM_USER_COLUMNS
    )

    role_records = fetch_dataverse_records(
        dataverse_url=dataverse_url,
        access_token=access_token,
        entity_set_name=TABLES["role"],
        select_columns=ROLE_COLUMNS
    )

    system_user_role_records = fetch_dataverse_records(
        dataverse_url=dataverse_url,
        access_token=access_token,
        entity_set_name=TABLES["system_user_roles"],
        select_columns=SYSTEM_USER_ROLE_COLUMNS
    )

    logger.info("Converting records to Pandas DataFrames...")

    df_bookable_resource = pd.DataFrame(bookable_resource_records)
    df_system_user = pd.DataFrame(system_user_records)
    df_roles = pd.DataFrame(role_records)
    df_system_user_roles = pd.DataFrame(system_user_role_records)

    logger.info("bookable_resource rows: %s", len(df_bookable_resource))
    logger.info("system_user rows: %s", len(df_system_user))
    logger.info("roles rows: %s", len(df_roles))
    logger.info("system_user_roles rows: %s", len(df_system_user_roles))

    require_columns(
        df_bookable_resource,
        BOOKABLE_RESOURCE_COLUMNS,
        TABLES["bookable_resource"]
    )

    require_columns(
        df_system_user,
        SYSTEM_USER_COLUMNS,
        TABLES["system_user"]
    )

    logger.info("Selecting required columns...")

    df_bookable_resource_clean = select_columns_dataframe(
        df_bookable_resource,
        BOOKABLE_RESOURCE_COLUMNS
    )

    df_system_user_clean = select_columns_dataframe(
        df_system_user,
        SYSTEM_USER_COLUMNS
    )

    df_system_user_roles_clean = select_columns_dataframe(
        df_system_user_roles,
        SYSTEM_USER_ROLE_COLUMNS
    )

    df_role_clean = select_columns_dataframe(
        df_roles,
        ROLE_COLUMNS
    )

    logger.info("Merging Practitioner dependent tables...")

    df_merged = df_bookable_resource_clean.merge(
        df_system_user_clean,
        how="left",
        left_on=BOOKABLE_RESOURCE_KEY,
        right_on=SYSTEM_USER_KEY
    )

    df_merged = df_merged.merge(
        df_system_user_roles_clean,
        how="left",
        left_on=SYSTEM_USER_KEY,
        right_on=SYSTEM_USER_ROLE_KEY
    )

    df_merged = df_merged.merge(
        df_role_clean,
        how="left",
        left_on="roleid",
        right_on="roleid"
    )

    logger.info("Applying default values...")

    df_merged = df_merged.assign(**DEFAULT_COLUMN_VALUES)

    logger.info("Selecting and renaming final Practitioner columns...")

    df_final = select_and_rename_columns(df_merged, FINAL_COLUMNS_MAPPING)

    logger.info("Applying Clinical role mapping...")

    df_final["Clinical role"] = np.select(
        [
            df_final["Clinical role"] == "Practitioner",
            df_final["Clinical role"] == "Leader"
        ],
        [
            1,
            3
        ],
        default=None
    )

    df_final = df_final.drop_duplicates()

    logger.info("Practitioner final rows: %s", len(df_final))

    return df_final


# ============================================================
# 9. Write output to Fabric Lakehouse
# ============================================================

def write_output_to_lakehouse(df: pd.DataFrame) -> None:
    """
    Writes output to Fabric Lakehouse Files and/or Delta table.
    """

    timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")

    if WRITE_CSV_OUTPUT:
        output_folder = f"{OUTPUT_LAKEHOUSE_FOLDER}/run_{timestamp}"
        output_file_path = f"{output_folder}/Practitioner.csv"

        logger.info("Writing CSV output to: %s", output_file_path)

        # In Fabric notebook, pandas can write to Lakehouse Files path directly
        # if the Lakehouse is attached.
        os.makedirs(output_folder, exist_ok=True)
        df.to_csv(output_file_path, index=False, encoding="utf-8")

        logger.info("CSV write completed.")

    if WRITE_DELTA_TABLE:
        logger.info("Writing Delta table: %s", OUTPUT_TABLE_NAME)

        spark_df = spark.createDataFrame(df)

        (
            spark_df.write
            .format("delta")
            .mode("overwrite")
            .option("overwriteSchema", "true")
            .saveAsTable(OUTPUT_TABLE_NAME)
        )

        logger.info("Delta table write completed.")


# ============================================================
# 10. Main execution
# ============================================================

def main() -> None:
    logger.info("Starting Practitioner Dataverse SPN extraction in Fabric...")

    tenant_id = get_secret_from_key_vault(KEY_VAULT_URL, TENANT_ID_SECRET_NAME)
    client_id = get_secret_from_key_vault(KEY_VAULT_URL, CLIENT_ID_SECRET_NAME)
    client_secret = get_secret_from_key_vault(KEY_VAULT_URL, CLIENT_SECRET_SECRET_NAME)
    dataverse_url = get_secret_from_key_vault(KEY_VAULT_URL, DATAVERSE_URL_SECRET_NAME).rstrip("/")

    logger.info("Secrets retrieved successfully from Key Vault.")
    logger.info("Dataverse URL: %s", dataverse_url)

    access_token = get_dataverse_access_token(
        tenant_id=tenant_id,
        client_id=client_id,
        client_secret=client_secret,
        dataverse_url=dataverse_url
    )

    logger.info("Dataverse access token acquired successfully.")

    df_practitioner = process_practitioner_from_dataverse(
        dataverse_url=dataverse_url,
        access_token=access_token
    )

    write_output_to_lakehouse(df_practitioner)

    result = {
        "status": "success",
        "table": "Practitioner",
        "rows_written": int(len(df_practitioner)),
        "output_table": OUTPUT_TABLE_NAME,
        "csv_output_enabled": WRITE_CSV_OUTPUT,
        "delta_output_enabled": WRITE_DELTA_TABLE
    }

    logger.info("Practitioner processing completed successfully.")
    print(json.dumps(result, indent=2))

    try:
        notebookutils.notebook.exit(json.dumps(result))
    except Exception:
        pass


main()


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
