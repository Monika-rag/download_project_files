# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "jupyter",
# META     "jupyter_kernel_name": "python3.12"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "2a4f1954-6c84-4327-9d1b-5090e493e152",
# META       "default_lakehouse_name": "lh_mmhci_datahub_dev",
# META       "default_lakehouse_workspace_id": "1ba3ebd5-d835-4cdc-85d9-80feb379778e",
# META       "known_lakehouses": [
# META         {
# META           "id": "2a4f1954-6c84-4327-9d1b-5090e493e152"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

import pandas as pd

TABLE_NAME = "IARDSTassessment"

# Constant values
ORGANISATION_ID = "SVHA-MMHCI-01"

# Left side is variable name, right side is string value from dataverse
IAR_DST_DOMAINS = {
    "IAR-DST - Domain 1" : "domain1",
    "IAR-DST - Domain 2" : "domain2",
    "IAR-DST - Domain 3" : "domain3",
    "IAR-DST - Domain 4" : "domain4",
    "IAR-DST - Domain 5" : "domain5",
    "IAR-DST - Domain 6" : "domain6",
    "IAR-DST - Domain 7" : "domain7",
    "IAR-DST - Domain 8" : "domain8"
}

# IMPORTANT:
CONSENT_PROVIDED = "D0FA4878-5B14-F111-8341-000D3A794D28"

# for IAR DST extraction logic
AGE_GROUP = {
    "15-25" : 2, 
    "Above 16" : 3,
    "adolescent" : 2, 
    "adult" :  3,
}

# Lakehouse paths
RAW_BASE_PATH = "/lakehouse/default/Files/raw/Dataverse/05/2026/iar_dst"
PROCESSED_BASE_PATH = "/lakehouse/default/Files/processed/Dataverse/05/2026"

# Input file paths
INCOMING_REFERRAL_FILE = f"{RAW_BASE_PATH}/mmhci_incomingreferral.parquet"
USER_CONSENT_FILE = f"{RAW_BASE_PATH}/mmhci_userconsent.parquet"
QUESTIONNAIRE_RESPONSE = f"{RAW_BASE_PATH}/msemr_questionnaireresponse.parquet"
QUESTIONNAIRE_RESPONSE_ITEM_ANSWER = f"{RAW_BASE_PATH}/msemr_questionnaireresponseitemanswer.parquet"

# Output file path
OUTPUT_FILE = f"{PROCESSED_BASE_PATH}/{TABLE_NAME}.csv"

def select_columns_dataframe(df: pd.DataFrame, columns_to_keep: list) -> pd.DataFrame:
    """
    Clean the DataFrame by removing metadata columns and selecting specific columns.

    Parameters:
        df (pd.DataFrame): Input DataFrame.
        columns_to_keep (list): List of columns to retain.

    Returns:
        pd.DataFrame: Cleaned DataFrame with selected columns.
    """
    if df.empty:
        return df
    # Remove metadata columns (e.g., columns starting with "@")
    df_clean = df.loc[:, ~df.columns.str.startswith("@")]
    # Select only the specified columns
    return df_clean[[col for col in columns_to_keep if col in df_clean.columns]]

def select_and_rename_columns(df: pd.DataFrame, columns_mapping: dict) -> pd.DataFrame:
    """
    Select and rename columns in a DataFrame

    Parameters:
        df (pd.DataFrame): Input DataFrame.
        columns_mapping (dict): Dictionary mapping old column names to new column names

    Returns:
        pd.DataFrame: DataFrame with selected and renamed columns
    """
    if df.empty:
        return df
    
    # Remove metadata columns (e.g., columns starting with "@")
    df = df.loc[:, ~df.columns.str.startswith("@")]
    # Select columns based on keys in the mapping
    selected_columns = list(columns_mapping.keys())
    df_selected = df[selected_columns]
    # Rename columns based on the mapping
    df_renamed = df_selected.rename(columns=columns_mapping)
    return df_renamed

def read_lakehouse_file(file_path: str) -> pd.DataFrame:
    """
    Read a Lakehouse file into a pandas DataFrame.
    Supports parquet and csv input files.
    """
    if file_path.lower().endswith(".parquet"):
        return pd.read_csv(file_path)
    return pd.read_csv(file_path)

def process_iar_dst_table():
    """
    Process the Client Table by combining data from multiple dependent tables.

    Parameters:

    Returns:
        pd.DataFrame: Processed Client Table.
    """
    # Step 1: Read data from dependent Lakehouse files
    try:
        df_incoming_referral = read_lakehouse_file(INCOMING_REFERRAL_FILE)
        df_user_consent = read_lakehouse_file(USER_CONSENT_FILE)
        df_questionnaire_response = read_lakehouse_file(QUESTIONNAIRE_RESPONSE)
        df_questionnaire_response_item_answer = read_lakehouse_file(QUESTIONNAIRE_RESPONSE_ITEM_ANSWER)
    except Exception as e:
        print(f"Error reading dependent files: {e}")
        raise
    
    # filter incoming_referral to active
    df_incoming_referral = df_incoming_referral[df_incoming_referral["statecode"]== 0] # 0: Active


    # Select columns
    df_incoming_referral_clean = select_columns_dataframe(
        df_incoming_referral,
        [
            "mmhci_incomingreferralid",
            "mmhci_intakekey",
            "mmhci_useofothermentalhealthservice",
            "mmhci_iardstrecommendedlevelofcare",
            "mmhci_organisationid",
            "mmhci_iardstpractitionerlevelofcare",
            "mmhci_personid"
        ],
    )
    df_questionnaire_response_clean = select_columns_dataframe(
        df_questionnaire_response,
        [
            "mmhci_responsedate",
            "mmhci_incomingreferralid",
            "msemr_questionnaireresponseid",
            "mmhci_agegroup",
        ],
    )
    df_questionnaire_response_item_answer_clean = select_columns_dataframe(
        df_questionnaire_response_item_answer,
        [
            "msemr_valueinteger",
            "mmhci_questionnaireresponse",
            "mmhci_measurekey",
        ],
    )

    df_user_consent_clean = select_and_rename_columns(
        df_user_consent,
        {
            "mmhci_personid" : "user_consent_personid",
            "mmhci_consentpurposeid" : "_mmhci_consentpurposeid_value",
            "statuscode" : "user_consent_statuscode"
        }
    )
    
    df_questionnaire_response_clean["mmhci_responsedate"] = pd.to_datetime(
        df_questionnaire_response_clean["mmhci_responsedate"], errors="coerce"
    )

    df_questionnaire_response_item_answer_clean["msemr_valueinteger"] = (
        df_questionnaire_response_item_answer_clean["msemr_valueinteger"].astype(
            "Int64"
        )
    )

    # Get latest questionnaire response per incoming referral ---
    df_latest_response = df_questionnaire_response_clean.sort_values(
        ["mmhci_incomingreferralid", "mmhci_responsedate"]
    ).drop_duplicates(subset=["mmhci_incomingreferralid"], keep="last")

    # Pivot item answers into domain columns (one row per response id) ---
    domain_measurekeys = set(IAR_DST_DOMAINS.values())
    measurekey_to_domaincol = {
        v: k for k, v in IAR_DST_DOMAINS.items()
    }  # reverse mapping

    df_item = df_questionnaire_response_item_answer_clean[
        df_questionnaire_response_item_answer_clean["mmhci_measurekey"].isin(
            domain_measurekeys
        )
    ].copy()

    df_item["domain_col"] = df_item["mmhci_measurekey"].map(measurekey_to_domaincol)

    df_domains_wide = df_item.pivot_table(
        index="mmhci_questionnaireresponse",
        columns="domain_col",
        values="msemr_valueinteger",
        aggfunc="first",  # if duplicates exist, take first non-null
    ).reset_index()

    # Merge referral + latest response + pivoted domains ---
    df_merged = df_incoming_referral_clean.merge(
        df_latest_response,
        how="left",
        left_on="mmhci_incomingreferralid",
        right_on="mmhci_incomingreferralid",
    ).merge(
        df_domains_wide,
        how="left",
        left_on="msemr_questionnaireresponseid",
        right_on="mmhci_questionnaireresponse",
    )
    df_merged = df_merged.merge(
        df_user_consent_clean,
        how="left",
        left_on="mmhci_personid",
        right_on="user_consent_personid"
    )

    # Step 4.5: Filter one help seekers that have provided consent for data collection
    df_merged = df_merged[df_merged["user_consent_statuscode"] == 1]  #check consent has been granted (1=consent granted)
    df_merged = df_merged[df_merged["_mmhci_consentpurposeid_value"]== CONSENT_PROVIDED] # Privacy, collection notice and terms of use (GUID)

    # Drop rows where incoming referral id is missing because it's a PK
    df_merged = df_merged.dropna(subset=["mmhci_incomingreferralid"])

    # Ensure all domain columns exist else create them
    for col in IAR_DST_DOMAINS.keys():
        if col not in df_merged.columns:
            df_merged[col] = pd.NA

    # default value: 1: Other phone services
    df_merged["mmhci_useofothermentalhealthservice"] = 1

    # drop duplicate intake keys
    df_merged = df_merged.drop_duplicates(
        subset="mmhci_incomingreferralid", keep="last"
    )

    # if iar derived/practitioner level of care is 9 then set to None.
    df_merged["mmhci_iardstpractitionerlevelofcare"] = df_merged[
        "mmhci_iardstpractitionerlevelofcare"
    ].replace(9, pd.NA)

    # age group extraction logic
    df_merged["mmhci_agegroup"] = df_merged["mmhci_agegroup"].map(AGE_GROUP)

    df_merged["mmhci_organisationid"] = ORGANISATION_ID

    # date format conversion
    df_merged["mmhci_responsedate"] = pd.to_datetime(
        df_merged["mmhci_responsedate"]
    ).dt.strftime("%Y-%m-%d")

    # Constant default variables for columns
    IAR_DST_PRACTITIONER_OVERRIDE_LEVEL_OF_CARE = None  # Default to blank

    # Mapping of the default values and additional columns
    DEFAULT_COLUMN_VALUES = {
        "IAR-DST - Practitioner override level of care": IAR_DST_PRACTITIONER_OVERRIDE_LEVEL_OF_CARE,
    }

    df_merged["mmhci_agegroup"] = df_merged["mmhci_agegroup"].astype("Int64")
    df_merged["IAR-DST - Domain 1"] = df_merged["IAR-DST - Domain 1"].astype("Int64")
    df_merged["IAR-DST - Domain 2"] = df_merged["IAR-DST - Domain 2"].astype("Int64")
    df_merged["IAR-DST - Domain 3"] = df_merged["IAR-DST - Domain 3"].astype("Int64")
    df_merged["IAR-DST - Domain 4"] = df_merged["IAR-DST - Domain 4"].astype("Int64")
    df_merged["IAR-DST - Domain 5"] = df_merged["IAR-DST - Domain 5"].astype("Int64")
    df_merged["IAR-DST - Domain 6"] = df_merged["IAR-DST - Domain 6"].astype("Int64")
    df_merged["IAR-DST - Domain 7"] = df_merged["IAR-DST - Domain 7"].astype("Int64")
    df_merged["IAR-DST - Domain 8"] = df_merged["IAR-DST - Domain 8"].astype("Int64")
    df_merged["mmhci_iardstpractitionerlevelofcare"] = df_merged["mmhci_iardstpractitionerlevelofcare"].astype("Int64")

    df_merged = df_merged.assign(**DEFAULT_COLUMN_VALUES)

    # use iardst recommended level of care if practitioner level of care is blank , else blank
    df_merged["mmhci_iardstpractitionerlevelofcare"] = (
        df_merged["mmhci_iardstpractitionerlevelofcare"]
        .replace("", pd.NA)
        .combine_first(df_merged["mmhci_iardstrecommendedlevelofcare"])
    )

    # derived level of care = practiitoner level of care else recommended level of care
    df_merged["derived_level_of_care"] = (
        df_merged["mmhci_iardstpractitionerlevelofcare"]
        .astype("string")
        .str.strip()
        .replace("", pd.NA)
        .combine_first(df_merged["mmhci_iardstrecommendedlevelofcare"])
        .astype("Int64")
    )

    columns_mapping = {
        "mmhci_incomingreferralid": "Intake key",
        "mmhci_organisationid": "Service provider organisation key",
        "mmhci_useofothermentalhealthservice": "Assessment provider",
        "mmhci_responsedate": "Assessment date",
        "mmhci_agegroup": "IAR-DST - Version",
        "IAR-DST - Domain 1": "IAR-DST - Domain 1",
        "IAR-DST - Domain 2": "IAR-DST - Domain 2",
        "IAR-DST - Domain 3": "IAR-DST - Domain 3",
        "IAR-DST - Domain 4": "IAR-DST - Domain 4",
        "IAR-DST - Domain 5": "IAR-DST - Domain 5",
        "IAR-DST - Domain 6": "IAR-DST - Domain 6",
        "IAR-DST - Domain 7": "IAR-DST - Domain 7",
        "IAR-DST - Domain 8": "IAR-DST - Domain 8",
        "mmhci_iardstrecommendedlevelofcare": "IAR-DST - Recommended level of care",
        "mmhci_iardstpractitionerlevelofcare": "IAR-DST - Practitioner override level of care",
        "derived_level_of_care": "IAR-DST - Derived level of care",
    }
    df_merged = select_and_rename_columns(df_merged, columns_mapping)
    df_merged["Assessment date"] = df_merged["Assessment date"].fillna("")

    # Step 7: Export processed output to CSV
    df_merged.to_csv(OUTPUT_FILE, index=False)

    return df_merged

process_iar_dst_table()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "jupyter_python"
# META }

# CELL ********************


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "jupyter_python"
# META }
