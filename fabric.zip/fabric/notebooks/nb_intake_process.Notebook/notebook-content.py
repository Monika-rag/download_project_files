# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "jupyter",
# META     "jupyter_kernel_name": "python3.12"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "2a4f1954-6c84-4327-9d1b-5090e493e152",
# META       "default_lakehouse_name": "lh_mmhci_datahub_dev",
# META       "default_lakehouse_workspace_id": "1ba3ebd5-d835-4cdc-85d9-80feb379778e",
# META       "known_lakehouses": [
# META         {
# META           "id": "2a4f1954-6c84-4327-9d1b-5090e493e152"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

# Table name for file export
TABLE_NAME = "Intake"

# Constant values
ORGANISATION_ID = "SVHA-MMHCI-01"
CONSENT_PROVIDED = "d0fa4878-5b14-f111-8341-000d3a794d28"
INTAKE_REGISTRATION_STATUS_DOH_MAPPING = {
}

SUICIDAL_REFERRAL_FLAG_DEFAULT = 3  # Unknown
USER_CONSENT_INACTIVE_STATE_CODE = 1  # Inactive

# Lakehouse paths
RAW_BASE_PATH = "/lakehouse/default/Files/raw/Dataverse/05/2026/intake"
PROCESSED_BASE_PATH = "/lakehouse/default/Files/processed/Dataverse/05/2026"

# Input file paths
# Update only the file names below if your raw files are named differently in OneLake.
CARE_PLAN_FILE = f"{RAW_BASE_PATH}/msemr_careplan.csv"
USER_CONSENT_FILE = f"{RAW_BASE_PATH}/mmhci_userconsent.csv"
CARE_PLAN_TEMPLATE_FILE = f"{RAW_BASE_PATH}/msemr_careplantemplate.csv"
EPISODE_OF_CARE_FILE = f"{RAW_BASE_PATH}/msemr_episodeofcare.csv"
INCOMING_REFERRAL_FILE = f"{RAW_BASE_PATH}/mmhci_incomingreferral.csv"
EMAIL_FILE = f"{RAW_BASE_PATH}/email.csv"

# Output file path
OUTPUT_FILE = f"{PROCESSED_BASE_PATH}/{TABLE_NAME}.csv"


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "jupyter_python"
# META }

# CELL ********************

%run nb_generic_loggers

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "jupyter_python"
# META }

# CELL ********************

logger, LOG_FILE = setup_lakehouse_logger(
    table_name=TABLE_NAME,
    source_system="Dataverse",
    month="05",
    year="2026",
    log_level="DEBUG",
    console_log_level="INFO",
    file_log_level="DEBUG"
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "jupyter_python"
# META }

# CELL ********************

import os
import pandas as pd

# Table columns and renamed
INCOMING_REFERRAL_COLUMNS = {
    "mmhci_incomingreferralid": "Intake key",
    "mmhci_organisationid": "Service provider organisation key",
    "mmhci_personid": "Client key",
    "mmhci_referraldate": "Referral date",
    "mmhci_referrertypeid": "Referrer organisation type",
    "mmhci_dateclientcontactedintake": "Date client contacted intake",
    "mmhci_suicidereferralflag": "Suicide referral flag",
    "statuscode": "Registration status",
}

USER_CONSENT_COLUMNS = {
    "mmhci_userconsentid": "Privacy preference key",
    "mmhci_personid": "Consent Client key",
    "mmhci_eocid": "mmhci_eocid",
    "statecode": "state_code",  # inactive/active values
    "mmhci_consentpurposeid": "mmhci_consentpurposeid",
    "statuscode": "user_consent_statuscode",
}

EPISODE_OF_CARE_COLUMNS = [
    "mmhci_incomingreferral",
    "msemr_episodeofcareid",
]

CARE_PLAN_COLUMNS = [
    "msemr_ve_episodeofcare",
    "mmhci_drupal_program_id",
]

CARE_PLAN_TEMPLATE_COLUMNS = [
    "msemr_templatename",
    "mmhci_drupal_program_id",
]

EMAIL_COLUMNS = [
    "subject",
    "regardingobjectid",
]

# Keys for merging
INCOMING_REFERRAL_KEY = "Intake key"  # mmhci_incomingreferralid used as intake key
EPISODE_OF_CARE_KEY = {
    "pk_episode_of_care_id": "msemr_episodeofcareid",
    "fk_incoming_referral_id": "mmhci_incomingreferral",
}
USER_CONSENT_KEY = "mmhci_eocid"
CARE_PLAN_KEY = {
    "fk_episode_of_care_id": "msemr_ve_episodeofcare",
    "fk_drupal_program": "mmhci_drupal_program_id",
}
CARE_PLAN_TEMPLATE_KEY = "mmhci_drupal_program_id"

# Default values
DEFAULT_COLUMNS = {
    "Primary presenting concern": None,
    "Secondary presenting concern": None,
}

# Subject lines for follow ups
SUBJECT_NOTIFS = [
    "reminder to register",
    "book your first appointment",
    "select your medicare mental health check in program",
    "get started with medicare mental health check in",
    "it's not too late to get started",
]

# Final order
DESIRED_COLUMN_ORDER = [
    "Intake key",
    "Service provider organisation key",
    "Client key",
    "Privacy preference key",
    "Referral date",
    "Referrer organisation type",
    "Date client contacted intake",
    "Primary presenting concern",
    "Secondary presenting concern",
    "User follow up",
    "Suicide referral flag",
    "Registration status",
]


def read_lakehouse_file(file_path: str) -> pd.DataFrame:
    """
    Read a Lakehouse file into a pandas DataFrame.
    Supports csv and parquet input files.
    """
    if file_path.lower().endswith(".parquet"):
        return pd.read_parquet(file_path)
    return pd.read_csv(file_path)


def select_columns_dataframe(df: pd.DataFrame, columns: list) -> pd.DataFrame:
    """
    Select required columns from a DataFrame.
    """
    if df.empty:
        return df

    # Remove metadata columns, for example columns starting with "@"
    df = df.loc[:, ~df.columns.str.startswith("@")]

    return df[columns]


def select_and_rename_columns(df: pd.DataFrame, columns_mapping: dict) -> pd.DataFrame:
    """
    Select and rename columns in a DataFrame.
    """
    if df.empty:
        return df

    # Remove metadata columns, for example columns starting with "@"
    df = df.loc[:, ~df.columns.str.startswith("@")]

    selected_columns = list(columns_mapping.keys())
    df_selected = df[selected_columns]
    df_renamed = df_selected.rename(columns=columns_mapping)

    return df_renamed


def normalize_merge_key(df: pd.DataFrame, column_name: str) -> pd.DataFrame:
    """
    Keep the same merge logic but standardize key datatype to avoid
    float/object merge errors when source columns contain null values.
    """
    if column_name in df.columns:
        df[column_name] = df[column_name].fillna("").astype(str).str.strip()
    return df


def process_intake_table() -> pd.DataFrame:
    """
    Process the Intake table by extracting, transforming and loading data
    from multiple dependent Lakehouse files.

    Returns:
        pd.DataFrame: Processed Intake table.
    """
    logger.info("Starting Intake table processing.")
    logger.info("Step 1: Read data from dependent Lakehouse files")
    try:
        logger.info("Fetching data from dependent tables...")
        logger.info(f"Reading incoming referral file: {INCOMING_REFERRAL_FILE}")
        df_incoming_referral = read_lakehouse_file(INCOMING_REFERRAL_FILE)
        logger.info(f"Care plan rows read: {len(df_incoming_referral)}")
        logger.info(f"Reading incoming referral file: {EPISODE_OF_CARE_FILE}")
        df_episode_of_care = read_lakehouse_file(EPISODE_OF_CARE_FILE)
        logger.info(f"Care plan rows read: {len(df_episode_of_care)}")
        logger.info(f"Reading incoming referral file: {USER_CONSENT_FILE}")
        df_user_consent = read_lakehouse_file(USER_CONSENT_FILE)
        logger.info(f"Care plan rows read: {len(df_user_consent)}")
        logger.info(f"Reading incoming referral file: {CARE_PLAN_FILE}")
        df_care_plan = read_lakehouse_file(CARE_PLAN_FILE)
        logger.info(f"Care plan rows read: {len(df_care_plan)}")
        logger.info(f"Reading incoming referral file: {CARE_PLAN_TEMPLATE_FILE}")
        df_care_plan_template = read_lakehouse_file(CARE_PLAN_TEMPLATE_FILE)
        logger.info(f"Care plan rows read: {len(df_care_plan_template)}")
        logger.info(f"Reading incoming referral file: {EMAIL_FILE}")
        df_email = read_lakehouse_file(EMAIL_FILE)
        logger.info(f"Care plan rows read: {len(df_email)}")
    except Exception as e:
        logger.error(f"Error reading dependent files: {e}")
        raise

    logger.info("Step 2 started: Filtering active incoming referral records.")
    try:
        display(df_incoming_referral)
        before_count =len(df_incoming_referral)
        df_incoming_referral = df_incoming_referral[
            df_incoming_referral["statecode"] == 0
        ]  # 0: Active
        after_count = len(df_incoming_referral)

        logger.info(f"Incoming referral rows before active filter: {before_count}")
        logger.info(f"Incoming referral rows after active filter: {after_count}")
        logger.info("Step 2 completed: Active incoming referral filter applied.")
        
    except Exception as e:
        logger.error(f"Error filtering active incoming referral records: {e}")
        raise

    logger.info("Step 3 started: Selecting and renaming required columns.")
    try:
        df_incoming_referral_clean = select_and_rename_columns(
            df_incoming_referral,
            INCOMING_REFERRAL_COLUMNS,
        )
        logger.info(f"Incoming referral clean rows: {len(df_incoming_referral_clean)}")

        df_user_consent_clean = select_and_rename_columns(
            df_user_consent,
            USER_CONSENT_COLUMNS,
        )
        
        logger.info(f"User consent clean rows: {len(df_user_consent_clean)}")
        df_episode_of_care_clean = select_columns_dataframe(
            df_episode_of_care,
            EPISODE_OF_CARE_COLUMNS,
        )
        logger.info(f"Episode of care clean rows: {len(df_episode_of_care_clean)}")

        df_care_plan_clean = select_columns_dataframe(
            df_care_plan,
            CARE_PLAN_COLUMNS,
        )

        logger.info(f"Care plan clean rows: {len(df_care_plan_clean)}")
        df_care_plan_template_clean = select_columns_dataframe(
            df_care_plan_template,
            CARE_PLAN_TEMPLATE_COLUMNS,
        )

        logger.info(f"Care plan template clean rows: {len(df_care_plan_template_clean)}")
        
        df_email_clean = select_columns_dataframe(
            df_email,
            EMAIL_COLUMNS,
        )

        logger.info(f"Email clean rows: {len(df_email_clean)}")

        logger.info("Step 3 completed: Required columns selected successfully.")

    except Exception as e:
        logger.error(f"Error cleaning and selecting columns: {e}")
        raise

    try:
        logger.info("Step 4 started: Calculating user follow-up email count.")
        pattern = "|".join(map(str.lower, SUBJECT_NOTIFS))
        df_email_followups = (
            df_email_clean.assign(
                subject_norm=lambda d: (
                    d["subject"].astype("string").str.lower().str.strip()
                ),
                is_followup=lambda d: (
                    d["subject_norm"]
                    .str.contains(pattern, na=False, regex=True)
                    .astype("int64")
                ),
            )
            .groupby("regardingobjectid", as_index=False)["is_followup"]
            .sum()
            .rename(
                columns={
                    "regardingobjectid": INCOMING_REFERRAL_KEY,
                    "is_followup": "User follow up",
                }
            )
        )
        logger.info(f"Email follow-up rows created: {len(df_email_followups)}")
        logger.info("Step 4 completed: User follow-up count calculated successfully.")
    except Exception as e:
        logger.error(f"Error calculating user follow up count: {e}")
        raise

    logger.info("Step 5 started: Normalizing merge keys.")
    df_incoming_referral_clean = normalize_merge_key(
        df_incoming_referral_clean,
        INCOMING_REFERRAL_KEY,
    )
    df_episode_of_care_clean = normalize_merge_key(
        df_episode_of_care_clean,
        EPISODE_OF_CARE_KEY["fk_incoming_referral_id"],
    )
    df_episode_of_care_clean = normalize_merge_key(
        df_episode_of_care_clean,
        EPISODE_OF_CARE_KEY["pk_episode_of_care_id"],
    )
    df_user_consent_clean = normalize_merge_key(
        df_user_consent_clean,
        USER_CONSENT_KEY,
    )
    df_care_plan_clean = normalize_merge_key(
        df_care_plan_clean,
        CARE_PLAN_KEY["fk_episode_of_care_id"],
    )
    df_care_plan_clean = normalize_merge_key(
        df_care_plan_clean,
        CARE_PLAN_KEY["fk_drupal_program"],
    )
    df_care_plan_template_clean = normalize_merge_key(
        df_care_plan_template_clean,
        CARE_PLAN_TEMPLATE_KEY,
    )
    df_email_followups = normalize_merge_key(
        df_email_followups,
        INCOMING_REFERRAL_KEY,
    )
    logger.info("Step 5 completed: Merge keys normalized successfully.")
    
    logger.info("Step 6 started: Merging Intake dependent tables.")
    try:
        df_merged = df_incoming_referral_clean.merge(
            df_episode_of_care_clean,
            how="left",
            left_on=INCOMING_REFERRAL_KEY,
            right_on=EPISODE_OF_CARE_KEY["fk_incoming_referral_id"],
        )
        logger.info(f"Rows after episode of care merge: {len(df_merged)}")
        df_merged = df_merged.merge(
            df_user_consent_clean,
            how="left",
            left_on=EPISODE_OF_CARE_KEY["pk_episode_of_care_id"],
            right_on=USER_CONSENT_KEY,
        )
        logger.info(f"Rows after user consent merge: {len(df_merged)}")
        df_merged = df_merged.merge(
            df_care_plan_clean,
            how="left",
            left_on=EPISODE_OF_CARE_KEY["pk_episode_of_care_id"],
            right_on=CARE_PLAN_KEY["fk_episode_of_care_id"],
        )
        logger.info(f"Rows after care plan merge: {len(df_merged)}")
        df_merged = df_merged.merge(
            df_care_plan_template_clean,
            how="left",
            left_on=CARE_PLAN_KEY["fk_drupal_program"],
            right_on=CARE_PLAN_TEMPLATE_KEY,
        )
        logger.info(f"Rows after care plan template merge: {len(df_merged)}")
        df_merged = df_merged.merge(
            df_email_followups,
            how="left",
            on=INCOMING_REFERRAL_KEY,
        )
        logger.info(f"Rows after email follow-up merge: {len(df_merged)}")

        logger.info("Step 6 completed: All merges completed successfully.")
    except Exception as e:
        logger.error(f"Error merging tables: {e}")
        raise

    logger.info("Step 7 started: Filtering inactive user consent records.")

    before_count = len(df_merged)
    df_merged = df_merged[
        df_merged[USER_CONSENT_COLUMNS["statecode"]]
        != USER_CONSENT_INACTIVE_STATE_CODE
    ]

    after_count = len(df_merged)

    logger.info(f"Rows before inactive user consent filter: {before_count}")
    logger.info(f"Rows after inactive user consent filter: {after_count}")
    logger.info("Step 7 completed: Inactive user consent records filtered.") 
    
    logger.info("Step 8: Filter help seekers that have provided consent for data collection")
    before_status_filter_count = len(df_merged)
    df_merged = df_merged[df_merged["user_consent_statuscode"] == 1]
    after_status_filter_count = len(df_merged)

    logger.info(f"Rows before consent status filter: {before_status_filter_count}")
    logger.info(f"Rows after consent status filter: {after_status_filter_count}")

    before_purpose_filter_count = len(df_merged)
    df_merged = df_merged[df_merged["user_consent_statuscode"] == 1]
    df_merged = df_merged[
        df_merged["mmhci_consentpurposeid"].astype("string").str.lower()
        == CONSENT_PROVIDED.lower()
    ]
    after_purpose_filter_count = len(df_merged)

    logger.info(f"Rows before consent purpose filter: {before_purpose_filter_count}")
    logger.info(f"Rows after consent purpose filter: {after_purpose_filter_count}")

    logger.info("Step 8 completed: Consent filters applied successfully.")

    logger.info("Step 9 started: Applying final Intake transformations.")
    try:
        # Additional columns and default values
        df_merged = df_merged.assign(**DEFAULT_COLUMNS)
        logger.info("Default columns added successfully.")
        # R3 Mapping
        df_merged["Primary presenting concern"] = df_merged["msemr_templatename"]
        logger.info("Primary presenting concern mapped successfully.")
        # Organising columns in desired order
        df_merged = df_merged.reindex(columns=DESIRED_COLUMN_ORDER)

        # Changing date format to yyyy-mm-dd
        df_merged[INCOMING_REFERRAL_COLUMNS["mmhci_referraldate"]] = pd.to_datetime(
            df_merged[INCOMING_REFERRAL_COLUMNS["mmhci_referraldate"]],
             errors="coerce",
             format="mixed"
        ).dt.strftime("%Y-%m-%d")

        df_merged[
            INCOMING_REFERRAL_COLUMNS["mmhci_dateclientcontactedintake"]
        ] = pd.to_datetime(
            df_merged[INCOMING_REFERRAL_COLUMNS["mmhci_dateclientcontactedintake"]],
             errors="coerce",
             format="mixed"
        ).dt.strftime("%Y-%m-%d")

        df_merged["User follow up"] = (
            df_merged["User follow up"].fillna(0).astype("Int64")
        )

        # Sort by date time and drop duplicates
        df_merged = df_merged.sort_values(
            by=["Intake key", "Referral date"],
        )

        # Drop duplicate intake keys
        df_merged = df_merged.drop_duplicates(subset="Intake key", keep="last")

        # Drop null intake keys
        df_merged = df_merged.dropna(subset=["Intake key"])

        # Add logic for missing referrer org
        df_merged["Referrer organisation type"] = df_merged[
            "Referrer organisation type"
        ].fillna("99: Self-referral")

        # Mapping for registration status
        df_merged["Registration status"] = (
            df_merged["Registration status"]
            .map(INTAKE_REGISTRATION_STATUS_DOH_MAPPING)
            .astype("Int64")
        )

        df_merged["Service provider organisation key"] = ORGANISATION_ID

        df_merged["Suicide referral flag"] = df_merged[
            "Suicide referral flag"
        ].astype("Int64")
        df_merged["Suicide referral flag"] = SUICIDAL_REFERRAL_FLAG_DEFAULT

        df_merged = df_merged.drop_duplicates()
    except Exception as e:
        logger.error(f"Error applying transformations: {e}")
        raise

    # Step 10: Export processed output to CSV
    try:
        os.makedirs(PROCESSED_BASE_PATH, exist_ok=True)
        df_merged.to_csv(OUTPUT_FILE, index=False)
        print(f"Intake output file created successfully: {OUTPUT_FILE}")
    except Exception as e:
        logger.error(f"Error writing Intake output file: {e}")
        raise

    return df_merged


try:
    process_intake_table()
    logger.info("Intake process completed successfully.")
except Exception as e:
    logger.exception(f"Intake notebook failed: {e}")
    raise


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "jupyter_python"
# META }

# CELL ********************


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "jupyter_python"
# META }
