# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "jupyter",
# META     "jupyter_kernel_name": "python3.12"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "2a4f1954-6c84-4327-9d1b-5090e493e152",
# META       "default_lakehouse_name": "lh_mmhci_datahub_dev",
# META       "default_lakehouse_workspace_id": "1ba3ebd5-d835-4cdc-85d9-80feb379778e",
# META       "known_lakehouses": [
# META         {
# META           "id": "2a4f1954-6c84-4327-9d1b-5090e493e152"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

pipeline_name = ""
pipeline_run_id = ""
failed_activity_name = ""
table_name = ""
source_system = "Dataverse"
month = "05"
year = "2026"
error_code = "NOTEBOOK_FAILED"
error_message = ""

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "jupyter_python"
# META }

# CELL ********************

import notebookutils
from datetime import datetime
import re


def clean_file_name(value):
    if value is None or str(value).strip() == "":
        return "unknown"

    return re.sub(r"[^a-zA-Z0-9_\-]", "_", str(value).strip())


def write_pipeline_error_file():
    """
    Writes pipeline-level/activity-level error details into Lakehouse.

    Output path:
    Files/error/MM/YYYY/SourceSystem/
    Example:
    Files/error/05/2026/Dataverse/
    """

    error_folder = f"Files/error/{month}/{year}/{source_system}"
    notebookutils.fs.mkdirs(error_folder)

    error_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    file_timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

    safe_pipeline_name = clean_file_name(pipeline_name)
    safe_activity_name = clean_file_name(failed_activity_name)
    safe_table_name = clean_file_name(table_name)

    error_file_path = (
        f"{error_folder}/"
        f"{safe_pipeline_name}_{safe_activity_name}_{safe_table_name}_{file_timestamp}.txt"
    )

    error_content = f"""
============================================================
FABRIC PIPELINE LEVEL ERROR LOG
============================================================

Error Time:
{error_time}

Pipeline Name:
{pipeline_name}

Pipeline Run ID:
{pipeline_run_id}

Failed Activity Name:
{failed_activity_name}

Table Name:
{table_name}

Source System:
{source_system}

Month:
{month}

Year:
{year}

Error Code:
{error_code}

Pipeline / Activity Error Message:
{error_message}

============================================================
END OF ERROR LOG
============================================================
"""

    notebookutils.fs.put(error_file_path, error_content, True)

    print("Pipeline-level error file created successfully:")
    print(error_file_path)

    print("Files available in error folder:")
    for file in notebookutils.fs.ls(error_folder):
        print(file.path)


write_pipeline_error_file()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "jupyter_python"
# META }

# MARKDOWN ********************

