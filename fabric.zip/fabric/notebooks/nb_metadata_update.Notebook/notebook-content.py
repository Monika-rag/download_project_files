# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "2a4f1954-6c84-4327-9d1b-5090e493e152",
# META       "default_lakehouse_name": "lh_mmhci_datahub_dev",
# META       "default_lakehouse_workspace_id": "1ba3ebd5-d835-4cdc-85d9-80feb379778e",
# META       "known_lakehouses": [
# META         {
# META           "id": "2a4f1954-6c84-4327-9d1b-5090e493e152"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

ingestion_config_id = ""
pipeline_run_id = ""
pipeline_name = ""

run_status = ""  # STARTED / SUCCEEDED / FAILED

source_file_name = ""
rows_read = "0"
rows_written = "0"

error_message = ""
new_watermark_value = ""

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from datetime import datetime
from pyspark.sql import Row
import uuid

MD_CONFIG_TABLE = "dbo.md_ingestion_config"
AUDIT_PIPELINE_TABLE = "dbo.audit_pipeline_run"
AUDIT_INGESTION_TABLE = "dbo.audit_ingestion_run"


def safe_string(value):
    if value is None:
        return ""
    return str(value)


def to_int(value, default=0):
    try:
        if value is None or str(value).strip() == "":
            return default
        return int(value)
    except Exception:
        return default


def to_bigint(value, default=0):
    try:
        if value is None or str(value).strip() == "":
            return default
        return int(value)
    except Exception:
        return default


def get_config_row():
    config_df = spark.sql(f"""
        SELECT
            ingestion_config_id,
            ingestion_name,
            source_type,
            connection_name,
            source_object_name,
            source_folder_path,
            source_file_pattern,
            load_type,
            watermark_column,
            watermark_value,
            target_folder_path,
            target_file_name,
            target_format,
            write_mode,
            schedule_group,
            execution_sequence,
            active_flag
        FROM {MD_CONFIG_TABLE}
        WHERE ingestion_config_id = '{ingestion_config_id}'
    """)

    rows = config_df.collect()

    if not rows:
        raise Exception(
            f"No active metadata configuration found for ingestion_config_id: {ingestion_config_id}"
        )

    return rows[0]


def build_paths(config):
    source_folder = safe_string(config["source_folder_path"]).rstrip("/")
    target_folder = safe_string(config["target_folder_path"]).rstrip("/")
    target_file = safe_string(config["target_file_name"])

    resolved_source_file_name = safe_string(source_file_name)

    if resolved_source_file_name.strip() == "":
        resolved_source_file_name = safe_string(config["source_file_pattern"])

    source_path = f"{source_folder}/{resolved_source_file_name}" if resolved_source_file_name else source_folder
    target_path = f"{target_folder}/{target_file}" if target_file else target_folder

    return resolved_source_file_name, source_path, target_path


def get_ingestion_run_id():
    """
    Deterministic ingestion_run_id so STARTED/SUCCEEDED/FAILED update same row.
    """
    return f"{pipeline_run_id}_{ingestion_config_id}"


def update_audit_pipeline_run(config):
    current_time = datetime.now()

    schedule_group = safe_string(config["schedule_group"])

    if run_status == "STARTED":
        start_time = current_time
        end_time = None
        row_count = 0
        success_count = 0
        failure_count = 0
        pipeline_status = "STARTED"

    elif run_status == "SUCCEEDED":
        start_time = None
        end_time = current_time
        row_count = to_int(rows_written)
        success_count = 1
        failure_count = 0
        pipeline_status = "SUCCEEDED"

    elif run_status == "FAILED":
        start_time = None
        end_time = current_time
        row_count = 0
        success_count = 0
        failure_count = 1
        pipeline_status = "FAILED"

    else:
        raise Exception(f"Invalid run_status received: {run_status}")

    update_row = Row(
        pipeline_run_id=safe_string(pipeline_run_id),
        pipeline_name=safe_string(pipeline_name),
        schedule_group=schedule_group,
        run_status=pipeline_status,
        start_time=start_time,
        end_time=end_time,
        row_count=row_count,
        success_count=success_count,
        failure_count=failure_count,
        error_message=safe_string(error_message),
        update_time=current_time
    )

    df_update = spark.createDataFrame([update_row])
    df_update.createOrReplaceTempView("vw_audit_pipeline_update")

    spark.sql(f"""
        MERGE INTO {AUDIT_PIPELINE_TABLE} AS target
        USING vw_audit_pipeline_update AS source
        ON target.pipeline_run_id = source.pipeline_run_id

        WHEN MATCHED THEN UPDATE SET
            target.pipeline_name = source.pipeline_name,
            target.schedule_group = source.schedule_group,
            target.run_status = source.run_status,
            target.end_time =
                CASE
                    WHEN source.run_status IN ('SUCCEEDED', 'FAILED')
                    THEN source.end_time
                    ELSE target.end_time
                END,
            target.row_count =
                CASE
                    WHEN source.run_status = 'SUCCEEDED'
                    THEN source.row_count
                    ELSE target.row_count
                END,
            target.success_count =
                CASE
                    WHEN source.run_status = 'SUCCEEDED'
                    THEN source.success_count
                    ELSE target.success_count
                END,
            target.failure_count =
                CASE
                    WHEN source.run_status = 'FAILED'
                    THEN source.failure_count
                    ELSE target.failure_count
                END,
            target.error_message = source.error_message,
            target.updated_at = source.update_time

        WHEN NOT MATCHED THEN INSERT (
            pipeline_run_id,
            pipeline_name,
            schedule_group,
            run_status,
            start_time,
            end_time,
            row_count,
            success_count,
            failure_count,
            error_message,
            created_at,
            updated_at
        )
        VALUES (
            source.pipeline_run_id,
            source.pipeline_name,
            source.schedule_group,
            source.run_status,
            source.start_time,
            source.end_time,
            source.row_count,
            source.success_count,
            source.failure_count,
            source.error_message,
            source.update_time,
            source.update_time
        )
    """)


def update_audit_ingestion_run(config, resolved_source_file_name, source_path, target_path):
    current_time = datetime.now()

    ingestion_run_id = get_ingestion_run_id()

    previous_watermark_value = safe_string(config["watermark_value"])

    if run_status == "STARTED":
        start_time = current_time
        end_time = None
        ingestion_status = "STARTED"
        audit_rows_read = 0
        audit_rows_written = 0
        audit_error_message = ""

    elif run_status == "SUCCEEDED":
        start_time = None
        end_time = current_time
        ingestion_status = "SUCCEEDED"
        audit_rows_read = to_bigint(rows_read)
        audit_rows_written = to_bigint(rows_written)
        audit_error_message = ""

    elif run_status == "FAILED":
        start_time = None
        end_time = current_time
        ingestion_status = "FAILED"
        audit_rows_read = to_bigint(rows_read)
        audit_rows_written = to_bigint(rows_written)
        audit_error_message = safe_string(error_message)

    else:
        raise Exception(f"Invalid run_status received: {run_status}")

    update_row = Row(
        ingestion_run_id=safe_string(ingestion_run_id),
        pipeline_run_id=safe_string(pipeline_run_id),
        ingestion_config_id=safe_string(ingestion_config_id),

        source_type=safe_string(config["source_type"]),
        source_object_name=safe_string(config["source_object_name"]),
        source_file_name=safe_string(resolved_source_file_name),
        source_path=safe_string(source_path),
        target_path=safe_string(target_path),

        load_type=safe_string(config["load_type"]),
        run_status=safe_string(ingestion_status),

        start_time=start_time,
        end_time=end_time,
        rows_read=audit_rows_read,
        rows_written=audit_rows_written,

        previous_watermark_value=safe_string(previous_watermark_value),
        new_watermark_value=safe_string(new_watermark_value),

        error_message=safe_string(audit_error_message),
        update_time=current_time
    )

    df_update = spark.createDataFrame([update_row])
    df_update.createOrReplaceTempView("vw_audit_ingestion_update")

    spark.sql(f"""
        MERGE INTO {AUDIT_INGESTION_TABLE} AS target
        USING vw_audit_ingestion_update AS source
        ON target.ingestion_run_id = source.ingestion_run_id

        WHEN MATCHED THEN UPDATE SET
            target.pipeline_run_id = source.pipeline_run_id,
            target.ingestion_config_id = source.ingestion_config_id,
            target.source_type = source.source_type,
            target.source_object_name = source.source_object_name,
            target.source_file_name = source.source_file_name,
            target.source_path = source.source_path,
            target.target_path = source.target_path,
            target.load_type = source.load_type,
            target.run_status = source.run_status,
            target.end_time =
                CASE
                    WHEN source.run_status IN ('SUCCEEDED', 'FAILED')
                    THEN source.end_time
                    ELSE target.end_time
                END,
            target.rows_read = source.rows_read,
            target.rows_written = source.rows_written,
            target.previous_watermark_value = source.previous_watermark_value,
            target.new_watermark_value = source.new_watermark_value,
            target.error_message = source.error_message,
            target.updated_at = source.update_time

        WHEN NOT MATCHED THEN INSERT (
            ingestion_run_id,
            pipeline_run_id,
            ingestion_config_id,

            source_type,
            source_object_name,
            source_file_name,
            source_path,
            target_path,

            load_type,
            run_status,

            start_time,
            end_time,
            rows_read,
            rows_written,

            previous_watermark_value,
            new_watermark_value,

            error_message,
            created_at,
            updated_at
        )
        VALUES (
            source.ingestion_run_id,
            source.pipeline_run_id,
            source.ingestion_config_id,

            source.source_type,
            source.source_object_name,
            source.source_file_name,
            source.source_path,
            source.target_path,

            source.load_type,
            source.run_status,

            source.start_time,
            source.end_time,
            source.rows_read,
            source.rows_written,

            source.previous_watermark_value,
            source.new_watermark_value,

            source.error_message,
            source.update_time,
            source.update_time
        )
    """)


def update_md_ingestion_config():
    """
    Updates updated_at every time.
    Updates watermark_value only on successful run when new_watermark_value is provided.
    """
    current_time = datetime.now()

    watermark_to_update = safe_string(new_watermark_value)

    update_row = Row(
        ingestion_config_id=safe_string(ingestion_config_id),
        new_watermark_value=watermark_to_update,
        update_time=current_time
    )

    df_update = spark.createDataFrame([update_row])
    df_update.createOrReplaceTempView("vw_md_config_update")

    spark.sql(f"""
        MERGE INTO {MD_CONFIG_TABLE} AS target
        USING vw_md_config_update AS source
        ON target.ingestion_config_id = source.ingestion_config_id

        WHEN MATCHED THEN UPDATE SET
            target.watermark_value =
                CASE
                    WHEN '{run_status}' = 'SUCCEEDED'
                         AND source.new_watermark_value IS NOT NULL
                         AND source.new_watermark_value <> ''
                    THEN source.new_watermark_value
                    ELSE target.watermark_value
                END,
            target.updated_at = source.update_time
    """)


def validate_inputs():
    if safe_string(ingestion_config_id).strip() == "":
        raise Exception("ingestion_config_id is mandatory.")

    if safe_string(pipeline_run_id).strip() == "":
        raise Exception("pipeline_run_id is mandatory.")

    if safe_string(pipeline_name).strip() == "":
        raise Exception("pipeline_name is mandatory.")

    if safe_string(run_status).strip() == "":
        raise Exception("run_status is mandatory.")

    if run_status not in ["STARTED", "SUCCEEDED", "FAILED"]:
        raise Exception("run_status must be STARTED, SUCCEEDED, or FAILED.")


validate_inputs()

config = get_config_row()

resolved_source_file_name, source_path, target_path = build_paths(config)

update_audit_pipeline_run(config)
update_audit_ingestion_run(config, resolved_source_file_name, source_path, target_path)
update_md_ingestion_config()

print("Metadata update completed successfully.")
print(f"ingestion_config_id: {ingestion_config_id}")
print(f"pipeline_run_id: {pipeline_run_id}")
print(f"pipeline_name: {pipeline_name}")
print(f"run_status: {run_status}")
print(f"source_path: {source_path}")
print(f"target_path: {target_path}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
