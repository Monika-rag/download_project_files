# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "jupyter",
# META     "jupyter_kernel_name": "python3.12"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "2a4f1954-6c84-4327-9d1b-5090e493e152",
# META       "default_lakehouse_name": "lh_mmhci_datahub_dev",
# META       "default_lakehouse_workspace_id": "1ba3ebd5-d835-4cdc-85d9-80feb379778e",
# META       "known_lakehouses": [
# META         {
# META           "id": "2a4f1954-6c84-4327-9d1b-5090e493e152"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

import pandas as pd

# Table name for file export
TABLE_NAME = "Privacypreferences"

# Constant default variables for columns
QUESTION = None  # Default to blank
QUESTIONNAIRE_VERSION_START_DATE = "2026-03-30"
QUESTIONNAIRE_VERSION_END_DATE = "2029-03-30"

# Constant default variables for columns
CONSENT_METHOD = 1

# Lakehouse paths
RAW_BASE_PATH = "/lakehouse/default/Files/raw/Dataverse/05/2026/privacy_preferences"
PROCESSED_BASE_PATH = "/lakehouse/default/Files/processed/Dataverse/05/2026"

# Input file paths
# Update only the file names below if your raw files are named differently in OneLake.
USER_CONSENT_FILE = f"{RAW_BASE_PATH}/mmhci_userconsent.csv"
CONSENT_PURPOSE_FILE = f"{RAW_BASE_PATH}/mmhci_consentpurpose.csv"

# Mapping of the default values and additional columns
DEFAULT_COLUMN_VALUES = {
    "Consent method": CONSENT_METHOD,
}
# Table columns
USER_CONSENT_COLUMNS = [
    "mmhci_userconsentid",
    "mmhci_personid",
    "mmhci_consentpurposeid",
    "statuscode",
    "mmhci_consentprovided",
    "statecode",
    "mmhci_consentmethod",
]
CONSENT_PURPOSE_COLUMNS = ["mmhci_consentpurposeid", "mmhci_name"]

# Key columns for merging
USER_CONSENT_KEY = "mmhci_consentpurposeid"
CONSENT_PURPOSE_KEY = "mmhci_consentpurposeid"

# DOH Mapping Extraction logic
USER_CONSENT_STATUS_DOH_MAPPING = {
    1: 1,  # Consent Granted : Consent Granted
    100000000: 2,  # Consent Declined : Consent Declined
    2: 2,  # Consent Revoked : Consent Declined
}
USER_CONSENT_FLAG_DOH_MAPPING = {
    0: 1,  # Active : Current
    1: 2,  # Inactive : Not Current
}
CONSENT_PURPOSE_DOH_MAPPING = {
    "D0FA4878-5B14-F111-8341-000D3A794D28": 1,  # Privacy, collection notice and terms of use : Primacy Purposes
    "18C6DF82-5B14-F111-8341-000D3A794D28": 2,  # Clinical trials : Secondary purposes
    "523EDD88-5B14-F111-8341-000D3A794D28": 2,  # Research and independent evaluations : Secondary purposes
    "AE4D8E90-5B14-F111-8341-000D3A794D28": "Other",  # Other : ??
    "509B9D6E-5C14-F111-8341-000D3A794D28": 1,  # Gp & other providers : Primary Purposes
}

# Mapping of DataFrame columns in order and to their corresponding names for CSV output
FINAL_COLUMNS_MAPPING = {
    "mmhci_userconsentid": "Privacy preference key",
    "mmhci_personid": "Client key",
    "mmhci_consentpurposeid": "Consent purpose",
    "statuscode": "Consent status",
    "mmhci_consentprovided": "Consent timestamp",
    "statecode": "Current flag",
    "mmhci_consentmethod": "Consent method",
}

def read_lakehouse_file(file_path: str) -> pd.DataFrame:
    """
    Read a Lakehouse file into a pandas DataFrame.
    Supports parquet and csv input files.
    """
    if file_path.lower().endswith(".parquet"):
        return pd.read_csv(file_path)
    return pd.read_csv(file_path)


def select_columns_dataframe(df: pd.DataFrame, columns: list) -> pd.DataFrame:
    """
    Select required columns from a DataFrame.
    """
    if df.empty:
        return df

    # Remove metadata columns, for example columns starting with "@"
    df = df.loc[:, ~df.columns.str.startswith("@")]

    return df[columns]


def select_and_rename_columns(df: pd.DataFrame, columns_mapping: dict) -> pd.DataFrame:
    """
    Select and rename columns in a DataFrame.
    """
    if df.empty:
        return df

    # Remove metadata columns, for example columns starting with "@"
    df = df.loc[:, ~df.columns.str.startswith("@")]

    selected_columns = list(columns_mapping.keys())
    df_selected = df[selected_columns]
    df_renamed = df_selected.rename(columns=columns_mapping)

    return df_renamed


def process_privacy_preferences_table() -> pd.DataFrame:
    """
    Process the Privacy Preference Table by combining data from multiple dependent tables.

    Parameters:
        Privacy Preference: Dataverse object for fetching data.

    Returns:
        pd.DataFrame: Processed Privacy Preferences Table.
    """
    # Step 1: Read data from dependent Lakehouse files
    
    try:
         df_user_consent = read_lakehouse_file(USER_CONSENT_FILE)
         mmhci_consentpurpose = read_lakehouse_file(CONSENT_PURPOSE_FILE)
        
    except Exception as e:
        print(f"Error reading dependent files: {e}")
        raise

    # Step 2: Clean and select required columns
    try:
        df_user_consent_clean = select_and_rename_columns(
            df_user_consent,USER_CONSENT_COLUMNS,
        )
        df_consentpurpose_clean = select_columns_dataframe(
            df_consent_purpose, CONSENT_PURPOSE_COLUMNS
        )
    except Exception as e:
        print(f"Error cleaning and selecting columns: {e}")
        raise
        
    # Step 4: Merge tables
    try:
        
        df_merged = df_user_consent_clean.merge(
            df_consentpurpose_clean,
            how="left",
            left_on=USER_CONSENT_KEY,
            right_on=CONSENT_PURPOSE_KEY,
        )
    except Exception as e:
        print(f"Error merging tables: {e}")
        raise

     # Step 4.5: Filter one help seekers that have provided consent for data collection
    df_merged = df_merged[df_merged["statuscode"] == 1]  #check consent has been granted (1=consent granted)
    df_merged = df_merged[df_merged["_mmhci_consentpurposeid_value"]== CONSENT_PROVIDED
    ] # Privacy, collection notice and terms of use (GUID)
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          
    # Step 5: Select columns to keep in the final table and rename
    df_merged = select_and_rename_columns(df_merged, FINAL_COLUMNS_MAPPING)

    # Step 6: Apply extraction logic
    try:
        df_merged["Consent timestamp"] = pd.to_datetime(
            df_merged["Consent timestamp"], utc=True, errors="coerce"
        ).dt.strftime("%Y-%m-%d %H:%M:%S")
        df_merged[FINAL_COLUMNS_MAPPING["statuscode"]] = df_merged[
            FINAL_COLUMNS_MAPPING["statuscode"]
        ].map(USER_CONSENT_STATUS_DOH_MAPPING)
        df_merged[FINAL_COLUMNS_MAPPING["statecode"]] = df_merged[
            FINAL_COLUMNS_MAPPING["statecode"]
        ].map(USER_CONSENT_FLAG_DOH_MAPPING)
        df_merged[FINAL_COLUMNS_MAPPING["_mmhci_consentpurposeid_value"]] = (
            df_merged[FINAL_COLUMNS_MAPPING["_mmhci_consentpurposeid_value"]]
            .str.upper()
            .map(CONSENT_PURPOSE_DOH_MAPPING)
        )

    except Exception as e:
        print(f"Error applying transformations: {e}")
        raise


    df_merged = df_merged.assign(**DEFAULT_COLUMN_VALUES)
    df_merged = df_merged.drop_duplicates()

    return df_merged

    try:
        process_privacy_preferences()
    except Exception as e:
        print(f"Error in privacy_preferences: {e}")
    raise


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "jupyter_python"
# META }
