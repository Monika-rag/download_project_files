# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "jupyter",
# META     "jupyter_kernel_name": "python3.12"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "2a4f1954-6c84-4327-9d1b-5090e493e152",
# META       "default_lakehouse_name": "lh_mmhci_datahub_dev",
# META       "default_lakehouse_workspace_id": "1ba3ebd5-d835-4cdc-85d9-80feb379778e",
# META       "known_lakehouses": [
# META         {
# META           "id": "2a4f1954-6c84-4327-9d1b-5090e493e152"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

import pandas as pd
import numpy as np
from datetime import datetime, timedelta, timezone
from typing import Callable
import json

# Table name for file export
TABLE_NAME = "Servicecontact"

# Lakehouse paths
RAW_BASE_PATH = "/lakehouse/default/Files/raw/Dataverse/05/2026/service_contact"
PROCESSED_BASE_PATH = "/lakehouse/default/Files/processed/Dataverse/05/2026"

# Input file paths
AUDITS_START_FILE = f"{RAW_BASE_PATH}/audits.parquet"
AUDTIS_COMP_FILE = f"{RAW_BASE_PATH}/audits_comp.parquet"
BOOKABLE_RESOURCE_FILE = f"{RAW_BASE_PATH}/bookableresource.parquet"
FEEDBACK_FILE = f"{RAW_BASE_PATH}/feedback.parquet"
USER_CONSENT_FILE = f"{RAW_BASE_PATH}/mmhci_userconsent.parquet"
APPOINTMENT_FILE = f"{RAW_BASE_PATH}/msemr_appointmentemr.parquet"
CARE_PLAN_FILE = f"{RAW_BASE_PATH}/msemr_careplan.parquet"
CARE_PLAN_ACTIVITY_FILE = f"{RAW_BASE_PATH}/msemr_careplanactivity.parquet"
CARE_PLAN_TEMPLATE_FILE = f"{RAW_BASE_PATH}/msemr_careplantemplate.parquet"
ENCOUNTER_FILE = f"{RAW_BASE_PATH}/msemr_encounter.parquet"
EPISODE_OF_CARE_FILE = f"{RAW_BASE_PATH}/msemr_episodeofcare.parquet"

# Output file path
OUTPUT_FILE = f"{PROCESSED_BASE_PATH}/{TABLE_NAME}.csv"

ChangedataPredicate = Callable[[list[dict]], bool]

APPOINTMENT_TYPE = {
    935000000 : "Appointment",
    935000001 : "Module"
}
ORGANISATION_ID = "SVHA-MMHCI-01"
CONSENT_PROVIDED = "D0FA4878-5B14-F111-8341-000D3A794D28"

# Constant default variables
TYPE_DEFAULT = 1
DURATION_DEFAULT = None
START_TIMESTAMP_DEFAULT = None
COMPLETION_TIMESTAMP_DEFAULT = None
COMPLETION_STATUS_DEFAULT = None
# FEEDBACK_RATING_DEFAULT = None
FINAL_SERVICE_CONTACT_OF_LICBT_COURSE_DEFAULT = 3
MODULE_DURATION_DEFAULT = 120

# Table columns
CARE_PLAN_COLUMNS = [
    "msemr_careplanid",
    "msemr_careplantemplate",
    "msemr_ve_episodeofcare",
    "mmhci_drupal_program_id",
    "msemr_patientidentifier"
]
CARE_PLAN_ACTIVITY_COLUMNS = [
    "msemr_careplanactivityid",
    "msemr_careplan",
    "msemr_activitystartdate",
    "mmhci_appointmentstarttime",
    "mmhci_appointmentendtime",
    "msemr_activitydefinitiontype",
    "statuscode",
    "msemr_careplanactivity",
    "mmhci_preferredappointmentchannel",
    "msemr_activitystatus",
]
CARE_PLAN_TEMPLATE_COLUMNS = ["msemr_careplantemplateid", "msemr_careplanidentifier", "mmhci_drupal_program_id"]
EPISODE_OF_CARE_COLUMNS = [
    "msemr_organization",
    "msemr_episodeofcareid",
    "mmhci_primarypractitioner",
    "mmhci_pathwaytype",
    "mmhci_interpreterrequired",
    "statecode",
    "msemr_patient"
]
BOOKABLE_RESOURCE_COLUMNS = ["bookableresourceid"]
FEEDBACK_COLUMNS = ["mmhci_howhelpfulwereactivitiestowardsgoal", "mmhci_regardingid"]
ENCOUNTER_COLUMNS = {
"mmhci_careplanactivity" : "mmhci_careplanactivity", 
"msemr_appointmentemr" : "msemr_appointmentemr",
"statecode" : "encounter_statecode"
}
APPOINTMENT_EMR_COLUMNS = ["activityid", "actualstart", "actualend"]

DEFAULT_COLUMN_VALUES = {
    # "Type": TYPE_DEFAULT,
    "Duration": DURATION_DEFAULT,
    "Start timestamp": START_TIMESTAMP_DEFAULT,
    "Completion timestamp": COMPLETION_TIMESTAMP_DEFAULT,
    # "Completion status": COMPLETION_STATUS_DEFAULT,
    # "Feedback rating": FEEDBACK_RATING_DEFAULT,
    # "Final service contact of LiCBT course": FINAL_SERVICE_CONTACT_OF_LICBT_COURSE_DEFAULT,
}

USER_CONSENT_COLUMNS = {
    "mmhci_personid" : "user_consent_personid",
    "mmhci_consentpurposeid" : "consent_purposeid",
    "statuscode" : "user_consent_statuscode"
}

def select_columns_dataframe(df: pd.DataFrame, columns_to_keep: list) -> pd.DataFrame:
    """
    Clean the DataFrame by removing metadata columns and selecting specific columns.

    Parameters:
        df (pd.DataFrame): Input DataFrame.
        columns_to_keep (list): List of columns to retain.

    Returns:
        pd.DataFrame: Cleaned DataFrame with selected columns.
    """
    if df.empty:
        return df
    # Remove metadata columns (e.g., columns starting with "@")
    df_clean = df.loc[:, ~df.columns.str.startswith("@")]
    # Select only the specified columns
    return df_clean[[col for col in columns_to_keep if col in df_clean.columns]]

def select_and_rename_columns(df: pd.DataFrame, columns_mapping: dict) -> pd.DataFrame:
    """
    Select and rename columns in a DataFrame

    Parameters:
        df (pd.DataFrame): Input DataFrame.
        columns_mapping (dict): Dictionary mapping old column names to new column names

    Returns:
        pd.DataFrame: DataFrame with selected and renamed columns
    """
    if df.empty:
        return df
    
    # Remove metadata columns (e.g., columns starting with "@")
    df = df.loc[:, ~df.columns.str.startswith("@")]
    # Select columns based on keys in the mapping
    selected_columns = list(columns_mapping.keys())
    df_selected = df[selected_columns]
    # Rename columns based on the mapping
    df_renamed = df_selected.rename(columns=columns_mapping)
    return df_renamed

def fetch_audit_logs_for_object_ids(
    dataframe: pd.DataFrame,
    changedata_filter: ChangedataPredicate | None = None,
    ) -> pd.DataFrame:

    audits_df = dataframe
    if audits_df.empty:
        return audits_df

    # Normalise object ids (audit -> target record)
    audits_df["_objectid_value_norm"] = (
        audits_df["_objectid_value"]
        .astype(str)
        .str.strip()
        .str.strip("{}")
    )
    # Parse changedata
    audits_df["changed_attributes"] = audits_df["changedata"].apply(extract_changed_attributes)
    if changedata_filter is not None:
        audits_df = audits_df[audits_df["changed_attributes"].apply(changedata_filter)].copy()

    return audits_df

def extract_changed_attributes(changedata: str) -> list[dict]:
    if not changedata:
        return []
    try:
        return json.loads(changedata).get("changedAttributes", [])
    except Exception:
        return []
    
def activitystatus_notstarted_to_released(attrs: list[dict]) -> bool:
    return any(
        a.get("logicalName") == "msemr_activitystatus"
        and a.get("oldValue") == "935000000" # Not Started value
        and a.get("newValue") == "935000001" # Released value
        for a in attrs
    )

NOT_STARTED = "935000000"
RELEASED    = "935000001"
COMPLETED   = "935000004"

def status_transition(old_value: str | None = None, new_value: str | None = None,
                      old_name: str | None = None, new_name: str | None = None):
    """
    Returns a predicate(attrs) that matches a msemr_activitystatus change with the given constraints.
    Works whether changedata carries *Value*, *Name*, or both.
    """
    def _pred(attrs: list[dict]) -> bool:
        for a in attrs:
            if a.get("logicalName") != "msemr_activitystatus":
                continue

            ov = str(a.get("oldValue")) if a.get("oldValue") is not None else None
            nv = str(a.get("newValue")) if a.get("newValue") is not None else None
            on = a.get("oldName")
            nn = a.get("newName")

            if old_value is not None and ov != str(old_value):
                continue
            if new_value is not None and nv != str(new_value):
                continue
            if old_name is not None and on != old_name:
                continue
            if new_name is not None and nn != new_name:
                continue

            return True
        return False
    return _pred

# Start: Not Started -> Released
activitystatus_notstarted_to_released = status_transition(old_value=NOT_STARTED, new_value=RELEASED)
# Completion: Released -> Completed
activitystatus_released_to_completed  = status_transition(old_value=RELEASED, new_value=COMPLETED)

def read_lakehouse_file(file_path: str) -> pd.DataFrame:
    """
    Read a Lakehouse file into a pandas DataFrame.
    Supports parquet and csv input files.
    """
    if file_path.lower().endswith(".parquet"):
        return pd.read_csv(file_path, low_memory=False)
    return pd.read_csv(file_path, low_memory=False)

# Key columns for merging
def process_service_contact() -> pd.DataFrame:
    """
    Process the Service Contact by combining data from multiple dependent tables.

    Parameters:
        client: Dataverse client object for fetching data.

    Returns:
        pd.DataFrame: Processed Service Contact.
    """
    # Step 1: Convert records to DataFrames for transformations
    try:
        df_care_plan = read_lakehouse_file(CARE_PLAN_FILE)
        df_care_plan_activity = read_lakehouse_file(CARE_PLAN_ACTIVITY_FILE)
        df_care_plan_template = read_lakehouse_file(CARE_PLAN_TEMPLATE_FILE)
        df_episode_of_care = read_lakehouse_file(EPISODE_OF_CARE_FILE)
        df_bookable_resource = read_lakehouse_file(BOOKABLE_RESOURCE_FILE)
        df_feedback = read_lakehouse_file(FEEDBACK_FILE)
        df_encounter = read_lakehouse_file(ENCOUNTER_FILE)
        df_appointment = read_lakehouse_file(APPOINTMENT_FILE)
        df_userconsent = read_lakehouse_file(USER_CONSENT_FILE)
        df_audit_start = read_lakehouse_file(AUDITS_START_FILE)
        df_audit_end = read_lakehouse_file(AUDTIS_COMP_FILE)
    except Exception as e:
        raise

    # Step 3: Clean and select columns directly using utility functions
    try:
        df_care_plan_clean = select_columns_dataframe(df_care_plan, CARE_PLAN_COLUMNS)
        df_care_plan_activity_clean = select_columns_dataframe(
            df_care_plan_activity, CARE_PLAN_ACTIVITY_COLUMNS
        )
        df_episode_of_care_clean = select_columns_dataframe(
            df_episode_of_care, EPISODE_OF_CARE_COLUMNS
        )
        df_bookable_resource_clean = select_columns_dataframe(
            df_bookable_resource, BOOKABLE_RESOURCE_COLUMNS
        )
        df_care_plan_template_clean = select_columns_dataframe(
            df_care_plan_template, CARE_PLAN_TEMPLATE_COLUMNS
        )
        df_feedback_clean = select_columns_dataframe(
            df_feedback, FEEDBACK_COLUMNS
        )
        df_encounter_clean = select_and_rename_columns(
            df_encounter, ENCOUNTER_COLUMNS
        )
        df_appointment_clean = select_columns_dataframe(
            df_appointment, APPOINTMENT_EMR_COLUMNS
        )
        df_userconsent_clean = select_and_rename_columns(
            df_userconsent, USER_CONSENT_COLUMNS
        )
    except Exception as e:
        raise

    # Step 3.5 drop inactive encounters, keep only active encounters
    df_encounter_clean = df_encounter_clean[df_encounter_clean["encounter_statecode"]== 0] # 0: Active
    # Step 4: Merge tables
    try:
        df_merged = df_care_plan_activity_clean.merge(
            df_care_plan_clean,
            how="left",
            left_on="msemr_careplan",
            right_on="msemr_careplanid",
        )
        df_merged = df_merged.merge(
            df_care_plan_template_clean,
            how="left",
            on="mmhci_drupal_program_id"
        )
        
        df_merged["msemr_ve_episodeofcare"] = df_merged["msemr_ve_episodeofcare"].astype("string")
        df_episode_of_care_clean["msemr_episodeofcareid"] = df_episode_of_care_clean["msemr_episodeofcareid"].astype("string")
        
        df_merged = df_merged.merge(
            df_episode_of_care_clean,
            how="left",
            left_on="msemr_ve_episodeofcare",
            right_on="msemr_episodeofcareid",
        )
        df_merged = df_merged.merge(
            df_bookable_resource_clean,
            how="left",
            left_on="mmhci_primarypractitioner",
            right_on="bookableresourceid",
        )
        df_merged = df_merged.merge(
            df_feedback_clean,
            how="left",
            left_on="msemr_careplanactivityid",
            right_on="mmhci_regardingid"
        )
        df_merged = df_merged.merge(
            df_encounter_clean,
            how="left",
            left_on="msemr_careplanactivityid",
            right_on="mmhci_careplanactivity"
        )
        df_merged = df_merged.merge(
            df_appointment_clean,
            how="left",
            left_on="msemr_appointmentemr",
            right_on="activityid"
        )
        df_merged = df_merged.merge(
            df_userconsent_clean,
            how="left",
            left_on="msemr_patientidentifier",
            right_on="user_consent_personid"
        )
    except Exception as e:
        raise

    # Step 4.5: Filter one help seekers that have provided consent for data collection
    df_merged = df_merged[df_merged["user_consent_statuscode"] == 1]  #check consent has been granted (1=consent granted)
    df_merged = df_merged[df_merged["consent_purposeid"]== CONSENT_PROVIDED] # Privacy, collection notice and terms of use (GUID)

    # Step 5: Apply transformations and extraction logic to birthdate, CALD status and request for accessibility service
    try:
        # Logic to filter the table to msemr_careplanactivityid where mmhci_activitydefinitiontype is equals to Module. This is the primary key
        df_merged["msemr_activitydefinitiontype"] = df_merged[
            "msemr_activitydefinitiontype"
        ].map(APPOINTMENT_TYPE)

        dt_utc = pd.to_datetime(df_merged["mmhci_appointmentstarttime"], errors="coerce", utc=True)

        # convert to Melbourne time then keeps rows up until yesterday
        dt_local = dt_utc.dt.tz_convert("Australia/Melbourne")
        dt_local_date = dt_local.dt.normalize()

        today_local = pd.Timestamp.now(tz="Australia/Melbourne").normalize()

        # KEEP rows where:
        # - date is missing (NaT), OR
        # - date is before today (i.e., <= yesterday)
        mask = dt_local.isna() | (dt_local_date < today_local)
        df_merged = df_merged.loc[mask].copy()

        # Only format AFTER filtering
        df_merged["mmhci_appointmentstarttime"] = dt_local.dt.strftime("%Y-%m-%d")
        df_merged = df_merged.assign(**DEFAULT_COLUMN_VALUES)
    except Exception as e:
        raise

    # Step 5: Apply transformations and extraction logic to birthdate, CALD status and request for accessibility service
    try:
        # df_merged["Duration"] = pd.to_datetime(df_merged["mmhci_appointmentendtime"]) - pd.to_datetime(df_merged["msemr_activitystartdate"])
        df_merged["msemr_activitystartdate"] = pd.to_datetime(
            df_merged["msemr_activitystartdate"], utc=True, errors="coerce"
        ).dt.strftime("%Y-%m-%d")

        # modality R3 mapping
        # 0= telehealth, 1=phone
        conditions = [
            (df_merged["msemr_activitydefinitiontype"] == "Appointment")
            & (df_merged["mmhci_preferredappointmentchannel"] == 0),

            (df_merged["msemr_activitydefinitiontype"] == "Appointment")
            & (df_merged["mmhci_preferredappointmentchannel"] == 1),

            df_merged["msemr_activitydefinitiontype"] == "Module",

            df_merged["msemr_activitydefinitiontype"] == "Appointment",
        ]
        # 3=Video, 2=telephone, 4=Internet-based
        choices = [3,2,4,3]
        df_merged["Modality"] = (
            np.select(conditions, choices, default=None)
        )

        # type R3 mapping
        # 6: guided
        # 7: self-guided
        type_conditions = [
            df_merged["statuscode"] == 100000011,
            df_merged["mmhci_pathwaytype"] == 6,
            df_merged["mmhci_pathwaytype"] == 7
        ]
        type_choices = [0,1,2]
        df_merged["Type"] = (
            np.select(type_conditions, type_choices, default=None)
        )

        # Accessibility service R3 mapping
        df_merged["Accessibility service"] = np.where(
            df_merged["mmhci_interpreterrequired"] == True,
            3, #if true
            0, #else false
        )

        # Final service contact of LiCBT course R3 mapping
        # 0 = Active, 1=Inactive
        df_merged["Final service contact of LiCBT course"] = np.select(
            [
                df_merged["statecode"] == 0,
                df_merged["statecode"] == 1
            ],
            [
                2, # Further services are planned for the client in the current course
                1, # No further services are planned for the client in the current course
            ],
            default=None
        )

        # Completion status R3 mapping
        df_merged["Completion status"] = (
            df_merged["msemr_activitystatus"].map({
                935000000 : 0, # Not started: Module not started
                935000001 : 1, # Released : Module partially completed
                935000004 : 2, # Completed: Module completed
                935000005 : 3, # Cancelled: Did not complete
            })
        ).fillna(0).astype("Int64")

        df_merged = df_merged.assign(**DEFAULT_COLUMN_VALUES)

        # Feedback rating mapping
        df_merged["mmhci_howhelpfulwereactivitiestowardsgoal"] = (
            df_merged["mmhci_howhelpfulwereactivitiestowardsgoal"].map(
                {
                    100000000 : 1, # 1 star - very poor/very dissatisfied
                    100000001 : 2, # 2 star - poor/dissatisfied
                    100000002 : 3, # 3 star - fair / neutral / average
                    100000003 : 4, # 4 star - good / satisfied
                    100000004 : 5  # 5 star - excellent / very satisfied
                }
            )
        )

        # Appointment start and end times
        mask = df_merged["msemr_activitydefinitiontype"].eq("Appointment")
        df_merged.loc[mask, "Start timestamp"] = df_merged.loc[mask, "actualstart"]
        df_merged.loc[mask, "Completion timestamp"] = df_merged.loc[mask, "actualend"]

        # Appointment duration calculation
        mask_appt = (
            df_merged["msemr_activitydefinitiontype"].eq("Appointment")
            & df_merged["actualstart"].notna()
            & df_merged["actualend"].notna()
        )

        df_merged.loc[mask_appt, "Duration"] = (
            (
                pd.to_datetime(df_merged.loc[mask_appt, "actualend"], utc=True, errors="coerce")
                - pd.to_datetime(df_merged.loc[mask_appt, "actualstart"], utc=True)
            )
            .dt.total_seconds()
            .div(60)
            .round()
            .astype("Int64")
        )

        # Module default duration
        mask_module = df_merged["msemr_activitydefinitiontype"].eq("Module")
        df_merged.loc[mask_module, "Duration"] = 120
    except Exception as e:
        raise

    # Service provder key
    df_merged["msemr_organization"] = ORGANISATION_ID
    # df_merged["Accessibility service"] = None
    df_merged["Venue"] = None
    df_merged["_activity_type"] = df_merged["msemr_activitydefinitiontype"]
    # Step 6: Select columns to keep in the final table and rename
    columns_mapping = {
        "msemr_careplanactivityid": "Service contact key",
        "msemr_organization": "Service provider organisation key",
        "msemr_careplan": "Course of LiCBT key",
        "bookableresourceid": "Practitioner key",
        "mmhci_appointmentstarttime": "Date",
        "Type": "Type",
        "Modality": "Modality",
        "Venue": "Venue",
        "Duration": "Duration",
        "statuscode": "Client participation indicator",
        "Accessibility service": "Accessibility service",
        "msemr_careplantemplateid": "Workbook ID",
        "msemr_careplanactivity": "Module ID",
        "Start timestamp": "Start timestamp",
        "Completion timestamp": "Completion timestamp",
        "Completion status": "Completion status",
        "mmhci_howhelpfulwereactivitiestowardsgoal": "Feedback rating",
        "Final service contact of LiCBT course": "Final service contact of LiCBT course",
        "_activity_type": "_activity_type",  # temp
    }
    
    df_merged = select_and_rename_columns(df_merged, columns_mapping)
    df_merged = df_merged.drop_duplicates()
    
    for col in ["Start timestamp", "Completion timestamp"]:
        if col not in df_merged.columns:
            df_merged[col] = None

    # Only Modules 
    module_mask = df_merged["_activity_type"].eq("Module")

    careplanactivity_ids = (
        df_merged.loc[module_mask, "Service contact key"]
        .dropna()
        .astype(str)
        .unique()
        .tolist()
    )

    # Normalise keys once (keep for mapping, drop later)
    df_merged["service_contact_key_norm"] = (
        df_merged["Service contact key"]
        .astype(str)
        .str.strip()
        .str.strip("{}")
    )

    #AUDITS

    # START TIMESTAMP: Not Started -> Released (Modules only)
    audits_start = fetch_audit_logs_for_object_ids(
        df_audit_start, 
        changedata_filter=activitystatus_notstarted_to_released
        )

    return audits_start
    # if not audits_start.empty:
    print("not empty")
    audits_start["createdon_dt"] = pd.to_datetime(
        audits_start["createdon"], utc=True, errors="coerce"
    )

    start_ts = (
        audits_start
        .dropna(subset=["createdon_dt"])
        .sort_values("createdon_dt")
        .groupby("_objectid_value_norm", as_index=False)["createdon_dt"]
        .first()
        .rename(columns={
            "_objectid_value_norm": "service_contact_key_norm",
            "createdon_dt": "Start timestamp"
        })
    )

    start_map = start_ts.set_index("service_contact_key_norm")["Start timestamp"]

    # Write back to Module rows
    df_merged.loc[module_mask, "Start timestamp"] = (
        df_merged.loc[module_mask, "service_contact_key_norm"].map(start_map)
    )
    # else:
    #     # only set missing module rows to None
    #     df_merged.loc[module_mask, "Start timestamp"] = None

    # COMPLETION TIMESTAMP: Released -> Completed (Modules only)
    audits_comp = fetch_audit_logs_for_object_ids(
        df_audit_end,
        changedata_filter=activitystatus_released_to_completed,
        )

    if not audits_comp.empty:
        audits_comp["createdon_dt"] = pd.to_datetime(
            audits_comp["createdon"], utc=True, errors="coerce"
        )

        completion_ts = (
            audits_comp
            .dropna(subset=["createdon_dt"])
            .sort_values("createdon_dt")
            .groupby("_objectid_value_norm", as_index=False)["createdon_dt"]
            .first()
            .rename(columns={
                "_objectid_value_norm": "service_contact_key_norm",
                "createdon_dt": "Completion timestamp"
            })
        )

        comp_map = completion_ts.set_index("service_contact_key_norm")["Completion timestamp"]

        # Write back to Module rows
        df_merged.loc[module_mask, "Completion timestamp"] = (
            df_merged.loc[module_mask, "service_contact_key_norm"].map(comp_map)
        )
    else:
        df_merged.loc[module_mask, "Completion timestamp"] = None

    # export debug audits
    # audits_start.to_csv("output/careplanactivity_status_start_debug.csv", index=False)
    # audits_comp.to_csv("output/careplanactivity_status_completion_debug.csv", index=False)

    # cleanup
    df_merged = df_merged.drop(columns=["service_contact_key_norm"], errors="ignore")

    # export debug audits
    # audits_start.to_csv("output/careplanactivity_status_start_debug.csv", index=False)
    # audits_comp.to_csv("output/careplanactivity_status_completion_debug.csv", index=False)
        
    # Format timestamps
    for col in ["Start timestamp", "Completion timestamp"]:
        dt = pd.to_datetime(df_merged[col], utc=True, errors="coerce")
        dt_local = dt.dt.tz_convert("Australia/Melbourne")
        df_merged[col] = dt_local.dt.strftime("%Y-%m-%d %H:%M:%S")
        df_merged.loc[df_merged[col].isna(), col] = None

    df_merged = df_merged.drop(columns=["_activity_type"], errors="ignore")
    # Step 6: Export processed output to CSV
    df_merged.to_csv(OUTPUT_FILE, index=False)
    return df_merged

process_service_contact()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "jupyter_python"
# META }
