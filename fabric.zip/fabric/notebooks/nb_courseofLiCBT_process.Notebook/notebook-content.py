# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "jupyter",
# META     "jupyter_kernel_name": "python3.12"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "2a4f1954-6c84-4327-9d1b-5090e493e152",
# META       "default_lakehouse_name": "lh_mmhci_datahub_dev",
# META       "default_lakehouse_workspace_id": "1ba3ebd5-d835-4cdc-85d9-80feb379778e",
# META       "known_lakehouses": [
# META         {
# META           "id": "2a4f1954-6c84-4327-9d1b-5090e493e152"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

# Table name for file export
TABLE_NAME = "CourseofLiCBT"

# Constant values
ORGANISATION_ID = "SVHA-MMHCI-01"

# IMPORTANT:
# Replace this value with the same CONSENT_PROVIDED GUID/value from your existing config.py.
# Keep it in lower-case because the existing logic compares with CONSENT_PROVIDED.lower().
CONSENT_PROVIDED = "D0FA4878-5B14-F111-8341-000D3A794D28"

# Lakehouse paths
RAW_BASE_PATH = "/lakehouse/default/Files/raw/Dataverse/05/2026/course_of_licbt"
PROCESSED_BASE_PATH = "/lakehouse/default/Files/processed/Dataverse/05/2026"

# Input file paths
# Update only the file names below if your raw files are named differently in OneLake.
CARE_PLAN_FILE = f"{RAW_BASE_PATH}/msemr_careplan.parquet"
USER_CONSENT_FILE = f"{RAW_BASE_PATH}/mmhci_userconsent.parquet"
CARE_PLAN_TEMPLATE_FILE = f"{RAW_BASE_PATH}/msemr_careplantemplate.parquet"
EPISODE_OF_CARE_FILE = f"{RAW_BASE_PATH}/msemr_episodeofcare.parquet"

# Output file path
OUTPUT_FILE = f"{PROCESSED_BASE_PATH}/{TABLE_NAME}.csv"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "jupyter_python"
# META }

# CELL ********************

%run nb_generic_loggers


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "jupyter_python"
# META }

# CELL ********************

logger, LOG_FILE = setup_lakehouse_logger(
    table_name=TABLE_NAME,
    source_system="Dataverse",
    month="05",
    year="2026",
    log_level="DEBUG",
    console_log_level="INFO",
    file_log_level="DEBUG"
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "jupyter_python"
# META }

# CELL ********************

import pandas as pd


# Table columns
CARE_PLAN_COLUMNS = {
    "msemr_careplanid": "msemr_careplanid",
    "msemr_episodeofcare": "msemr_episodeofcare",
    "msemr_careplantemplate": "msemr_careplantemplate",
    "msemr_patientidentifier": "msemr_patientidentifier",
    "msemr_planenddate": "msemr_planenddate",
    "msemr_ve_episodeofcare": "msemr_ve_episodeofcare",
    "statuscode": "care_plan_status_code",
    "mmhci_drupal_program_id": "care_plan_mmhci_drupal_program_id",
}

USER_CONSENT_COLUMNS = {
    "mmhci_personid": "mmhci_personid",
    "mmhci_userconsentid": "mmhci_userconsentid",
    "mmhci_consentpurposeid": "mmhci_consentpurposeid",
    "statuscode": "user_consent_statuscode",
}

CARE_PLAN_TEMPLATE_COLUMNS = [
    "msemr_careplantemplateid",
    "mmhci_drupal_program_id",
]

EPISODE_OF_CARE_COLUMNS = [
    "statuscode",
    "msemr_organization",
    "msemr_episodeofcareid",
]

EPISODE_OF_CARE_STATUS_CODE_COLUMN = "statuscode"
EPISODE_OF_CARE_ORGANISATION_COLUMN = "msemr_organization"

# Key columns for merging
CARE_PLAN_KEY = {
    "fk_care_plan_template_id": "care_plan_mmhci_drupal_program_id",
    "fk_episode_of_care_id": "msemr_ve_episodeofcare",
    "fk_patient_identifier_id": "msemr_patientidentifier",
}
CARE_PLAN_TEMPLATE_KEY = "mmhci_drupal_program_id"
EPISODE_OF_CARE_KEY = "msemr_episodeofcareid"
USER_CONSENT_KEY = "mmhci_personid"

# DOH extraction logic mapping
LICBT_COMPLETION_STATUS_DOH_MAPPING = {
    100000001: 0,
    1: 2,
    100000002: 0,
    2: 6,
    100000009: 2,
    100000003: 1,
    100000006: 6,
    100000007: 6,
    100000005: 5,
    None: 7,
}

# Final mapping
FINAL_COLUMNS_MAPPING = {
    "msemr_careplanid": "Course of LiCBT key",
    "msemr_organization": "Service provider organisation key",
    "msemr_patientidentifier": "Client key",
    "mmhci_userconsentid": "Privacy preference key",
    "msemr_careplantemplateid": "Workbook ID",
    "msemr_planenddate": "Course of LiCBT end date",
    "statuscode": "Course of LiCBT completion status",
}


def read_lakehouse_file(file_path: str) -> pd.DataFrame:
    """
    Read a Lakehouse file into a pandas DataFrame.
    Supports parquet and csv input files.
    """
    if file_path.lower().endswith(".parquet"):
        return pd.read_csv(file_path)
    return pd.read_csv(file_path)


def select_columns_dataframe(df: pd.DataFrame, columns: list) -> pd.DataFrame:
    """
    Select required columns from a DataFrame.
    """
    if df.empty:
        return df

    df = df.loc[:, ~df.columns.str.startswith("@")]

    return df[columns]


def select_and_rename_columns(df: pd.DataFrame, columns_mapping: dict) -> pd.DataFrame:
    """
    Select and rename columns in a DataFrame.
    """
    if df.empty:
        return df
        
    df = df.loc[:, ~df.columns.str.startswith("@")]

    selected_columns = list(columns_mapping.keys())
    df_selected = df[selected_columns]
    df_renamed = df_selected.rename(columns=columns_mapping)

    return df_renamed

def process_course_of_licbt() -> pd.DataFrame:
    """
    Process the Course of LiCBT table by extracting, transforming and loading data
    from multiple dependent tables.

    Returns:
        pd.DataFrame: Processed Course of LiCBT table.
    """

    logger.info("Starting Course of LiCBT table processing.")

    # Step 1: Read data from dependent Lakehouse files
    try:
        logger.info("Step 1 started: Reading dependent Lakehouse files.")

        logger.info(f"Reading Care Plan file: {CARE_PLAN_FILE}")
        df_care_plan = read_lakehouse_file(CARE_PLAN_FILE)
        logger.info(f"Care Plan rows read: {len(df_care_plan)}")

        logger.info(f"Reading User Consent file: {USER_CONSENT_FILE}")
        df_user_consent = read_lakehouse_file(USER_CONSENT_FILE)
        logger.info(f"User Consent rows read: {len(df_user_consent)}")

        logger.info(f"Reading Care Plan Template file: {CARE_PLAN_TEMPLATE_FILE}")
        df_care_plan_template = read_lakehouse_file(CARE_PLAN_TEMPLATE_FILE)
        logger.info(f"Care Plan Template rows read: {len(df_care_plan_template)}")

        logger.info(f"Reading Episode of Care file: {EPISODE_OF_CARE_FILE}")
        df_episode_of_care = read_lakehouse_file(EPISODE_OF_CARE_FILE)
        logger.info(f"Episode of Care rows read: {len(df_episode_of_care)}")

        logger.info("Step 1 completed: All dependent Lakehouse files read successfully.")

    except Exception as e:
        logger.exception(f"Error reading dependent files: {e}")
        raise

    try:
        logger.info("Step 2 started: Cleaning and selecting required columns.")

        df_care_plan_clean = select_and_rename_columns(
            df_care_plan,
            CARE_PLAN_COLUMNS
        )
        logger.info(f"Care Plan clean rows: {len(df_care_plan_clean)}")
        logger.info(f"Care Plan clean columns: {list(df_care_plan_clean.columns)}")

        df_user_consent_clean = select_and_rename_columns(
            df_user_consent,
            USER_CONSENT_COLUMNS,
        )
        logger.info(f"User Consent clean rows: {len(df_user_consent_clean)}")
        logger.info(f"User Consent clean columns: {list(df_user_consent_clean.columns)}")

        df_care_plan_template_clean = select_columns_dataframe(
            df_care_plan_template,
            CARE_PLAN_TEMPLATE_COLUMNS,
        )
        logger.info(f"Care Plan Template clean rows: {len(df_care_plan_template_clean)}")
        logger.info(
            f"Care Plan Template clean columns: {list(df_care_plan_template_clean.columns)}"
        )

        df_episode_of_care_clean = select_columns_dataframe(
            df_episode_of_care,
            EPISODE_OF_CARE_COLUMNS,
        )
        logger.info(f"Episode of Care clean rows: {len(df_episode_of_care_clean)}")
        logger.info(
            f"Episode of Care clean columns: {list(df_episode_of_care_clean.columns)}"
        )

        logger.info("Step 2 completed: Required columns selected successfully.")

    except Exception as e:
        logger.exception(f"Error cleaning and selecting columns: {e}")
        raise

    try:
        logger.info("Step 2.5 started: Replacing null merge key values with blank.")

        df_care_plan_clean["msemr_ve_episodeofcare"] = (
            df_care_plan_clean["msemr_ve_episodeofcare"]
            .fillna("")
            .astype(str)
            .str.strip()
        )

        df_episode_of_care_clean["msemr_episodeofcareid"] = (
            df_episode_of_care_clean["msemr_episodeofcareid"]
            .fillna("")
            .astype(str)
            .str.strip()
        )

        logger.info("Step 2.5 completed: Merge key null handling completed.")

    except Exception as e:
        logger.exception(f"Error replacing null merge key values: {e}")
        raise

    try:
        logger.info("Step 3 started: Merging dependent tables.")

        df_merged = df_care_plan_clean.merge(
            df_care_plan_template_clean,
            how="left",
            left_on=CARE_PLAN_KEY["fk_care_plan_template_id"],
            right_on=CARE_PLAN_TEMPLATE_KEY,
        )
        logger.info(f"Rows after Care Plan Template merge: {len(df_merged)}")

        df_merged = df_merged.merge(
            df_episode_of_care_clean,
            how="left",
            left_on=CARE_PLAN_KEY["fk_episode_of_care_id"],
            right_on=EPISODE_OF_CARE_KEY,
        )
        logger.info(f"Rows after Episode of Care merge: {len(df_merged)}")

        df_merged = df_merged.merge(
            df_user_consent_clean,
            how="left",
            left_on=CARE_PLAN_KEY["fk_patient_identifier_id"],
            right_on=USER_CONSENT_KEY,
        )
        logger.info(f"Rows after User Consent merge: {len(df_merged)}")

        logger.info("Step 3 completed: All table merges completed successfully.")

    except Exception as e:
        logger.exception(f"Error merging tables: {e}")
        raise

    try:
        logger.info("Step 4 started: Applying consent filters.")

        before_status_filter_count = len(df_merged)

        df_merged = df_merged[df_merged["user_consent_statuscode"] == 1]

        after_status_filter_count = len(df_merged)

        logger.info(f"Rows before consent status filter: {before_status_filter_count}")
        logger.info(f"Rows after consent status filter: {after_status_filter_count}")

        before_consent_purpose_filter_count = len(df_merged)

        df_merged = df_merged[
            df_merged["mmhci_consentpurposeid"] == CONSENT_PROVIDED
        ]

        after_consent_purpose_filter_count = len(df_merged)

        logger.info(
            f"Rows before consent purpose filter: {before_consent_purpose_filter_count}"
        )
        logger.info(
            f"Rows after consent purpose filter: {after_consent_purpose_filter_count}"
        )

        logger.info("Step 4 completed: Consent filters applied successfully.")

    except Exception as e:
        logger.exception(f"Error applying consent filters: {e}")
        raise

    try:
        logger.info("Step 5 started: Applying transformations and extraction logic.")

        if CARE_PLAN_COLUMNS["msemr_planenddate"] in df_merged.columns:
            logger.info("Formatting Course of LiCBT end date.")

            df_merged[CARE_PLAN_COLUMNS["msemr_planenddate"]] = pd.to_datetime(
                df_merged[CARE_PLAN_COLUMNS["msemr_planenddate"]],
                errors="coerce",
                format="mixed"
            ).dt.strftime("%Y-%m-%d")

            logger.info("Course of LiCBT end date formatted successfully.")
        else:
            logger.warning(
                f"Date column {CARE_PLAN_COLUMNS['msemr_planenddate']} not found in merged dataframe."
            )

        logger.info("Mapping Course of LiCBT completion status to DOH values.")

        df_merged[EPISODE_OF_CARE_STATUS_CODE_COLUMN] = df_merged[
            EPISODE_OF_CARE_STATUS_CODE_COLUMN
        ].map(LICBT_COMPLETION_STATUS_DOH_MAPPING)

        df_merged[EPISODE_OF_CARE_STATUS_CODE_COLUMN] = df_merged[
            EPISODE_OF_CARE_STATUS_CODE_COLUMN
        ].astype("Int64")

        logger.info("Course of LiCBT completion status mapped successfully.")

        df_merged[EPISODE_OF_CARE_ORGANISATION_COLUMN] = ORGANISATION_ID
        logger.info("Service provider organisation key populated successfully.")

        logger.info("Step 5 completed: Transformations applied successfully.")

    except Exception as e:
        logger.exception(f"Error applying transformations: {e}")
        raise

    try:
        logger.info("Step 6 started: Selecting final columns and removing duplicates.")

        before_final_selection_count = len(df_merged)

        df_merged = select_and_rename_columns(df_merged, FINAL_COLUMNS_MAPPING)

        logger.info(f"Rows before final column selection: {before_final_selection_count}")
        logger.info(f"Rows after final column selection: {len(df_merged)}")
        logger.info(f"Final output columns: {list(df_merged.columns)}")

        before_duplicate_count = len(df_merged)

        df_merged = df_merged.drop_duplicates()

        after_duplicate_count = len(df_merged)

        logger.info(f"Rows before duplicate removal: {before_duplicate_count}")
        logger.info(f"Rows after duplicate removal: {after_duplicate_count}")

        logger.info("Step 6 completed: Final columns selected and duplicates removed.")

    except Exception as e:
        logger.exception(f"Error selecting final columns or removing duplicates: {e}")
        raise

    try:
        logger.info("Step 7 started: Writing Course of LiCBT output file.")

        df_merged.to_csv(OUTPUT_FILE, index=False)

        logger.info(f"Final Course of LiCBT row count written: {len(df_merged)}")
        logger.info(f"Course of LiCBT output file created successfully: {OUTPUT_FILE}")

        logger.info("Step 7 completed: Output file written successfully.")

    except Exception as e:
        logger.exception(f"Error writing Course of LiCBT output file: {e}")
        raise

    logger.info("Course of LiCBT table processing completed successfully.")

    return df_merged

try:
    process_course_of_licbt()

except Exception as e:
    logger.exception(f"Error reading incoming referral file: {e}")
    raise


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "jupyter_python"
# META }

# CELL ********************


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "jupyter_python"
# META }
