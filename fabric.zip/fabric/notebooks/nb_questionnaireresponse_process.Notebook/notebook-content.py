# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "jupyter",
# META     "jupyter_kernel_name": "python3.12"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "2a4f1954-6c84-4327-9d1b-5090e493e152",
# META       "default_lakehouse_name": "lh_mmhci_datahub_dev",
# META       "default_lakehouse_workspace_id": "1ba3ebd5-d835-4cdc-85d9-80feb379778e",
# META       "known_lakehouses": [
# META         {
# META           "id": "2a4f1954-6c84-4327-9d1b-5090e493e152"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

import pandas as pd

# Table name for file export
TABLE_NAME = "Questionnaireresponse"

# Lakehouse paths
RAW_BASE_PATH = "/lakehouse/default/Files/raw/Dataverse/05/2026/questionnaire_response"
PROCESSED_BASE_PATH = "/lakehouse/default/Files/processed/Dataverse/05/2026"

# Input file paths
QUESTIONNAIRE_FILE = f"{RAW_BASE_PATH}/msemr_questionnaire.parquet"
QUESTIONNAIRE_RESPONSE_FILE = f"{RAW_BASE_PATH}/msemr_questionnaireresponse.parquet"
QUESTIONNAIRE_RESPONSE_ITEM_FILE = f"{RAW_BASE_PATH}/msemr_questionnaireresponseitem.parquet"
QUESTIONNAIRE_RESPONSE_ITEM_ANSWER_FILE = f"{RAW_BASE_PATH}/msemr_questionnaireresponseitemanswer.parquet"

# Output file path
OUTPUT_FILE = f"{PROCESSED_BASE_PATH}/{TABLE_NAME}.csv"

# Constant default variables
QUESTIONNAIRE_RESPONSE = None

# Table columns
QUESTIONNAIRE_COLUMNS = ["msemr_questionnaireid", "msemr_version"]
QUESTIONNAIRE_RESPONSE_COLUMNS = [
    "msemr_questionnaireresponseid",
    "msemr_questionnaire",
]
QUESTIONNAIRE_RESPONSE_ITEM_COLUMNS = [
    "msemr_questionnaireresponseitemid",
    "msemr_questionnaireresponse",
]
QUESTIONNAIRE_RESPONSE_ITEM_ANSWER_COLUMNS = [
    "msemr_questionnaireresponseitemanswerid",
    "mmhci_questionnaireresponse",
    "msemr_questionnaireresponseitem",
]

# Key columns for merging
QUESTIONNAIRE_KEY = "msemr_questionnaireid"
QUESTIONNAIRE_RESPONSE_KEY = {
    "pk_questionnaire_response_id": "msemr_questionnaireresponseid",
    "fk_questionnaire_id": "msemr_questionnaire",
}
QUESTIONNAIRE_RESPONSE_ITEM_KEY = "msemr_questionnaireresponse"
QUESTIONNAIRE_RESPONSE_ITEM_ANSWER_KEY = {
    "fk_questionnaire_response_item_id": "msemr_questionnaireresponseitem",
    "fk_questionnaire_response_id": "mmhci_questionnaireresponse",
}

# TODO: Questionnaire response to be retrieved from database
ADDITIONAL_COLUMNS = {"Response": QUESTIONNAIRE_RESPONSE}

# Mapping of DataFrame columns in order and to their corresponding names for CSV output
FINAL_COLUMNS_MAPPING = {
    "response_key": "Response key",
    "msemr_questionnaireresponseid": "Questionnaire session key",
    "msemr_questionnaireresponseitemid": "Question ID",
    "msemr_questionnaireid": "Questionnaire version",
    "msemr_questionnaireresponseitemanswerid": "Unique question key",
    "Response": "Response",
}

def select_columns_dataframe(df: pd.DataFrame, columns_to_keep: list) -> pd.DataFrame:
    """
    Clean the DataFrame by removing metadata columns and selecting specific columns.

    Parameters:
        df (pd.DataFrame): Input DataFrame.
        columns_to_keep (list): List of columns to retain.

    Returns:
        pd.DataFrame: Cleaned DataFrame with selected columns.
    """
    if df.empty:
        return df
    # Remove metadata columns (e.g., columns starting with "@")
    df_clean = df.loc[:, ~df.columns.str.startswith("@")]
    # Select only the specified columns
    return df_clean[[col for col in columns_to_keep if col in df_clean.columns]]

def select_and_rename_columns(df: pd.DataFrame, columns_mapping: dict) -> pd.DataFrame:
    """
    Select and rename columns in a DataFrame

    Parameters:
        df (pd.DataFrame): Input DataFrame.
        columns_mapping (dict): Dictionary mapping old column names to new column names

    Returns:
        pd.DataFrame: DataFrame with selected and renamed columns
    """
    if df.empty:
        return df
    
    # Remove metadata columns (e.g., columns starting with "@")
    df = df.loc[:, ~df.columns.str.startswith("@")]
    # Select columns based on keys in the mapping
    selected_columns = list(columns_mapping.keys())
    df_selected = df[selected_columns]
    # Rename columns based on the mapping
    df_renamed = df_selected.rename(columns=columns_mapping)
    return df_renamed

def read_lakehouse_file(file_path: str) -> pd.DataFrame:
    """
    Read a Lakehouse file into a pandas DataFrame.
    Supports parquet and csv input files.
    """
    if file_path.lower().endswith(".parquet"):
        return pd.read_csv(file_path)
    return pd.read_csv(file_path)

def process_questionnaire_response() -> pd.DataFrame:
    """
    Process the Questionnaire Response table by extracting, transforming and loading data from multiple dependent tables.

    Parameters:

    Returns:
        pd.DataFrame: Processed Questionnaire Response Table.
    """

    # Step 2: Convert records to DataFrames for transformations
    try:
        df_questionnaire_response_item_answer = read_lakehouse_file(QUESTIONNAIRE_RESPONSE_ITEM_ANSWER_FILE)
        df_questionnaire = read_lakehouse_file(QUESTIONNAIRE_FILE)
        df_questionnaire_response_item = read_lakehouse_file(QUESTIONNAIRE_RESPONSE_ITEM_FILE)
        df_questionnaire_response = read_lakehouse_file(QUESTIONNAIRE_RESPONSE_FILE)
    except Exception as e:
        raise

    # Step 3: Clean, select and rename columns
    try:
        df_questionnaire_response_item_answer_clean = select_columns_dataframe(
            df_questionnaire_response_item_answer,
            QUESTIONNAIRE_RESPONSE_ITEM_ANSWER_COLUMNS,
        )
        df_questionnaire_clean = select_columns_dataframe(
            df_questionnaire, QUESTIONNAIRE_COLUMNS
        )
        df_questionnaire_response_item_clean = select_columns_dataframe(
            df_questionnaire_response_item, QUESTIONNAIRE_RESPONSE_ITEM_COLUMNS
        )
        df_questionnaire_response_clean = select_columns_dataframe(
            df_questionnaire_response, QUESTIONNAIRE_RESPONSE_COLUMNS
        )
    except Exception as e:
        raise

    # Step 4: Merge tables
    try:
        df_merged = df_questionnaire_response_item_answer_clean.merge(
            df_questionnaire_response_clean,
            how="left",
            left_on=QUESTIONNAIRE_RESPONSE_ITEM_ANSWER_KEY[
                "fk_questionnaire_response_id"
            ],
            right_on=QUESTIONNAIRE_RESPONSE_KEY["pk_questionnaire_response_id"],
        )
        df_merged = df_merged.merge(
            df_questionnaire_clean,
            how="left",
            left_on=QUESTIONNAIRE_RESPONSE_KEY["fk_questionnaire_id"],
            right_on=QUESTIONNAIRE_KEY,
        )
        df_merged = df_merged.merge(
            df_questionnaire_response_item_clean,
            how="left",
            left_on=QUESTIONNAIRE_RESPONSE_ITEM_ANSWER_KEY[
                "fk_questionnaire_response_item_id"
            ],
            right_on=QUESTIONNAIRE_RESPONSE_ITEM_KEY,
        )
        # Create response key column, and assign composite key
        df_merged["response_key"] = (
            df_merged["msemr_questionnaireresponseitemanswerid"].astype(str)
            + "_"
            + df_merged["msemr_questionnaireresponseid"].astype(str)
        )
    except Exception as e:
        raise

    # Step 5: Apply transformations
    # Adding in an additional column and default value
    df_merged = df_merged.assign(**ADDITIONAL_COLUMNS)
    df_merged = select_and_rename_columns(df_merged, FINAL_COLUMNS_MAPPING)
    # delete all rows
    df_merged = df_merged.iloc[0:0]

    # Step 6: Export processed output to CSV
    df_merged.to_csv(OUTPUT_FILE, index=False)
    return df_merged

process_questionnaire_response()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "jupyter_python"
# META }
