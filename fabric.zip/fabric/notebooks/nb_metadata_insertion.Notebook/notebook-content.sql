-- Fabric notebook source

-- METADATA ********************

-- META {
-- META   "kernel_info": {
-- META     "name": "synapse_pyspark"
-- META   },
-- META   "dependencies": {
-- META     "lakehouse": {
-- META       "default_lakehouse": "2a4f1954-6c84-4327-9d1b-5090e493e152",
-- META       "default_lakehouse_name": "lh_mmhci_datahub_dev",
-- META       "default_lakehouse_workspace_id": "1ba3ebd5-d835-4cdc-85d9-80feb379778e",
-- META       "known_lakehouses": [
-- META         {
-- META           "id": "2a4f1954-6c84-4327-9d1b-5090e493e152"
-- META         }
-- META       ]
-- META     }
-- META   }
-- META }

-- CELL ********************

INSERT INTO dbo.md_ingestion_config (
    ingestion_config_id,
    ingestion_name,
    source_type,
    connection_name,
    source_object_name,
    source_folder_path,
    source_file_pattern,
    load_type,
    watermark_column,
    watermark_value,
    target_folder_path,
    target_file_name,
    target_format,
    write_mode,
    schedule_group,
    execution_sequence,
    active_flag,
    created_at,
    updated_at
)
VALUES (
    'CFG_COURSE_OF_LICBT_001',
    'Course of LiCBT Load',
    'Dataverse',
    'dataverse_connection',
    'CourseofLiCBT',
    'Files/raw/Dataverse/05/2026/course_of_licbt',
    '*.csv',
    'FULL',
    NULL,
    NULL,
    'Files/processed/Dataverse/05/2026',
    'CourseofLiCBT.csv',
    'csv',
    'overwrite',
    'MONTHLY',
    1,
    true,
    current_timestamp(),
    current_timestamp()
);

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

INSERT INTO dbo.md_ingestion_config (
    ingestion_config_id,
    ingestion_name,
    source_type,
    connection_name,
    source_object_name,
    source_folder_path,
    source_file_pattern,
    load_type,
    watermark_column,
    watermark_value,
    target_folder_path,
    target_file_name,
    target_format,
    write_mode,
    schedule_group,
    execution_sequence,
    active_flag,
    created_at,
    updated_at
)
VALUES (
    'CFG_INTAKE_001',
    'Intake Load',
    'Dataverse',
    'dataverse_connection',
    'Intake',
    'Files/raw/Dataverse/05/2026/intake',
    '*.csv',
    'FULL',
    NULL,
    NULL,
    'Files/processed/Dataverse/05/2026',
    'Intake.csv',
    'csv',
    'overwrite',
    'MONTHLY',
    2,
    true,
    current_timestamp(),
    current_timestamp()
);

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }
