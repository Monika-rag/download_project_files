# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "2a4f1954-6c84-4327-9d1b-5090e493e152",
# META       "default_lakehouse_name": "lh_mmhci_datahub_dev",
# META       "default_lakehouse_workspace_id": "1ba3ebd5-d835-4cdc-85d9-80feb379778e",
# META       "known_lakehouses": [
# META         {
# META           "id": "2a4f1954-6c84-4327-9d1b-5090e493e152"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

import pandas as pd
from utils import (
    setup_logger,
    fetch_records,
    select_columns_dataframe,
    export_to_csv,
    select_and_rename_columns,
    require_columns
)
from config import TABLES, ORGANISATION_ID
from PowerPlatform.Dataverse.client import DataverseClient

# Setup logger
logger = setup_logger(__name__, "logs/practitioner.log")

# Table name for file export
TABLE_NAME = "Practitioner"

# Constant default variables for columns
CATEGORY_DEFAULT = 99  # Default to 99 - Not stated
ABORIGINAL_AND_TORRES_STRAIT_ISLANDER_CULTURAL_TRAINING_DEFAULT = (
    8  # Default to 8 - Not Required
)
COMPLETED_MENTAL_HEALTH_FIRST_AID_TRAINING_DEFAULT = 8  # Default to 8 - Not Required
CLINICAL_ROLE_DEFAULT = None
ACTIVE_DEFAULT = 1
LEVEL_OF_CLINICAL_QUALIFICATION_DEFAULT = None
YEAR_OF_QUALIFICATION_DEFAULT = None
EMPLOYMENT_START_DEFAULT = "2026-03-30"
EMPLOYEMENT_END_DEFAULT = None

# Table Columns
BOOKABLE_RESOURCE_COLUMNS = ["bookableresourceid", "_userid_value"]
SYSTEM_USER_COLUMNS = ["systemuserid", "organizationid"]

# Key columns for merging
BOOKABLE_RESOURCE_KEY = "_userid_value"
SYSTEM_USER_KEY = "systemuserid"

# Mapping of the default values and additional columns
DEFAULT_COLUMN_VALUES = {
    "Category": CATEGORY_DEFAULT,
    "Aboriginal and Torres Strait Islander cultural training": ABORIGINAL_AND_TORRES_STRAIT_ISLANDER_CULTURAL_TRAINING_DEFAULT,
    "Completed Mental Health First Aid training": COMPLETED_MENTAL_HEALTH_FIRST_AID_TRAINING_DEFAULT,
    "Clinical role": CLINICAL_ROLE_DEFAULT,
    "Active": ACTIVE_DEFAULT,
    "Level of clinical qualification": LEVEL_OF_CLINICAL_QUALIFICATION_DEFAULT,
    "Year of qualification": YEAR_OF_QUALIFICATION_DEFAULT,
    "Employment start": EMPLOYMENT_START_DEFAULT,
    "Employment end": EMPLOYEMENT_END_DEFAULT,
    "Year of birth": None,
    "Sex": None,
    "Gender": None,
    "Variations of sex characteristics": None,
    "Sexual orientation": None,
    "Aboriginal and Torres Strait Islander status": None,
    "Language spoken": None,
    "Experience assisting with mental ill-health episodes prior to working on program": None,
    "organizationid": ORGANISATION_ID,
}

# Mapping of DataFrame columns in order and to their corresponding names for CSV output
FINAL_COLUMNS_MAPPING = {
    "bookableresourceid": "Staff key",
    "organizationid": "Service provider organisation key",
    "systemuserid": "Base staff key",
    "Category": "Category",
    "Clinical role": "Clinical role",
    "Aboriginal and Torres Strait Islander cultural training": "Aboriginal and Torres Strait Islander cultural training",
    "Completed Mental Health First Aid training": "Completed Mental Health First Aid training",
    "Year of birth": "Year of birth",
    "Sex": "Sex",
    "Gender": "Gender",
    "Variations of sex characteristics": "Variations of sex characteristics",
    "Sexual orientation": "Sexual orientation",
    "Aboriginal and Torres Strait Islander status": "Aboriginal and Torres Strait Islander status",
    "Language spoken": "Language spoken",
    "Experience assisting with mental ill-health episodes prior to working on program": "Experience assisting with mental ill-health episodes prior to working on program",
    "Active": "Active",
    "Level of clinical qualification": "Level of clinical qualification",
    "Year of qualification": "Year of qualification",
    "Employment start": "Employment start",
    "Employment end": "Employment end",
}


df = spark.read.format("parquet").load(
    "Files/raw/Dataverse/05/2026/mmhci_practitionerpreference"
)

def process_practitioner(df) -> pd.DataFrame:
    """
    Process the Practitioner by cextracting, transforming and loading data from multiple dependent tables.

    Parameters:
        client: Dataverse client object for fetching data.

    Returns:
        pd.DataFrame: Processed Practitioner Preference Table.
    """
    # Step 1: Fetch data from dependent tables
    ##try:
        logger.info("Fetching data from dependent tables...")
        bookable_resource_records = fetch_records(client, TABLES["bookable_resource"])
        system_user_records = fetch_records(client, TABLES["system_user"])
        logger.info("Data fectched successfully from dependent tables.")
    except Exception as e:
        logger.exception(f"Error fetching data from tables: {e}")
        raise

    # Step 2: Convert records to DataFrames for transformations
    try:
        logger.info("Converting records to DataFrames...")
        df_bookable_resource = pd.DataFrame(bookable_resource_records)
        df_system_user = pd.DataFrame(system_user_records)
        logger.info("DataFrames created successfully")
    except Exception as e:
        logger.exception(f"Error converting records to DataFrame: {e}")
        raise

    # Step 2.5 Verify columns exist before selection, raise Key Error otherwise
    require_columns(
        df_bookable_resource,
        BOOKABLE_RESOURCE_COLUMNS,
        TABLES["bookable_resource"]
    )
    require_columns(
        df_system_user,
        SYSTEM_USER_COLUMNS,
        TABLES["system_user"]
    )

    # Step 3: Clean and select columns directly using utility functions
    try:
        logger.info("Cleaning and selecting columns...")
        df_bookable_resource_clean = select_columns_dataframe(
            df_bookable_resource, BOOKABLE_RESOURCE_COLUMNS
        )
        df_system_user_clean = select_columns_dataframe(
            df_system_user, SYSTEM_USER_COLUMNS
        )
        logger.info("Columns cleaned and selected successfully.")
    except Exception as e:
        logger.exception(f"Error cleaning and selecting columns: {e}")
        raise

    # Step 4: Merge tables
    try:
        logger.info("Merging tables...")
        df_merged = df_bookable_resource_clean.merge(
            df_system_user_clean,
            how="left",
            left_on=BOOKABLE_RESOURCE_KEY,
            right_on=SYSTEM_USER_KEY
        )
        logger.info("Tables merged successfully.")
    except Exception as e:
        logger.exception(f"Error merging tables: {e}")
        raise

    # Step 5: Apply transformations and extraction logic
    logger.info("Applying transformations...")
    # Add additional columns and defualt values
    df_merged = df_merged.assign(**DEFAULT_COLUMN_VALUES)

    logger.info("Transformations applied successfully.")

    # Step 6: Select columns to keep in the final table and rename
    df_merged = select_and_rename_columns(df_merged, FINAL_COLUMNS_MAPPING)
    df_merged = df_merged.drop_duplicates()

    return df_merged


def export_practitioner(client: DataverseClient) -> None:
    """
    Process and export the Table to a CSV file with dynamic naming.

    Parameters:
        client: Dataverse client object for fetching data.

    Returns:
        None
    """
    try:
        logger.info("Starting Practitioner export...")
        # Process the table
        df_client = process_practitioner(client)

        # Export the DataFrame to a CSV file
        export_to_csv(df_client, table_name=TABLE_NAME)

        logger.info("Practitioner table exported successfully.")
    except Exception as e:
        logger.error(f"An error occurred while exporting the Practitioner table: {e}")
        raise

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
