# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "jupyter",
# META     "jupyter_kernel_name": "python3.12"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "2a4f1954-6c84-4327-9d1b-5090e493e152",
# META       "default_lakehouse_name": "lh_mmhci_datahub_dev",
# META       "default_lakehouse_workspace_id": "1ba3ebd5-d835-4cdc-85d9-80feb379778e",
# META       "known_lakehouses": [
# META         {
# META           "id": "2a4f1954-6c84-4327-9d1b-5090e493e152"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

import pandas as pd
import os

# Table name for file export
TABLE_NAME = "Questionnairesession"

# Lakehouse paths
RAW_BASE_PATH = "/lakehouse/default/Files/raw/Dataverse/05/2026/questionnaire_session"
PROCESSED_BASE_PATH = "/lakehouse/default/Files/processed/Dataverse/05/2026"

# Input file paths
QUESTIONNAIRE_RESPONSE_FILE = f"{RAW_BASE_PATH}/msemr_questionnaireresponse.parquet"
INCOMING_REFERRAL_FILE = f"{RAW_BASE_PATH}/mmhci_incomingreferral.parquet"
CARE_PLAN_FILE = f"{RAW_BASE_PATH}/msemr_careplan.parquet"
EPISODE_OF_CARE_FILE = f"{RAW_BASE_PATH}/msemr_episodeofcare.parquet"

# Output file path
OUTPUT_FILE = f"{PROCESSED_BASE_PATH}/{TABLE_NAME}.csv"

ORGANISATION_ID = "SVHA-MMHCI-01"

# Constant default variables for columns
CHECK_IN_AWARENESS_PATHWAY_DEFAULT = 4

# Table Columns
QUESTIONNAIRE_RESPONSE = [
    "msemr_status",
    "msemr_source",
    "mmhci_responsedate",
    "msemr_questionnaireresponseid",
    "owningbusinessunit",
    "mmhci_questionnairetype",
    "mmhci_incomingreferralid",
    "msemr_name",
]
INCOMING_REFERRAL_COLUMNS = ["mmhci_incomingreferralid"]
CARE_PLAN_COLUMNS = ["msemr_ve_episodeofcare", "msemr_careplanid"]
EPISODE_OF_CARE_COLUMNS = ["msemr_episodeofcareid", "mmhci_incomingreferral"]

QUESTIONNAIRE_COMPLETION_STATUS = "msemr_status"
QUESTIONNAIRE_DATE = "mmhci_responsedate"

# Table Keys
INCOMING_REFERRAL_KEY = {"pk_incoming_referral_id": "mmhci_incomingreferralid"}
QUESTIONNAIRE_RESPONE_KEY = {
    "fk_incoming_referral_id": "mmhci_incomingreferralid"
}
CARE_PLAN_KEY = {"fk_episode_of_care_id": "msemr_ve_episodeofcare"}
EPISODE_OF_CARE_KEY = {
    "pk_episode_of_care_id": "msemr_episodeofcareid",
    "fk_incoming_referral_id": "mmhci_incomingreferral",
}

# Mapping of the default values and additional columns
DEFAULT_COLUMN_VALUES = {
    "Check In awareness pathway": CHECK_IN_AWARENESS_PATHWAY_DEFAULT,
    "Questionnaire type": None,
    "Course of LiCBT": None,
    "Service provider organisation key": ORGANISATION_ID,
}

# Mapping of DataFrame columns in order and to their corresponding names for CSV output
FINAL_COLUMNS_MAPPING = {
    "msemr_questionnaireresponseid": "Questionnaire session key",
    "mmhci_responsedate": "Questionnaire date",
    "Service provider organisation key": "Service provider organisation key",
    "msemr_source": "Client key",
    "mmhci_incomingreferralid": "Intake key",
    "msemr_careplanid": "Course of LiCBT key",
    "msemr_name": "Questionnaire type",
    "msemr_status": "Questionnaire completion status",
    "Check In awareness pathway": "Check In awareness pathway",
}

QUESTIONNAIRE_TYPE_DOH_MAPPING = {
    "GAD-7 Anxiety": 2,
    "PHQ-9 Depression": 2,
    "K10": 2,
    "IAR-DST": 1,
}

# DOH Extraction logic mapping
# TODO: Add the other statuses in
QUESTIONNAIRE_SESSION_COMPLETION_STATUS_DOH_MAPPING = {
    935000001: 2  # Completed : Completed
}

def select_columns_dataframe(df: pd.DataFrame, columns_to_keep: list) -> pd.DataFrame:
    """
    Clean the DataFrame by removing metadata columns and selecting specific columns.

    Parameters:
        df (pd.DataFrame): Input DataFrame.
        columns_to_keep (list): List of columns to retain.

    Returns:
        pd.DataFrame: Cleaned DataFrame with selected columns.
    """
    if df.empty:
        return df
    # Remove metadata columns (e.g., columns starting with "@")
    df_clean = df.loc[:, ~df.columns.str.startswith("@")]
    # Select only the specified columns
    return df_clean[[col for col in columns_to_keep if col in df_clean.columns]]

def select_and_rename_columns(df: pd.DataFrame, columns_mapping: dict) -> pd.DataFrame:
    """
    Select and rename columns in a DataFrame

    Parameters:
        df (pd.DataFrame): Input DataFrame.
        columns_mapping (dict): Dictionary mapping old column names to new column names

    Returns:
        pd.DataFrame: DataFrame with selected and renamed columns
    """
    if df.empty:
        return df
    
    # Remove metadata columns (e.g., columns starting with "@")
    df = df.loc[:, ~df.columns.str.startswith("@")]
    # Select columns based on keys in the mapping
    selected_columns = list(columns_mapping.keys())
    df_selected = df[selected_columns]
    # Rename columns based on the mapping
    df_renamed = df_selected.rename(columns=columns_mapping)
    return df_renamed

def read_lakehouse_file(file_path: str) -> pd.DataFrame:
    """
    Read a Lakehouse file into a pandas DataFrame.
    Supports parquet and csv input files.
    """
    if file_path.lower().endswith(".parquet"):
        return pd.read_csv(file_path)
    return pd.read_csv(file_path)

def process_questionnaire_session() -> pd.DataFrame:
    """
    Process the Questionnaire Session Table by extracting, transforming and loading data from multiple dependent tables.

    Parameters:

    Returns:
        pd.DataFrame: Processed Questionnaire Session Table.
    """
    # Step 1: Fetch data from lakehouse
    try:
        df_questionnaire_response = read_lakehouse_file(QUESTIONNAIRE_RESPONSE_FILE)
        df_care_plan = read_lakehouse_file(CARE_PLAN_FILE)
        df_incoming_referral = read_lakehouse_file(INCOMING_REFERRAL_FILE)
        df_episode_of_care = read_lakehouse_file(EPISODE_OF_CARE_FILE)
    except Exception as e:
        raise

    # filter incoming_referral to active
    df_incoming_referral = df_incoming_referral[df_incoming_referral["statecode"]== 0] # 0: Active

    # Step 3: Clean, select and rename columns
    try:
        df_questionnaire_response_clean = select_columns_dataframe(
            df_questionnaire_response, QUESTIONNAIRE_RESPONSE
        )
        df_incoming_referral_clean = select_columns_dataframe(
            df_incoming_referral, INCOMING_REFERRAL_COLUMNS
        )
        df_care_plan_clean = select_columns_dataframe(df_care_plan, CARE_PLAN_COLUMNS)
        df_episode_of_care_clean = select_columns_dataframe(
            df_episode_of_care, EPISODE_OF_CARE_COLUMNS
        )
    except Exception as e:
        raise

    # Step 3.5: Drop duplicates
    df_episode_of_care_clean = df_episode_of_care_clean.drop_duplicates(
        subset=["msemr_episodeofcareid", "mmhci_incomingreferral"]
    )
    
    # Ensure merge keys are same type
    df_episode_of_care_clean["msemr_episodeofcareid"] = (
        df_episode_of_care_clean["msemr_episodeofcareid"].astype("string")
    )

    df_care_plan_clean["msemr_ve_episodeofcare"] = (
        df_care_plan_clean["msemr_ve_episodeofcare"].astype("string")
    )

    # Step 4: Merge tables
    try:
        df_merged = df_questionnaire_response_clean.merge(
            df_incoming_referral_clean,
            how="left",
            left_on=QUESTIONNAIRE_RESPONE_KEY["fk_incoming_referral_id"],
            right_on=INCOMING_REFERRAL_KEY["pk_incoming_referral_id"],
        )
        df_merged = df_merged.merge(
            df_episode_of_care_clean,
            how="left",
            left_on=INCOMING_REFERRAL_KEY["pk_incoming_referral_id"],
            right_on=EPISODE_OF_CARE_KEY["fk_incoming_referral_id"],
        )
        df_merged = df_merged.merge(
            df_care_plan_clean,
            how="left",
            left_on=EPISODE_OF_CARE_KEY["pk_episode_of_care_id"],
            right_on=CARE_PLAN_KEY["fk_episode_of_care_id"],
        )
    except Exception as e:
        raise

    # Step 5: Apply transformations
    try:
        # Change date format
        df_merged[QUESTIONNAIRE_DATE] = pd.to_datetime(
            df_merged[QUESTIONNAIRE_DATE],
            format="%Y-%m-%dT%H:%M:%S",
            errors="coerce"
        ).dt.strftime("%Y-%m-%d")
        # Mapping
        df_merged[QUESTIONNAIRE_COMPLETION_STATUS] = df_merged[
            QUESTIONNAIRE_COMPLETION_STATUS
        ].astype("Int64")
        df_merged[QUESTIONNAIRE_COMPLETION_STATUS] = df_merged[
            QUESTIONNAIRE_COMPLETION_STATUS
        ].map(QUESTIONNAIRE_SESSION_COMPLETION_STATUS_DOH_MAPPING)
        df_merged[QUESTIONNAIRE_COMPLETION_STATUS] = df_merged[
            QUESTIONNAIRE_COMPLETION_STATUS
        ].astype("Int64")
        df_merged[QUESTIONNAIRE_COMPLETION_STATUS] = df_merged[
            QUESTIONNAIRE_COMPLETION_STATUS
        ].fillna(0)
        # Default value and additional column
        df_merged = df_merged.assign(**DEFAULT_COLUMN_VALUES)
    except Exception as e:
        raise

    df_merged = select_and_rename_columns(df_merged, FINAL_COLUMNS_MAPPING)
    df_merged["Questionnaire type"] = (
        df_merged["Questionnaire type"]
        .map(QUESTIONNAIRE_TYPE_DOH_MAPPING)
        .astype("Int64")
    )
    df_merged = df_merged.drop_duplicates()
    # delete all rows
    df_merged = df_merged.iloc[0:0]
    
    # Export processed output to CSV
    df_merged.to_csv(OUTPUT_FILE, index=False)
    return df_merged

process_questionnaire_session()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "jupyter_python"
# META }
