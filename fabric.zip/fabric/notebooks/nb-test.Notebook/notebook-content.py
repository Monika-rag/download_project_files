# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "2a4f1954-6c84-4327-9d1b-5090e493e152",
# META       "default_lakehouse_name": "lh_mmhci_datahub_dev",
# META       "default_lakehouse_workspace_id": "1ba3ebd5-d835-4cdc-85d9-80feb379778e",
# META       "known_lakehouses": [
# META         {
# META           "id": "2a4f1954-6c84-4327-9d1b-5090e493e152"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

ws_id = notebookutils.runtime.context.get("currentWorkspaceId")
ws_name = notebookutils.runtime.context.get("currentWorkspaceName")
print(ws_name, ws_id)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Welcome to your new notebook
# Type here in the cell editor to add code!
key_vault_uri = 'https://kv-crm-mmhci-tst-ae-01.vault.azure.net/'
secret_name = 'sp-fabric-to-dataverse-si'

secret = notebookutils.credentials.getSecret(key_vault_uri, secret_name)
#print("Fetched password from key vault is", secret)  

print("✅ AKV access successful")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
