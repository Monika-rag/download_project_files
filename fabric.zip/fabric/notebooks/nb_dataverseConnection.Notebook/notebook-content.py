# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "jupyter",
# META     "jupyter_kernel_name": "python3.12"
# META   },
# META   "dependencies": {}
# META }

# CELL ********************

import requests
import pandas as pd

# ============================================================
# 1. Read secrets from Azure Key Vault
# ============================================================

key_vault_url ="https://kv-crm-mmhci-tst-ae-01.vault.azure.net/"
client_secret = notebookutils.credentials.getSecret(key_vault_url, "sp-fabric-to-dataverse-si")

print(client_secret)
"""dataverse_url_val ="https://orgad765dff.crm6.dynamics.com"
tenant_id = "0efe9a78-ee2f-44a1-aa0f-83011f5d244d"
client_id = "42e0f7fe-b445-41c2-8b9b-8321f4b78dc9"
client_secret = notebookutils.credentials.getSecret(key_vault_url, "sp-fabric-to-dataverse-si")
dataverse_url = "https://orgad765dff.crm6.dynamics.com"

#notebookutils.credentials.getSecret(key_vault_url, "dataverse_url_val").rstrip("/")
#notebookutils.credentials.getSecret(key_vault_url, "b5b79448-8275-4819-9a89-7369faa486a7")
#notebookutils.credentials.getSecret(key_vault_url, "42e0f7fe-b445-41c2-8b9b-8321f4b78dc9")

# ============================================================
# 2. Function to generate token
# ============================================================

def get_dataverse_token():
    token_url = f"https://login.microsoftonline.com/{tenant_id}/oauth2/v2.0/token"

    payload = {
        "client_id": client_id,
        "client_secret": client_secret,
        "grant_type": "client_credentials",
        "scope": f"{dataverse_url}/.default"
    }

    response = requests.post(token_url, data=payload)

    if response.status_code != 200:
        raise Exception(
            f"Token generation failed. "
            f"Status: {response.status_code}, Response: {response.text}"
        )

    return response.json()["access_token"]"""

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "jupyter_python"
# META }

# CELL ********************


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "jupyter_python"
# META }
