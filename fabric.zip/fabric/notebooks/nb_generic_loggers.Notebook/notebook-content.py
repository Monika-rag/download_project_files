# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "jupyter",
# META     "jupyter_kernel_name": "python3.12"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "2a4f1954-6c84-4327-9d1b-5090e493e152",
# META       "default_lakehouse_name": "lh_mmhci_datahub_dev",
# META       "default_lakehouse_workspace_id": "1ba3ebd5-d835-4cdc-85d9-80feb379778e",
# META       "known_lakehouses": [
# META         {
# META           "id": "2a4f1954-6c84-4327-9d1b-5090e493e152"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

import logging
import os
import sys
import re
from datetime import datetime


def clean_file_name(value):
    if value is None or str(value).strip() == "":
        return "unknown"

    return re.sub(r"[^a-zA-Z0-9_\-]", "_", str(value).strip())

def get_log_level(level_name: str):
    """
    Convert log level string to Python logging level.
    Supported levels:
    DEBUG, INFO, WARNING, ERROR, CRITICAL
    """
    level_name = str(level_name).upper().strip()

    return {
        "DEBUG": logging.DEBUG,
        "INFO": logging.INFO,
        "WARNING": logging.WARNING,
        "WARN": logging.WARNING,
        "ERROR": logging.ERROR,
        "CRITICAL": logging.CRITICAL,
    }.get(level_name, logging.INFO)
    
    
    
def setup_lakehouse_logger(
    table_name,
    source_system="Dataverse",
    month="05",
    year="2026",
    log_level="INFO",
    console_log_level=None,
    file_log_level=None,
    log_base_path="/lakehouse/default/Files/logs"
):
    """
    Generic logger setup for Fabric table-load notebooks.

    Logs are written to:
    /lakehouse/default/Files/logs/SourceSystem/MM/YYYY/TableName_timestamp.log
    """

    safe_table_name = clean_file_name(table_name)
    safe_source_system = clean_file_name(source_system)

    log_folder = f"{log_base_path}/{safe_source_system}/{month}/{year}"
    os.makedirs(log_folder, exist_ok=True)

    log_file = f"{log_folder}/{safe_table_name}_{datetime.now().strftime('%Y%m%d')}.log"

    logger_name = f"{safe_table_name}_logger"
    logger = logging.getLogger(logger_name)

    # Default console/file levels to main log_level if not provided
    console_log_level = console_log_level or log_level
    file_log_level = file_log_level or log_level

    main_level = get_log_level(log_level)
    console_level = get_log_level(console_log_level)
    file_level = get_log_level(file_log_level)


    logger.setLevel(min(main_level, console_level, file_level))
    logger.propagate = False

    # Avoid duplicate logs when notebook cells are rerun
    if logger.handlers:
        logger.handlers.clear()

    formatter = logging.Formatter(
        "%(asctime)s | %(levelname)s | %(name)s | %(message)s"
    )

    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(getattr(logging, log_level.upper(), logging.INFO))
    console_handler.setFormatter(formatter)
    # File handler - writes to Lakehouse log file
    file_handler = logging.FileHandler(log_file, mode="a", encoding="utf-8")
    file_handler.setLevel(file_level)
    file_handler.setFormatter(formatter)

    logger.addHandler(console_handler)
    logger.addHandler(file_handler)

    logger.info("Logger initialized successfully.")
    logger.info(f"Log file path: {log_file}")

    return logger, log_file


def log_dataframe_details(logger, df, dataframe_name):
    """
    Logs basic dataframe details.
    """

    try:
        logger.info(f"{dataframe_name} row count: {len(df)}")
        logger.info(f"{dataframe_name} column count: {len(df.columns)}")
        logger.info(f"{dataframe_name} columns: {list(df.columns)}")
    except Exception as e:
        logger.warning(f"Unable to log dataframe details for {dataframe_name}: {e}")


def close_lakehouse_logger(logger):
    """
    Flush and close logger handlers.
    """

    if logger:
        for handler in logger.handlers:
            handler.flush()
            handler.close()

        logger.handlers.clear()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "jupyter_python"
# META }

# CELL ********************


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "jupyter_python"
# META }
