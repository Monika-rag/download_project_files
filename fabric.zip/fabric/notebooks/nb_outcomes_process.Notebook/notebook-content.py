# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "jupyter",
# META     "jupyter_kernel_name": "python3.12"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "2a4f1954-6c84-4327-9d1b-5090e493e152",
# META       "default_lakehouse_name": "lh_mmhci_datahub_dev",
# META       "default_lakehouse_workspace_id": "1ba3ebd5-d835-4cdc-85d9-80feb379778e",
# META       "known_lakehouses": [
# META         {
# META           "id": "2a4f1954-6c84-4327-9d1b-5090e493e152"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

import pandas as pd 

CONSENT_PROVIDED = "D0FA4878-5B14-F111-8341-000D3A794D28"

TABLE_NAME = "Outcomes"

# Lakehouse paths
RAW_BASE_PATH = "/lakehouse/default/Files/raw/Dataverse/05/2026/outcomes"
PROCESSED_BASE_PATH = "/lakehouse/default/Files/processed/Dataverse/05/2026"

# Input file paths
CONTACT_FILE = f"{RAW_BASE_PATH}/contact.parquet"
INCOMING_REFERRAL_FILE = f"{RAW_BASE_PATH}/mmhci_incomingreferral.parquet"
USER_CONSENT_FILE = f"{RAW_BASE_PATH}/mmhci_userconsent.parquet"
CARE_PLAN_FILE = f"{RAW_BASE_PATH}/msemr_careplan.parquet"
CARE_PLAN_ACTIVITY_FILE = f"{RAW_BASE_PATH}/msemr_careplanactivity.parquet"
EPISODE_OF_CARE_FILE = f"{RAW_BASE_PATH}/msemr_episodeofcare.parquet"
QUESTIONNAIRE_FILE = f"{RAW_BASE_PATH}/msemr_questionnaire.parquet"
QUESTIONNAIRE_RESPONSE_FILE = f"{RAW_BASE_PATH}/msemr_questionnaireresponse.parquet"
QUESTIONNAIRE_RESPONSE_ITEM_FILE = f"{RAW_BASE_PATH}/msemr_questionnaireresponseitem.parquet"
QUESTIONNAIRE_RESPONSE_ITEM_ANSWER_FILE = f"{RAW_BASE_PATH}/msemr_questionnaireresponseitemanswer.parquet"

OUTPUT_FILE = f"{PROCESSED_BASE_PATH}/{TABLE_NAME}.csv"

GAD_7_ANXIETY = [
    "Feeling nervous, anxious, or on edge",
    "Not being able to stop or control worrying",
    "Worrying too much about different things",
    "Trouble relaxing",
    "Being so restless that it's hard to sit still",
    "Becoming easily annoyed or irritable",
    "Feeling afraid as if something awful might happen",
]

PHQ_9_DEPRESSION = [
    "Little interest or pleasure in doing things?",
    "Feeling down, depressed, or hopeless?",
    "Trouble falling or staying asleep, or sleeping too much?",
    "Feeling tired or having little energy?",
    "Poor appetite or overeating?",
    "Feeling bad about yourself – or that you are a failure or have let yourself or your family down?",
    "Trouble concentrating on things, such as reading the newspaper or watching television?",
    "Moving or speaking so slowly that other people could have noticed? Or so fidgety or restless that you have been moving a lot more than usual?",
    "Thoughts that you would be better off dead, or thoughts of hurting yourself in some way?"
]

IAR_DST = [
    "domain1",
    "domain2",
    "domain3",
    "domain4",
    "domain5",
    "domain6",
    "domain7",
    "domain8"
]

OUTPUT_MEASURE = {
    "K10" : 1,
    "GAD-7" : 2,
    "GAD-7 Anxiety": 2,
    "PHQ-9" : 3,
    "PHQ-9 Depression" : 3,
    "IAR-DST" : 4,
    "Mood check" : 5
}

QUESTION_ORDER_MAP = {
    "GAD-7": {q: i + 1 for i, q in enumerate(GAD_7_ANXIETY)},
    "PHQ-9": {q: i + 1 for i, q in enumerate(PHQ_9_DEPRESSION)},
    "IAR-DST": {q: i + 1 for i, q in enumerate(IAR_DST)},
}

MEASURE_CANONICAL = {
    "GAD-7 Anxiety": "GAD-7",
    "PHQ-9 Depression": "PHQ-9",
    "IAR-DST": "IAR-DST",
    "K10": "K10",
    "Mood check": "Mood check",
}

REASON_FOR_COLLECTION_MAPPING = {
    4 : 1, # IAR-DST : Pre appointment
    1 : 2, # K10 : During LiCBT course
    2 : 2, # GAD-7 : During LiCBT course
    3 : 2, # PHQ-9: During LiCBT
}

def select_and_rename_columns(df: pd.DataFrame, columns_mapping: dict) -> pd.DataFrame:
    """
    Select and rename columns in a DataFrame

    Parameters:
        df (pd.DataFrame): Input DataFrame.
        columns_mapping (dict): Dictionary mapping old column names to new column names

    Returns:
        pd.DataFrame: DataFrame with selected and renamed columns
    """
    if df.empty:
        return df
    
    # Remove metadata columns (e.g., columns starting with "@")
    df = df.loc[:, ~df.columns.str.startswith("@")]
    # Select columns based on keys in the mapping
    selected_columns = list(columns_mapping.keys())
    df_selected = df[selected_columns]
    # Rename columns based on the mapping
    df_renamed = df_selected.rename(columns=columns_mapping)
    return df_renamed

def read_lakehouse_file(file_path: str) -> pd.DataFrame:
    """
    Read a Lakehouse file into a pandas DataFrame.
    Supports parquet and csv input files.
    """
    if file_path.lower().endswith(".parquet"):
        return pd.read_csv(file_path)
    return pd.read_csv(file_path)

def process_outcomes():
    """
    Process the Client Table by combining data from multiple dependent tables.

    Parameters:

    Returns:
        pd.DataFrame: Processed Client Table.
    """

    # Step 1: Convert records to DataFrames for transformations
    try:
        df_incoming_referral = read_lakehouse_file(INCOMING_REFERRAL_FILE)
        df_episode_of_care = read_lakehouse_file(EPISODE_OF_CARE_FILE)
        df_care_plan = read_lakehouse_file(CARE_PLAN_FILE)
        df_questionnaire_response = read_lakehouse_file(QUESTIONNAIRE_RESPONSE_FILE)
        df_care_plan_activity = read_lakehouse_file(CARE_PLAN_ACTIVITY_FILE)
        df_questionnaireresponseitemanswer = read_lakehouse_file(QUESTIONNAIRE_RESPONSE_ITEM_ANSWER_FILE)
        df_questionnaire = read_lakehouse_file(QUESTIONNAIRE_FILE)
        df_questionnaire_response_item = read_lakehouse_file(QUESTIONNAIRE_RESPONSE_ITEM_FILE)
        df_contact = read_lakehouse_file(CONTACT_FILE)
        df_user_consent = read_lakehouse_file(USER_CONSENT_FILE)
    except Exception as e:
        raise

    # Step 3: Clean and select columns directly using utility functions
    try:
        df_incoming_referral_clean = select_and_rename_columns(
            df_incoming_referral,
            {
                "mmhci_incomingreferralid": "mmhci_incomingreferralid",
                "mmhci_personid": "mmhci_personid",
                "statecode" : "incoming_referral_state_code" #inactive/active column
            },
        )
        df_episode_of_care_clean = select_and_rename_columns(
            df_episode_of_care,
            {
                "statuscode": "statuscode",
                "mmhci_incomingreferral": "mmhci_incomingreferralid",
                "msemr_organization": "Service provider organisation key",
                "msemr_episodeofcareid": "msemr_episodeofcareid",
            },
        )
        df_care_plan_clean = select_and_rename_columns(
            df_care_plan,
            {
                "msemr_careplanid": "Course of LICBT Key",
                "msemr_ve_episodeofcare": "msemr_episodeofcare",
                "statuscode" : "statuscode",
                "createdon" : "createdon"
            },
        )
        df_questionnaire_response_item_clean = select_and_rename_columns(
            df_questionnaire_response_item,
            {
                "msemr_name" : "questionnaire_response_item_question",
                "msemr_questionnaireresponseitemid" : "msemr_questionnaireresponseitemid"
            }
        )
        df_care_plan_activity_clean = select_and_rename_columns(
            df_care_plan_activity, 
            {
                "msemr_careplanactivityid" : "Service contact key",
                "msemr_careplan" : "msemr_careplan",
            }
        )
        df_contact_clean = select_and_rename_columns(
            df_contact,
            {
                "contactid" : "Client key"
            }
        )
        df_user_consent_clean = select_and_rename_columns(
            df_user_consent,
            {
                "mmhci_personid" : "user_consent_personid",
                "mmhci_consentpurposeid" : "mmhci_consentpurposeid",
                "statuscode" : "user_consent_statuscode"
            }
        )

    except Exception as e:
        raise

    # Step 4: Merge tables
    try:
        df_base = df_incoming_referral_clean.merge(
            df_episode_of_care_clean, 
            how="left", 
            on="mmhci_incomingreferralid"
        )

        # right merge on contact here
        df_base = df_base.merge(
            df_contact_clean,
            how="right",
            left_on="mmhci_personid",
            right_on="Client key"
        )

        # merge on user consent here
        df_base = df_base.merge(
            df_user_consent_clean,
            how="left",
            left_on="Client key",
            right_on="user_consent_personid"
        )

        # Step 4.5: Filter one help seekers that have provided consent for data collection
        df_base = df_base[df_base["user_consent_statuscode"] == 1]  #check consent has been granted (1=consent granted)
        df_base = df_base[df_base["mmhci_consentpurposeid"]== CONSENT_PROVIDED] # Privacy, collection notice and terms of use (GUID)

        # Sort care plan based on createdon - grab latest (last)
        df_care_plan_clean = df_care_plan_clean.sort_values(
            ["msemr_episodeofcare", "createdon"],
            ascending=[True, False]
        ).drop_duplicates(subset=["msemr_episodeofcare"], keep="first")

        # Drop values where episode of care value is blank
        df_care_plan_clean = df_care_plan_clean.dropna(
            subset=["msemr_episodeofcare"]
        )        

        df_base["msemr_episodeofcareid"] = df_base["msemr_episodeofcareid"].astype("string")
        df_care_plan_clean["msemr_episodeofcare"] = df_care_plan_clean["msemr_episodeofcare"].astype("string")

        df_base = df_base.merge(
            df_care_plan_clean,
            how="left",
            left_on="msemr_episodeofcareid",
            right_on="msemr_episodeofcare",
            # validate="many_to_one",
        )

        # merge with care plan activity to retrieve careplanactivityid for service contact key
        df_base = df_base.merge(
            df_care_plan_activity_clean,
            how="left",
            left_on= "Course of LICBT Key",
            right_on= "msemr_careplan"
        )

        df_base = df_base.sort_values(
            ["mmhci_incomingreferralid", "createdon"],
            ascending=[True, False]
        ).drop_duplicates(subset=["mmhci_incomingreferralid"], keep="first")

        # Only completed questionnnaire should be used here
        df_questionnaire_response = df_questionnaire_response[
            df_questionnaire_response["statuscode"] == 1 # Completed?
        ]

        df_qr = df_questionnaire_response.merge(
            df_questionnaire,
            left_on="msemr_questionnaire",
            right_on="msemr_questionnaireid",
            how="left",
        )
        df_qr = df_questionnaire_response[
            [
                "msemr_questionnaireresponseid",
                "mmhci_incomingreferralid",
                "mmhci_responsedate",
                "mmhci_totalscore",
                "msemr_name",
                "msemr_questionnaire",
            ]
        ].rename(
            columns={
                "msemr_questionnaireresponseid": "questionnaireresponseid",
                "mmhci_incomingreferralid": "mmhci_incomingreferralid",
                "mmhci_responsedate": "Date",
                "mmhci_totalscore": "Outcome score",
                "msemr_name": "Outcome measure type",
            }
        )

        df_qr = df_qr.merge(
            df_questionnaire,
            left_on="msemr_questionnaire",
            right_on="msemr_questionnaireid",
            how="left",
        )

        df_base = df_qr.merge(df_base, how="left", on="mmhci_incomingreferralid")
        # ------------this is needed to get measure key for question level-------------------
        # msemr_questionnairename
        # ---------- Answer-level: build Outcome response and pivot into columns ----------
        # print(df_questionnaireresponseitemanswer.head)
        # return df_questionnaireresponseitemanswer
        df_outcome_answers = df_questionnaireresponseitemanswer[
            [
                "mmhci_questionnaireresponse",
                "msemr_questionnaireresponseitem", #Question text id
                # "_msemr_questionnaireresponseitemname", #Question text
                "msemr_name",
                "mmhci_measurekey",
                "msemr_valueinteger",
                "msemr_valuedecimal",
                "msemr_valuestring",
            ]
        ].rename(
            columns={"mmhci_questionnaireresponse": "questionnaireresponseid"}
        )

        # Need to merge on df_outcome answers with questionnaire reseponse item
        df_outcome_answers = df_outcome_answers.merge(
            df_questionnaire_response_item_clean,
            how="left",
            left_on="msemr_questionnaireresponseitem",
            right_on="msemr_questionnaireresponseitemid"
        )

        df_outcome_answers = df_outcome_answers[
            [
                "questionnaireresponseid",
                "msemr_questionnaireresponseitem", #Question text?
                # "_msemr_questionnaireresponseitemname", #Question text
                "questionnaire_response_item_question",
                "msemr_name",
                "mmhci_measurekey",
                "msemr_valueinteger",
                "msemr_valuedecimal",
                "msemr_valuestring",
            ]
        ].rename(
            columns={
                     "questionnaire_response_item_question": "question_text" # question text
                     }
        )
        # One response value column (integer/decimal/string)
        df_outcome_answers["Outcome response"] = (
            df_outcome_answers["msemr_valueinteger"]
            .combine_first(df_outcome_answers["msemr_valuedecimal"]) if df_outcome_answers["msemr_valuedecimal"].notna().any() else df_outcome_answers["msemr_valueinteger"]
            .combine_first(df_outcome_answers["msemr_valuestring"]) if df_outcome_answers["msemr_valuestring"].notna().any() else df_outcome_answers["msemr_valueinteger"]
        )

        # Join for reordering of questions
        df_qr["Outcome measure type"] = df_qr["Outcome measure type"].astype(str).str.strip()
        df_qr["Outcome measure type"] = df_qr["Outcome measure type"].map(MEASURE_CANONICAL).fillna(df_qr["Outcome measure type"])
        df_outcome_answers = df_outcome_answers.merge(
            df_qr[["questionnaireresponseid", "Outcome measure type"]],
            on="questionnaireresponseid",
            how="left",
        )

        def map_question_order(row):
            return QUESTION_ORDER_MAP.get(
                row["Outcome measure type"], {}
            ).get(row["question_text"])
            
        df_outcome_answers["question_order"] = df_outcome_answers.apply(
            map_question_order, axis=1
        )

        mapped_measures = set(QUESTION_ORDER_MAP.keys())
        mask_mapped = df_outcome_answers["Outcome measure type"].isin(mapped_measures)

        if df_outcome_answers.loc[mask_mapped, "question_order"].isna().any():
            unmapped = df_outcome_answers.loc[
                mask_mapped & df_outcome_answers["question_order"].isna(),
                ["Outcome measure type", "question_text"]
            ].drop_duplicates()

            # raise ValueError(f"Unmapped questionnaire questions detected:\n{unmapped}")

        # for debugging
        df_outcome_answers["question_with_answer"] = (
            "Q"
            + df_outcome_answers["question_order"].astype("Int64").astype(str)
            + ". "
            + df_outcome_answers["question_text"].astype(str)
            + " → "
            + df_outcome_answers["Outcome response"].astype(str)
        )

        # Build a readable answer for debugging
        df_outcome_answers["Outcome response display"] = (
            df_outcome_answers["Outcome response"].astype(str)
            + " ("
            + df_outcome_answers["msemr_name"].astype(str)  # answer label text
            + ")"
        )


        # Pivot key WITHOUT measurekey (because measurekey is null)
        df_outcome_answers["pivot_question"] = df_outcome_answers[
            "msemr_name"
        ].combine_first(df_outcome_answers["msemr_questionnaireresponseitem"])
        
        before = len(df_outcome_answers)
        df_outcome_answers = df_outcome_answers.dropna(subset=["question_order"])
        after = len(df_outcome_answers)
        print(f"Dropped {before-after} rows due to missing question_order (remaining {after}).")

        df_outcome_answers = df_outcome_answers.drop_duplicates(
            subset=["questionnaireresponseid", "question_order"]
        )
        
        df_outcome_pivot = (
            df_outcome_answers
            .pivot_table(
                index="questionnaireresponseid",
                columns="question_order",
                values="Outcome response",
                aggfunc="first",
            )
            .reset_index()
        )

        df_outcome_answers = df_outcome_answers.dropna(subset=["question_order"]).copy()
        df_outcome_answers["question_order"] = df_outcome_answers["question_order"].astype(int)
        rename_cols = {}
        for c in df_outcome_pivot.columns:
            if c == "questionnaireresponseid":
                continue
            try:
                q = int(float(c))  # handles 1, 1.0, np.int64, "1", "1.0"
                rename_cols[c] = f"Outcome measure question {q} response"
            except (TypeError, ValueError):
                # leave non-numeric columns untouched
                pass

        df_outcome_pivot = df_outcome_pivot.rename(columns=rename_cols)
        # print("Pivot columns after rename:", df_outcome_pivot.columns.tolist()[:20])
        # print("Non-null pivot cells:", df_outcome_pivot.drop(columns=["questionnaireresponseid"], errors="ignore").notna().sum().sum())

        df_outcome_pivot.columns.name = None

        # ---------- Final report = base + pivoted answers ----------
        df_report = df_base.merge(
            df_outcome_pivot, how="left", on="questionnaireresponseid"
        )
        df_report["Service provider organisation key"] = "SVHA-MMHCI-01"

    except Exception as e:
        raise

    df_report["Measure key"] = df_report["questionnaireresponseid"]

    df_report = df_report.rename(
        columns={
            "Course of LICBT Key": "Course of LiCBT key",
            "Outcome score": "Outcome measure score",
            "msemr_name": "Outcome measure type",
        }
    ) 

    # filter incoming_referral to active
    df_report = df_report[df_report["incoming_referral_state_code"]== 0] # 0: Active

    # print(df_outcome_answers["Outcome measure type"].value_counts().head(10))
    # print(df_outcome_answers["question_order"].notna().sum(), "mapped out of", len(df_outcome_answers))
    final_columns = [
        "Measure key",
        "Service provider organisation key",
        "Course of LiCBT key",
        "Client key",
        "Service contact key",
        "Date",
        "Reason for collection",
        "Outcome measure type",
        "Outcome measure question 1 response",
        "Outcome measure question 2 response",
        "Outcome measure question 3 response",
        "Outcome measure question 4 response",
        "Outcome measure question 5 response",
        "Outcome measure question 6 response",
        "Outcome measure question 7 response",
        "Outcome measure question 8 response",
        "Outcome measure question 9 response",
        "Outcome measure question 10 response",
        "Outcome measure score",
    ]

    # keep only columns that actually exist (prevents KeyError)
    df_report = df_report.loc[:, ~df_report.columns.duplicated()]
    df_report = df_report.loc[:, ~df_report.columns.duplicated()]
    df_report = df_report.reindex(columns=final_columns)  # missing columns created with NaN

    # mapping outcome measuretype numeric values

    df_report["Outcome measure type"] = (
        df_report["Outcome measure type"].astype(str).str.strip()
    )

    df_report["Outcome measure type"] = (
        df_report["Outcome measure type"]
        .str.extract(r"(K10|GAD-7 Anxiety|PHQ-9 Depression|IAR-DST|Mood check)", expand=False)
        .fillna(df_report["Outcome measure type"])
    )

    s = df_report["Outcome measure type"].astype("string").str.strip()
    df_report["Outcome measure type"] = (
        pd.to_numeric(s.map(OUTPUT_MEASURE), errors="coerce").astype("Int64")
    )

    # Changing date format to yyyy-mm-dd
    if "Date" in df_report.columns:
        df_report["Date"] = pd.to_datetime(
            df_report["Date"],
            format="%Y-%m-%d",
            errors="coerce"
        ).dt.strftime("%Y-%m-%d")
        
    df_report["Outcome measure question 1 response"] = df_report[
        "Outcome measure question 1 response"
    ].astype("Int64", errors="ignore")
    df_report["Outcome measure question 2 response"] = df_report[
        "Outcome measure question 2 response"
    ].astype("Int64", errors="ignore")
    df_report["Outcome measure question 3 response"] = df_report[
        "Outcome measure question 3 response"
    ].astype("Int64", errors="ignore")
    df_report["Outcome measure question 4 response"] = df_report[
        "Outcome measure question 4 response"
    ].astype("Int64", errors="ignore")
    df_report["Outcome measure question 5 response"] = df_report[
        "Outcome measure question 5 response"
    ].astype("Int64", errors="ignore")
    df_report["Outcome measure question 6 response"] = df_report[
        "Outcome measure question 6 response"
    ].astype("Int64", errors="ignore")
    df_report["Outcome measure question 7 response"] = df_report[
        "Outcome measure question 7 response"
    ].astype("Int64", errors="ignore")
    df_report["Outcome measure question 8 response"] = df_report[
        "Outcome measure question 8 response"
    ].astype("Int64", errors="ignore")
    df_report["Outcome measure question 9 response"] = df_report[
        "Outcome measure question 9 response"
    ].astype("Int64", errors="ignore")
    df_report["Outcome measure question 10 response"] = df_report[
        "Outcome measure question 10 response"
    ].astype("Int64", errors="ignore")
    df_report["Outcome measure score"] = df_report["Outcome measure score"].astype(
        "Int64"
    )
    s = df_report["Outcome measure type"]
    if pd.api.types.is_numeric_dtype(s):
        df_report["Outcome measure type"] = s.astype("Int64")

    df_report["Reason for collection"] = (
        df_report["Outcome measure type"]
        .map(REASON_FOR_COLLECTION_MAPPING).astype("Int64")
    )
    
    # drop duplicate rows
    df_report = df_report.drop_duplicates()
    # Step 6: Export processed output to CSV
    df_report.to_csv(OUTPUT_FILE, index=False)
    return df_report

process_outcomes()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "jupyter_python"
# META }
