# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "2a4f1954-6c84-4327-9d1b-5090e493e152",
# META       "default_lakehouse_name": "lh_mmhci_datahub_dev",
# META       "default_lakehouse_workspace_id": "1ba3ebd5-d835-4cdc-85d9-80feb379778e",
# META       "known_lakehouses": [
# META         {
# META           "id": "2a4f1954-6c84-4327-9d1b-5090e493e152"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

# # Table name for file export
# TABLE_NAME = "Questionnairematerial"

# # Constant default variables for columns
# QUESTION = None  # Default to blank
# QUESTIONNAIRE_VERSION_START_DATE = "2026-03-30"
# QUESTIONNAIRE_VERSION_END_DATE = "2029-03-30"

# # IMPORTANT:
# # Replace this value with the same CONSENT_PROVIDED GUID/value from your existing config.py.
# # Keep it in lower-case because the existing logic compares with CONSENT_PROVIDED.lower().
# CONSENT_PROVIDED = "D0FA4878-5B14-F111-8341-000D3A794D28"

# # Lakehouse paths
# RAW_BASE_PATH = "/lakehouse/default/Files/raw/Dataverse/05/2026/questionnaire_material"
# PROCESSED_BASE_PATH = "/lakehouse/default/Files/processed/Dataverse/05/2026"

# # Input file paths
# # Update only the file names below if your raw files are named differently in OneLake.
# QUESTIONNAIRE_FILE = f"{RAW_BASE_PATH}/msemr_questionnaire.csv"
# QUESTIONNAIRE_RESPONSE_FILE = f"{RAW_BASE_PATH}/msemr_questionnaireresponse.csv"
# QUESTIONNAIRE_RESPONSE_ITEM_FILE = f"{RAW_BASE_PATH}/msemr_questionnaireresponseitem.csv"
# QUESTIONNAIRE_RESPONSE_ITEM_ANSWER_FILE = f"{RAW_BASE_PATH}/msemr_questionnaireresponseitemanswer.csv"

# # Output file path
# OUTPUT_FILE = f"{PROCESSED_BASE_PATH}/{TABLE_NAME}.csv"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# %run nb_generic_loggers

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# logger, LOG_FILE = setup_lakehouse_logger(
#     table_name=TABLE_NAME,
#     source_system="Dataverse",
#     month="05",
#     year="2026"
# )

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

import pandas as pd

# Table name for file export
TABLE_NAME = "Questionnairematerial"

# Constant default variables for columns
QUESTION = None  # Default to blank
QUESTIONNAIRE_VERSION_START_DATE = "2026-03-30"
QUESTIONNAIRE_VERSION_END_DATE = "2029-03-30"

# IMPORTANT:
# Replace this value with the same CONSENT_PROVIDED GUID/value from your existing config.py.
# Keep it in lower-case because the existing logic compares with CONSENT_PROVIDED.lower().
CONSENT_PROVIDED = "D0FA4878-5B14-F111-8341-000D3A794D28"

# Lakehouse paths
RAW_BASE_PATH = "/lakehouse/default/Files/raw/Dataverse/05/2026/questionnaire_material"
PROCESSED_BASE_PATH = "/lakehouse/default/Files/processed/Dataverse/05/2026"

# Input file paths
# Update only the file names below if your raw files are named differently in OneLake.
QUESTIONNAIRE_FILE = f"{RAW_BASE_PATH}/msemr_questionnaire.csv"
QUESTIONNAIRE_RESPONSE_FILE = f"{RAW_BASE_PATH}/msemr_questionnaireresponse.csv"
QUESTIONNAIRE_RESPONSE_ITEM_FILE = f"{RAW_BASE_PATH}/msemr_questionnaireresponseitem.csv"
QUESTIONNAIRE_RESPONSE_ITEM_ANSWER_FILE = f"{RAW_BASE_PATH}/msemr_questionnaireresponseitemanswer.csv"

# Output file path
OUTPUT_FILE = f"{PROCESSED_BASE_PATH}/{TABLE_NAME}.csv"

# Table columns and their corresponding names to be renamed to
QUESTIONNAIRE_COLUMNS = {
    "msemr_questionnaireid": "Questionnaire version",
    # "msemr_version" : "Questionnaire version",
    "msemr_effectiveperiodstart": "Questionnaire version start date",
    "msemr_effectiveperiodend": "Questionnaire version end date",
    "msemr_name": "Questionnaire type",
}
QUESTIONNAIRE_RESPONSE_COLUMNS = {
    # "mmhci_questionnairetype" : "Questionnaire type",
    "msemr_questionnaire": "msemr_questionnaire",
    "msemr_questionnaireresponseid": "msemr_questionnaireresponseid",
}

QUESTIONNAIRE_RESPONSE_ITEM_COLUMNS = {
    "msemr_questionnaireresponseitemid": "Question ID",
    "msemr_questionnaireresponse": "msemr_questionnaireresponse",
}
QUESTIONNAIRE_RESPONSE_ITEM_ANSWER_COLUMNS = {
    "msemr_questionnaireresponseitemanswerid": "Unique question key",
    "mmhci_questionnaireresponse": "mmhci_questionnaireresponse",
    "msemr_questionnaireresponseitem": "msemr_questionnaireresponseitem",
}

# Key columns for merging
QUESTIONNAIRE_RESPONSE_ITEM_ANSWER_KEY = {
    "fk_questionnaire_response_item_id": "msemr_questionnaireresponseitem",
    "fk_questionnaire_response_id": "mmhci_questionnaireresponse",
}
QUESTIONNAIRE_RESPONSE_KEY = {
    "pk_questionnaire_response_id": "msemr_questionnaireresponseid",
    "fk_questionnaire_id": "msemr_questionnaire",
}
QUESTIONNAIRE_KEY = "Questionnaire version"
QUESTIONNAIRE_RESPONSE_ITEM_KEY = "Question ID"

QUESTIONNAIRE_TYPE_DOH_MAPPING = {
    "GAD-7 Anxiety": 2,
    "PHQ-9 Depression": 2,
    "K10": 2,
    "IAR-DST": 1,
}

# Final selected columns for CSV output
FINAL_COLUMNS = [
    "Questionnaire type",
    "Questionnaire version",
    "Questionnaire version start date",
    "Questionnaire version end date",
    "Unique question key",
    "Question ID",
]

def read_lakehouse_file(file_path: str) -> pd.DataFrame:
    """
    Read a Lakehouse file into a pandas DataFrame.
    Supports parquet and csv input files.
    """
    if file_path.lower().endswith(".parquet"):
        return pd.read_csv(file_path)
    return pd.read_csv(file_path)


def select_columns_dataframe(df: pd.DataFrame, columns: list) -> pd.DataFrame:
    """
    Select required columns from a DataFrame.
    """
    if df.empty:
        return df

    # Remove metadata columns, for example columns starting with "@"
    df = df.loc[:, ~df.columns.str.startswith("@")]

    return df[columns]


def select_and_rename_columns(df: pd.DataFrame, columns_mapping: dict) -> pd.DataFrame:
    """
    Select and rename columns in a DataFrame.
    """
    if df.empty:
        return df

    # Remove metadata columns, for example columns starting with "@"
    df = df.loc[:, ~df.columns.str.startswith("@")]

    selected_columns = list(columns_mapping.keys())
    df_selected = df[selected_columns]
    df_renamed = df_selected.rename(columns=columns_mapping)

    return df_renamed


def process_questionnaire_material() -> pd.DataFrame:
    """
     Process the Questionnaire Material table by extracting, transforming and loading data from multiple dependent tables.

    Parameters:
        client: Dataverse client object for fetching data.

    Returns:
        pd.DataFrame: Processed Practitioner Preference Table.
    """
   
    # Step 1: Read data from dependent Lakehouse files
    
    try:
        df_questionnaire = read_lakehouse_file(QUESTIONNAIRE_FILE)
        df_questionnaire_response = read_lakehouse_file(QUESTIONNAIRE_RESPONSE_FILE)
        df_questionnaire_response_item = read_lakehouse_file(QUESTIONNAIRE_RESPONSE_ITEM_FILE)
        df_questionnaire_response_item_answer = read_lakehouse_file(QUESTIONNAIRE_RESPONSE_ITEM_ANSWER_FILE)
    except Exception as e:
        print(f"Error reading dependent files: {e}")
        raise

    # Step 2: Clean and select required columns
    try:
        df_questionnaire_response_clean = select_and_rename_columns(
            df_questionnaire_response, QUESTIONNAIRE_RESPONSE_COLUMNS
        )
        df_questionnaire_clean = select_and_rename_columns(
            df_questionnaire, QUESTIONNAIRE_COLUMNS
        )
        df_questionnaire_response_item_answer_clean = select_and_rename_columns(
            df_questionnaire_response_item_answer,
            QUESTIONNAIRE_RESPONSE_ITEM_ANSWER_COLUMNS,
        )
        df_questionnaire_response_item_clean = select_and_rename_columns(
            df_questionnaire_response_item, QUESTIONNAIRE_RESPONSE_ITEM_COLUMNS
        )
    except Exception as e:
        print(f"Error cleaning and selecting columns: {e}")
        raise

    print(df_questionnaire_response_clean.columns.tolist())
    print(QUESTIONNAIRE_RESPONSE_KEY["fk_questionnaire_id"])

    display(df_questionnaire_response_clean)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

import pandas as pd

# Table name for file export
TABLE_NAME = "Questionnairematerial"

# Constant default variables for columns
QUESTION = None  # Default to blank
QUESTIONNAIRE_VERSION_START_DATE = "2026-03-30"
QUESTIONNAIRE_VERSION_END_DATE = "2029-03-30"

# IMPORTANT:
# Replace this value with the same CONSENT_PROVIDED GUID/value from your existing config.py.
# Keep it in lower-case because the existing logic compares with CONSENT_PROVIDED.lower().
CONSENT_PROVIDED = "D0FA4878-5B14-F111-8341-000D3A794D28"

# Lakehouse paths
RAW_BASE_PATH = "/lakehouse/default/Files/raw/Dataverse/05/2026/questionnaire_material"
PROCESSED_BASE_PATH = "/lakehouse/default/Files/processed/Dataverse/05/2026"

# Input file paths
# Update only the file names below if your raw files are named differently in OneLake.
QUESTIONNAIRE_FILE = f"{RAW_BASE_PATH}/msemr_questionnaire.csv"
QUESTIONNAIRE_RESPONSE_FILE = f"{RAW_BASE_PATH}/msemr_questionnaireresponse.csv"
QUESTIONNAIRE_RESPONSE_ITEM_FILE = f"{RAW_BASE_PATH}/msemr_questionnaireresponseitem.csv"
QUESTIONNAIRE_RESPONSE_ITEM_ANSWER_FILE = f"{RAW_BASE_PATH}/msemr_questionnaireresponseitemanswer.csv"

# Output file path
OUTPUT_FILE = f"{PROCESSED_BASE_PATH}/{TABLE_NAME}.csv"

# Table columns and their corresponding names to be renamed to
QUESTIONNAIRE_COLUMNS = {
    "msemr_questionnaireid": "Questionnaire version",
    # "msemr_version" : "Questionnaire version",
    "msemr_effectiveperiodstart": "Questionnaire version start date",
    "msemr_effectiveperiodend": "Questionnaire version end date",
    "msemr_name": "Questionnaire type",
}
QUESTIONNAIRE_RESPONSE_COLUMNS = {
    # "mmhci_questionnairetype" : "Questionnaire type",
    "msemr_questionnaire": "msemr_questionnaire",
    "msemr_questionnaireresponseid": "msemr_questionnaireresponseid",
}

QUESTIONNAIRE_RESPONSE_ITEM_COLUMNS = {
    "msemr_questionnaireresponseitemid": "Question ID",
    "msemr_questionnaireresponse": "msemr_questionnaireresponse",
}
QUESTIONNAIRE_RESPONSE_ITEM_ANSWER_COLUMNS = {
    "msemr_questionnaireresponseitemanswerid": "Unique question key",
    "mmhci_questionnaireresponse": "mmhci_questionnaireresponse",
    "msemr_questionnaireresponseitem": "msemr_questionnaireresponseitem",
}

# Key columns for merging
QUESTIONNAIRE_RESPONSE_ITEM_ANSWER_KEY = {
    "fk_questionnaire_response_item_id": "msemr_questionnaireresponseitem",
    "fk_questionnaire_response_id": "mmhci_questionnaireresponse",
}
QUESTIONNAIRE_RESPONSE_KEY = {
    "pk_questionnaire_response_id": "msemr_questionnaireresponseid",
    "fk_questionnaire_id": "msemr_questionnaire",
}
QUESTIONNAIRE_KEY = "Questionnaire version"
QUESTIONNAIRE_RESPONSE_ITEM_KEY = "Question ID"

QUESTIONNAIRE_TYPE_DOH_MAPPING = {
    "GAD-7 Anxiety": 2,
    "PHQ-9 Depression": 2,
    "K10": 2,
    "IAR-DST": 1,
}

# Final selected columns for CSV output
FINAL_COLUMNS = [
    "Questionnaire type",
    "Questionnaire version",
    "Questionnaire version start date",
    "Questionnaire version end date",
    "Unique question key",
    "Question ID",
]

def read_lakehouse_file(file_path: str) -> pd.DataFrame:
    """
    Read a Lakehouse file into a pandas DataFrame.
    Supports parquet and csv input files.
    """
    if file_path.lower().endswith(".parquet"):
        return pd.read_csv(file_path)
    return pd.read_csv(file_path)


def select_columns_dataframe(df: pd.DataFrame, columns: list) -> pd.DataFrame:
    """
    Select required columns from a DataFrame.
    """
    if df.empty:
        return df

    # Remove metadata columns, for example columns starting with "@"
    df = df.loc[:, ~df.columns.str.startswith("@")]

    return df[columns]


def select_and_rename_columns(df: pd.DataFrame, columns_mapping: dict) -> pd.DataFrame:
    """
    Select and rename columns in a DataFrame.
    """
    if df.empty:
        return df

    # Remove metadata columns, for example columns starting with "@"
    df = df.loc[:, ~df.columns.str.startswith("@")]

    selected_columns = list(columns_mapping.keys())
    df_selected = df[selected_columns]
    df_renamed = df_selected.rename(columns=columns_mapping)

    return df_renamed


def process_questionnaire_material() -> pd.DataFrame:
    """
     Process the Questionnaire Material table by extracting, transforming and loading data from multiple dependent tables.

    Parameters:
        client: Dataverse client object for fetching data.

    Returns:
        pd.DataFrame: Processed Practitioner Preference Table.
    """
   
    # Step 1: Read data from dependent Lakehouse files
    
    try:
        df_questionnaire = read_lakehouse_file(QUESTIONNAIRE_FILE)
        df_questionnaire_response = read_lakehouse_file(QUESTIONNAIRE_RESPONSE_FILE)
        df_questionnaire_response_item = read_lakehouse_file(QUESTIONNAIRE_RESPONSE_ITEM_FILE)
        df_questionnaire_response_item_answer = read_lakehouse_file(QUESTIONNAIRE_RESPONSE_ITEM_ANSWER_FILE)
    except Exception as e:
        print(f"Error reading dependent files: {e}")
        raise

    # Step 2: Clean and select required columns
    try:
        df_questionnaire_response_clean = select_and_rename_columns(
            df_questionnaire_response, QUESTIONNAIRE_RESPONSE_COLUMNS
        )
        df_questionnaire_clean = select_and_rename_columns(
            df_questionnaire, QUESTIONNAIRE_COLUMNS
        )
        df_questionnaire_response_item_answer_clean = select_and_rename_columns(
            df_questionnaire_response_item_answer,
            QUESTIONNAIRE_RESPONSE_ITEM_ANSWER_COLUMNS,
        )
        df_questionnaire_response_item_clean = select_and_rename_columns(
            df_questionnaire_response_item, QUESTIONNAIRE_RESPONSE_ITEM_COLUMNS
        )
    except Exception as e:
        print(f"Error cleaning and selecting columns: {e}")
        raise

    # # Change this cell with the columns required Replace null values with blank before merging
    df_questionnaire_clean["Questionnaire version start date"] = (
        df_questionnaire_clean["Questionnaire version start date"]
        .fillna("")
        .astype(str)
        .str.strip())

    df_questionnaire_clean["Questionnaire version end date"] = (
        df_questionnaire_clean["Questionnaire version end date"]
        .fillna("")
        .astype(str)
        .str.strip())

    # df_episode_of_care_clean["msemr_episodeofcareid"] = (
    #     df_episode_of_care_clean["msemr_episodeofcareid"]
    #     .fillna("")
    #     .astype(str)
    #     .str.strip())
    
    try:
        df_merged = df_questionnaire_response_item_answer_clean.merge(
            df_questionnaire_response_clean,
            how="left",
            left_on=QUESTIONNAIRE_RESPONSE_ITEM_ANSWER_KEY[
                "fk_questionnaire_response_id"
            ],
            right_on=QUESTIONNAIRE_RESPONSE_KEY["pk_questionnaire_response_id"],
        )
        df_merged = df_merged.merge(
            df_questionnaire_clean,
            how="left",
            left_on=QUESTIONNAIRE_RESPONSE_KEY["fk_questionnaire_id"],
            right_on=QUESTIONNAIRE_KEY,
        )
        df_merged = df_merged.merge(
            df_questionnaire_response_item_clean,
            how="left",
            left_on=QUESTIONNAIRE_RESPONSE_ITEM_ANSWER_KEY[
                "fk_questionnaire_response_item_id"
            ],
            right_on=QUESTIONNAIRE_RESPONSE_ITEM_KEY,
        )
    except Exception as e:
        print(f"Error merging tables: {e}")
        raise
 
    # Step 5: Select columns to keep in the final table
    df_merged["Questionnaire version start date"] = pd.to_datetime(
        df_merged["Questionnaire version start date"]
    ).dt.strftime("%Y-%m-%d")
    df_merged["Questionnaire version end date"] = pd.to_datetime(
        df_merged["Questionnaire version end date"]
    ).dt.strftime("%Y-%m-%d")

    df_merged = select_columns_dataframe(df_merged, FINAL_COLUMNS)
    df_merged["Questionnaire type"] = (
        df_merged["Questionnaire type"]
        .map(QUESTIONNAIRE_TYPE_DOH_MAPPING)
        .astype("Int64")
    )
    df_merged = df_merged.assign(**DEFAULT_COLUMN_VALUES)
    df_merged = df_merged[df_merged["Questionnaire version"].notna()]
    # delete all rows
    df_merged = df_merged.iloc[0:0]
    return df_merged

    # Step 6: Export processed output to CSV
    df_merged.to_csv(OUTPUT_FILE, index=False)

    return df_merged

try:
    process_questionnaire_material()

except Exception as e:
    print(f"Error in Questionnaire_material: {e}")
    raise

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
