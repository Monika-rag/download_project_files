# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "jupyter",
# META     "jupyter_kernel_name": "python3.12"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "2a4f1954-6c84-4327-9d1b-5090e493e152",
# META       "default_lakehouse_name": "lh_mmhci_datahub_dev",
# META       "default_lakehouse_workspace_id": "1ba3ebd5-d835-4cdc-85d9-80feb379778e",
# META       "known_lakehouses": [
# META         {
# META           "id": "2a4f1954-6c84-4327-9d1b-5090e493e152"
# META         }
# META       ]
# META     },
# META     "warehouse": {
# META       "default_warehouse": "54688cc8-cff0-454c-8489-c760ce6b17e1",
# META       "known_warehouses": [
# META         {
# META           "id": "54688cc8-cff0-454c-8489-c760ce6b17e1",
# META           "type": "Lakewarehouse"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

import pandas as pd
# from utils import (
#     setup_logger,
#     fetch_records,
#     export_to_csv,
# )
import numpy as np

# # Setup logger
# logger = setup_logger(__name__, "logs/practitioner.log")

# Table name for file export
TABLE_NAME = "Practitioner"

# Constant default variables for columns
CATEGORY_DEFAULT = 99  # Default to 99 - Not stated
ABORIGINAL_AND_TORRES_STRAIT_ISLANDER_CULTURAL_TRAINING_DEFAULT = (
    8  # Default to 8 - Not Required
)
COMPLETED_MENTAL_HEALTH_FIRST_AID_TRAINING_DEFAULT = 8  # Default to 8 - Not Required
# CLINICAL_ROLE_DEFAULT = None
ACTIVE_DEFAULT = 1
LEVEL_OF_CLINICAL_QUALIFICATION_DEFAULT = None
YEAR_OF_QUALIFICATION_DEFAULT = None
EMPLOYMENT_START_DEFAULT = "2026-03-30"
EMPLOYEMENT_END_DEFAULT = None
ORGANISATION_ID = "SVHA-MMHCI-01"

# Table Columns
# BOOKABLE_RESOURCE_COLUMNS = ["bookableresourceid", "_userid_value"]
# SYSTEM_USER_COLUMNS = ["systemuserid", "organizationid"]
# SYSTEM_USER_ROLE_COLUMNS = ["systemuserid", "roleid", "systemuserroleid"]
# ROLE_COLUMNS = ["roleid", "name"]

# Key columns for merging
BOOKABLE_RESOURCE_KEY = "userid"
SYSTEM_USER_KEY = "systemuserid"
SYSTEM_USER_ROLE_KEY="systemuserid"

# Mapping of the default values and additional columns
DEFAULT_COLUMN_VALUES = {
    "Category": CATEGORY_DEFAULT,
    "Aboriginal and Torres Strait Islander cultural training": ABORIGINAL_AND_TORRES_STRAIT_ISLANDER_CULTURAL_TRAINING_DEFAULT,
    "Completed Mental Health First Aid training": COMPLETED_MENTAL_HEALTH_FIRST_AID_TRAINING_DEFAULT,
    # "Clinical role": CLINICAL_ROLE_DEFAULT,
    "Active": ACTIVE_DEFAULT,
    "Level of clinical qualification": LEVEL_OF_CLINICAL_QUALIFICATION_DEFAULT,
    "Year of qualification": YEAR_OF_QUALIFICATION_DEFAULT,
    "Employment start": EMPLOYMENT_START_DEFAULT,
    "Employment end": EMPLOYEMENT_END_DEFAULT,
    "Year of birth": None,
    "Sex": None,
    "Gender": None,
    "Variations of sex characteristics": None,
    "Sexual orientation": None,
    "Aboriginal and Torres Strait Islander status": None,
    "Language spoken": None,
    "Experience assisting with mental ill-health episodes prior to working on program": None,
    "organizationid": ORGANISATION_ID,
}

# Mapping of DataFrame columns in order and to their corresponding names for CSV output
FINAL_COLUMNS_MAPPING = {
    "bookableresourceid": "Staff key",
    "organizationid": "Service provider organisation key",
    "systemuserid": "Base staff key",
    "Category": "Category",
    "name": "Clinical role",
    "Aboriginal and Torres Strait Islander cultural training": "Aboriginal and Torres Strait Islander cultural training",
    "Completed Mental Health First Aid training": "Completed Mental Health First Aid training",
    "Year of birth": "Year of birth",
    "Sex": "Sex",
    "Gender": "Gender",
    "Variations of sex characteristics": "Variations of sex characteristics",
    "Sexual orientation": "Sexual orientation",
    "Aboriginal and Torres Strait Islander status": "Aboriginal and Torres Strait Islander status",
    "Language spoken": "Language spoken",
    "Experience assisting with mental ill-health episodes prior to working on program": "Experience assisting with mental ill-health episodes prior to working on program",
    "Active": "Active",
    "Level of clinical qualification": "Level of clinical qualification",
    "Year of qualification": "Year of qualification",
    "Employment start": "Employment start",
    "Employment end": "Employment end",
}

def select_and_rename_columns(df: pd.DataFrame, columns_mapping: dict) -> pd.DataFrame:
    """
    Select and rename columns in a DataFrame

    Parameters:
        df (pd.DataFrame): Input DataFrame.
        columns_mapping (dict): Dictionary mapping old column names to new column names

    Returns:
        pd.DataFrame: DataFrame with selected and renamed columns
    """
    if df.empty:
        return df
    
    # Remove metadata columns (e.g., columns starting with "@")
    df = df.loc[:, ~df.columns.str.startswith("@")]
    # Select columns based on keys in the mapping
    selected_columns = list(columns_mapping.keys())
    df_selected = df[selected_columns]
    # Rename columns based on the mapping
    df_renamed = df_selected.rename(columns=columns_mapping)
    return df_renamed

def process_practitioner() -> pd.DataFrame:
    """
    Process the Practitioner by extracting, transforming and loading data from multiple dependent tables.

    Parameters:

    Returns:
        pd.DataFrame: Processed Practitioner Preference Table.
    """
    # Step 1: Fetch data from dependent tables
    try:
        # logger.info("Fetching data from dependent tables...")
        df_bookable_resource = pd.read_csv("/lakehouse/default/Files/raw/Dataverse/05/2026/bookableresource_tbl.parquet")
        df_system_user = pd.read_csv("/lakehouse/default/Files/raw/Dataverse/05/2026/systemuser.parquet")
        df_role = pd.read_csv("/lakehouse/default/Files/raw/Dataverse/05/2026/role.parquet")
        df_system_user_roles = pd.read_csv("/lakehouse/default/Files/raw/Dataverse/05/2026/systemuserroles.parquet")
        # logger.info("Data fectched successfully from dependent tables.")
    except Exception as e:
        # logger.exception(f"Error fetching data from tables: {e}")
        raise

    # Step 4: Merge tables
    try:
        # logger.info("Merging tables...")
        df_merged = df_bookable_resource.merge(
            df_system_user,
            how="left",
            left_on=BOOKABLE_RESOURCE_KEY,
            right_on=SYSTEM_USER_KEY
        )
        df_merged = df_merged.merge(
            df_system_user_roles,
            how="left",
            left_on=SYSTEM_USER_KEY,
            right_on=SYSTEM_USER_ROLE_KEY
        )
        df_merged = df_merged.merge(
            df_role,
            how="left",
            left_on="roleid",
            right_on="roleid"
        )
        # logger.info("Tables merged successfully.")
    except Exception as e:
        # logger.exception(f"Error merging tables: {e}")
        raise

    # Step 5: Apply transformations and extraction logic
    # logger.info("Applying transformations...")
    # Add additional columns and defualt values
    df_merged = df_merged.assign(**DEFAULT_COLUMN_VALUES)
    # logger.info("Transformations applied successfully.")

    # Step 6: Select columns to keep in the final table and rename
    df_merged = select_and_rename_columns(df_merged, FINAL_COLUMNS_MAPPING)

    # R3 Clinical role mapping
    df_merged["Clinical role"] = np.select(
        [
            df_merged["Clinical role"] == "Practitioner",
            df_merged["Clinical role"] == "Leader"
        ],
        [
            1, # practitioner
            3, # Team lead
        ],
        default=None
    )

    df_merged = df_merged.drop_duplicates()
    
    output_file = "/lakehouse/default/Files/processed/Dataverse/05/2026/Practitioner.csv"
    df_merged.to_csv(output_file, index=False)

    return df_merged

process_practitioner()


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "jupyter_python"
# META }
