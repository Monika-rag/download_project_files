# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {}
# META }

# CELL ********************

# Install dependencies if not already installed
# !pip install azure-identity requests

from azure.identity import DefaultAzureCredential
import requests
import json

# -----------------------------
# CONFIGURATION - EDIT THESE
# -----------------------------
DATAVERSE_URL = "https://orgad765dff.crm6.dynamics.com/"  # Your Dataverse environment URL
SCOPE = f"{DATAVERSE_URL}/.default"  # Resource scope for Dataverse

# -----------------------------
# AUTHENTICATION USING MANAGED IDENTITY
# -----------------------------
try:
    # DefaultAzureCredential will automatically use the workspace's managed identity
    credential = DefaultAzureCredential()

    # Get token for Dataverse
    token = credential.get_token(SCOPE)
    access_token = token.token
    print("✅ Managed identity authentication successful.")

except Exception as e:
    print(f"❌ Authentication error: {e}")
    raise

# -----------------------------
# TEST API CALL
# -----------------------------
try:
    headers = {
        "Authorization": f"Bearer {access_token}",
        "OData-MaxVersion": "4.0",
        "OData-Version": "4.0",
        "Accept": "application/json"
    }

    # Example: Retrieve top 1 account record
    response = requests.get(
        f"{DATAVERSE_URL}/api/data/v9.2/accounts?$top=1",
        headers=headers
    )

    if response.status_code == 200:
        print("✅ Dataverse connection successful.")
        print(json.dumps(response.json(), indent=2))
    else:
        print(f"❌ API call failed: {response.status_code} - {response.text}")

except Exception as e:
    print(f"❌ API request error: {e}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
