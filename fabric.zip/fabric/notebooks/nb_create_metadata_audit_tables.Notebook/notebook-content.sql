-- Fabric notebook source

-- METADATA ********************

-- META {
-- META   "kernel_info": {
-- META     "name": "synapse_pyspark"
-- META   },
-- META   "dependencies": {
-- META     "lakehouse": {
-- META       "default_lakehouse": "2a4f1954-6c84-4327-9d1b-5090e493e152",
-- META       "default_lakehouse_name": "lh_mmhci_datahub_dev",
-- META       "default_lakehouse_workspace_id": "1ba3ebd5-d835-4cdc-85d9-80feb379778e",
-- META       "known_lakehouses": [
-- META         {
-- META           "id": "2a4f1954-6c84-4327-9d1b-5090e493e152"
-- META         }
-- META       ]
-- META     }
-- META   }
-- META }

-- CELL ********************

CREATE TABLE IF NOT EXISTS dbo.md_ingestion_config (
    ingestion_config_id STRING,
    ingestion_name STRING,

    source_type STRING,
    connection_name STRING,
    source_object_name STRING,
    source_folder_path STRING,
    source_file_pattern STRING,

    load_type STRING,
    watermark_column STRING,
    watermark_value STRING,

    target_path STRING,
    target_file_name STRING,
    target_format STRING,
    write_mode STRING,

    schedule_group STRING,
    execution_sequence INT,
    active_flag BOOLEAN,

    created_at TIMESTAMP,
    updated_at TIMESTAMP
)
USING DELTA;

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

CREATE TABLE IF NOT EXISTS dbo.audit_pipeline_run (
    pipeline_run_id STRING,
    pipeline_name STRING,
    schedule_group STRING,
    run_status STRING,
    start_time TIMESTAMP,
    end_time TIMESTAMP,
    row_count INT,
    success_count INT,
    failure_count INT,
    error_message STRING,
    created_at TIMESTAMP,
    updated_at TIMESTAMP
)
USING DELTA;

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

CREATE TABLE IF NOT EXISTS dbo.audit_ingestion_run (
    ingestion_run_id STRING,
    pipeline_run_id STRING,
    ingestion_config_id STRING,

    source_type STRING,
    source_object_name STRING,
    source_file_name STRING,
    source_path STRING,
    target_path STRING,

    load_type STRING,
    run_status STRING,

    start_time TIMESTAMP,
    end_time TIMESTAMP,
    rows_read BIGINT,
    rows_written BIGINT,

    previous_watermark_value STRING,
    new_watermark_value STRING,

    error_message STRING,
    created_at TIMESTAMP,
    updated_at TIMESTAMP
)
USING DELTA;

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************


-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }
