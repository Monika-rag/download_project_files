# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "2a4f1954-6c84-4327-9d1b-5090e493e152",
# META       "default_lakehouse_name": "lh_mmhci_datahub_dev",
# META       "default_lakehouse_workspace_id": "1ba3ebd5-d835-4cdc-85d9-80feb379778e",
# META       "known_lakehouses": [
# META         {
# META           "id": "2a4f1954-6c84-4327-9d1b-5090e493e152"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

# from notebookutils import mssparkutils

# mssparkutils.fs.mkdirs("Files/raw/Dataverse/05/2026/course_of_libt")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

folder_path = "Files"
file_name = "folder_structure.txt"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from notebookutils import mssparkutils

full_file_path = f"{folder_path}/{file_name}"

content = mssparkutils.fs.head(full_file_path, 10000)

file_path = [
    path.strip().replace('"','').replace(',','') 
    for path in content.split("\n") 
    if path.strip()
]

for path in file_path:
    mssparkutils.fs.mkdirs(path)
    print(f"Created: {path}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

"""from notebookutils import mssparkutils

base_path = "Files/"

folders = [
    f"{base_path}/processed",
    f"{base_path}/raw/Dataverse/05/2026",
    f"{base_path}/raw/GCS/05/2026",
    f"{base_path}/processed/Dataverse/05/2026",
    f"{base_path}/processed/GCS/05/2026",
    f"{base_path}/error"
]

for folder in folders:
    mssparkutils.fs.mkdirs(folder)
    print(f"Created or already exists: {folder}")"""

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
