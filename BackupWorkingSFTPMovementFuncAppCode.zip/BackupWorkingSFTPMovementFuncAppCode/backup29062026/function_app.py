import json
import logging
import os
from datetime import datetime

import azure.functions as func
from azure.identity import ManagedIdentityCredential
from azure.keyvault.secrets import SecretClient
from services.onelake_service import OneLakeService
from services.sftp_service import SftpService


app = func.FunctionApp(http_auth_level=func.AuthLevel.FUNCTION)


# ============================================================
# Helper functions
# ============================================================

def to_bool(value) -> bool:
    return str(value).strip().lower() in ["true", "1", "yes", "y"]


def get_int_or_none(value):
    if value is None or str(value).strip() == "":
        return None
    return int(value)

def get_managed_identity_credential(key_vault_url):
    """
    Uses user-assigned managed identity client ID from Key Vault when available.
    Otherwise uses system-assigned managed identity.
    """
 
    managed_identity_client_id = os.getenv("MANAGED_IDENTITY_CLIENT_ID")
 
    if not managed_identity_client_id and key_vault_url:
        try:
            secret_name = os.getenv(
                "MANAGED_IDENTITY_CLIENT_ID_SECRET_NAME",
                "mmhci-edp-client-ID"
            )
 
            logging.info("Fetching managed identity client ID from Key Vault secret: %s", secret_name)
 
            # Bootstrap using system-assigned managed identity to read Key Vault
            bootstrap_credential = ManagedIdentityCredential()
 
            secret_client = SecretClient(
                vault_url=key_vault_url,
                credential=bootstrap_credential
            )
 
            managed_identity_client_id = secret_client.get_secret(secret_name).value
            logging.info("Fetching managed_identity_client_id value from Key Vault secret: %s", managed_identity_client_id)
 
        except Exception as ex:
            logging.warning(
                "Unable to fetch managed identity client ID from Key Vault. "
                "Falling back to system-assigned managed identity. Error: %s",
                str(ex)
            )

    return ManagedIdentityCredential(client_id=managed_identity_client_id.strip())

#def get_managed_identity_credential():
 #   """
  #  Uses user-assigned managed identity when MANAGED_IDENTITY_CLIENT_ID is available.
   # Otherwise uses system-assigned managed identity.
    #"""
    #managed_identity_client_id =  "dd81e28d-86ec-40ad-be60-129b99b8574f" # os.getenv("MANAGED_IDENTITY_CLIENT_ID")

    #if managed_identity_client_id:
     #   logging.info("Using user-assigned managed identity.")
      #  return ManagedIdentityCredential(client_id=managed_identity_client_id)

    #logging.info("Using system-assigned managed identity.")
    #return ManagedIdentityCredential()


def get_year_month_week(processing_date: str):
    """
    Derives year/month/week folder from processing_date.

    Week logic:
    01-07 = week01
    08-14 = week02
    15-21 = week03
    22-28 = week04
    29-31 = week05

    Example:
    2026-06-10 -> 2026/06/week02
    """
    if processing_date is None or str(processing_date).strip() == "":
        raise ValueError("processing_date is required.")

    processing_dt = datetime.strptime(str(processing_date)[:10], "%Y-%m-%d")

    year = processing_dt.strftime("%Y")
    month = processing_dt.strftime("%m")
    week_no = ((processing_dt.day - 1) // 7) + 1
    week_folder = f"week{week_no:02d}"

    return year, month, week_folder


def build_weekly_onelake_folder(
    base_folder: str,
    year: str,
    month: str,
    week_folder: str,
    sub_folder: str = None
) -> str:
    """
    Builds weekly Lakehouse folder path.

    Example:
    base_folder = Files/processed/Dataverse
    year = 2026
    month = 06
    week_folder = week02

    Output:
    Files/processed/Dataverse/2026/06/week02
    """
    if base_folder is None or str(base_folder).strip() == "":
        raise ValueError("base_folder is required.")

    folder_path = (
        f"{str(base_folder).strip().strip('/')}/"
        f"{year}/{month}/{week_folder}"
    )

    if sub_folder is not None and str(sub_folder).strip() != "":
        folder_path = f"{folder_path}/{str(sub_folder).strip().strip('/')}"

    return folder_path


def build_sftp_target_folder(
    sftp_target_base_folder: str,
    year: str,
    month: str,
    week_folder: str,
    target_sub_folder: str = None,
    append_week_to_sftp_target: bool = False
) -> str:
    """
    Builds final SFTP target folder.

    If append_week_to_sftp_target=False:
      /inbound

    If append_week_to_sftp_target=True:
      /inbound/2026/06/week02

    If target_sub_folder is passed:
      /inbound/2026/06/week02/practitioner
    """
    if sftp_target_base_folder is None or str(sftp_target_base_folder).strip() == "":
        raise ValueError("sftp_target_base_folder is required.")

    folder_path = str(sftp_target_base_folder).strip().rstrip("/")

    if append_week_to_sftp_target:
        folder_path = f"{folder_path}/{year}/{month}/{week_folder}"

    if target_sub_folder is not None and str(target_sub_folder).strip() != "":
        folder_path = f"{folder_path}/{str(target_sub_folder).strip().strip('/')}"

    return folder_path


# ============================================================
# HTTP trigger called from Fabric Function Activity
# ============================================================

@app.route(route="move-weekly-onelake-to-sftp", methods=["POST"])
def move_onelake_files(req: func.HttpRequest) -> func.HttpResponse:
    """
    HTTP-triggered Azure Function.

    Called from Fabric Function Activity.

    Current scope:
    - Connect to Fabric OneLake using Function App Managed Identity.
    - Pick files from weekly OneLake source folder.
    - Validate source file count.
    - Upload files to SFTP target folder.
    - Validate uploaded file size on SFTP.
    - Optionally delete source file after successful upload validation.

    Example OneLake source:
    Files/processed/Dataverse/2026/06/week02

    Example SFTP target:
    /inbound
    or /inbound/2026/06/week02 when append_week_to_sftp_target=true
    """

    logging.info("Started move-weekly-onelake-to-sftp HTTP function.")

    try:
        try:
            body = req.get_json()
        except ValueError:
            body = {}

        logging.info("Request body received: %s", json.dumps(body))

        # ------------------------------------------------------------
        # Runtime parameters from Fabric body
        # ------------------------------------------------------------
        processing_date = body.get("processing_date")

        source_base_folder = (
            body.get("source_base_folder")
            or os.getenv("ONELAKE_SOURCE_BASE_FOLDER")
            or os.getenv("ONELAKE_SOURCE_FOLDER")
        )

        source_sub_folder = body.get("source_sub_folder")

        file_pattern = body.get("file_pattern") or os.getenv("FILE_PATTERN", "*")

        expected_file_count = get_int_or_none(
            body.get("expected_file_count")
            or os.getenv("EXPECTED_FILE_COUNT")
        )

        recursive_copy = to_bool(
            body.get("recursive", os.getenv("RECURSIVE_COPY", "false"))
        )

        fail_if_no_files = to_bool(
            body.get("fail_if_no_files", os.getenv("FAIL_IF_NO_FILES", "true"))
        )

        delete_source_after_upload = False
        
        # SFTP target details. Credentials still come from Key Vault, not from Fabric body.

        sftp_target_base_folder = (
            body.get("sftp_target_base_folder")
            or body.get("sftp_target_folder")
            or "inbox"
        )
 
       
        processing_date_folder = str(processing_date)[:10]
 
        sftp_target_sub_folder = body.get("sftp_target_sub_folder")
 
        if sftp_target_sub_folder is not None and str(sftp_target_sub_folder).strip() != "":
            sftp_target_sub_folder = (
                f"{processing_date_folder}/"
                f"{str(sftp_target_sub_folder).strip().strip('/')}")
        else:
            sftp_target_sub_folder = processing_date_folder

        sftp_target_sub_folder = body.get("sftp_target_sub_folder")

        append_week_to_sftp_target = to_bool(
            body.get("append_week_to_sftp_target", os.getenv("APPEND_WEEK_TO_SFTP_TARGET", "false"))
        )

        create_sftp_target_folder = to_bool(
            body.get("create_sftp_target_folder", os.getenv("CREATE_SFTP_TARGET_FOLDER", "true"))
        )

        overwrite_sftp_file = to_bool(
            body.get("overwrite_sftp_file", os.getenv("OVERWRITE_SFTP_FILE", "true"))
        )

        # ------------------------------------------------------------
        # Environment variables from Azure Function App configuration
        # ------------------------------------------------------------
        fabric_workspace_name = (
            body.get("fabric_workspace_name")
            or os.getenv("FABRIC_WORKSPACE_NAME")
        )

        lakehouse_name = (
            body.get("lakehouse_name")
            or os.getenv("FABRIC_LAKEHOUSE_NAME")
        )

        key_vault_url = (
            body.get("key_vault_url")
            or os.getenv("KEY_VAULT_URL")
        )

        if not fabric_workspace_name:
            raise ValueError("FABRIC_WORKSPACE_NAME is required in app settings or request body.")

        if not lakehouse_name:
            raise ValueError("FABRIC_LAKEHOUSE_NAME is required in app settings or request body.")

        if not key_vault_url:
            raise ValueError("KEY_VAULT_URL is required in app settings or request body.")

        if not source_base_folder:
            raise ValueError("source_base_folder or ONELAKE_SOURCE_FOLDER is required.")

        if not sftp_target_base_folder:
            raise ValueError("sftp_target_base_folder or SFTP_TARGET_FOLDER is required.")

        # ------------------------------------------------------------
        # Build weekly source and SFTP target paths
        # ------------------------------------------------------------
        year, month, week_folder = get_year_month_week(processing_date)

        onelake_source_folder = build_weekly_onelake_folder(
            base_folder=source_base_folder,
            year=year,
            month=month,
            week_folder=week_folder,
            sub_folder=source_sub_folder
        )

        sftp_target_folder = build_sftp_target_folder(
            sftp_target_base_folder=sftp_target_base_folder,
            year=year,
            month=month,
            week_folder=week_folder,
            target_sub_folder=sftp_target_sub_folder,
            append_week_to_sftp_target=append_week_to_sftp_target
        )

        logging.info("FABRIC_WORKSPACE_NAME: %s", fabric_workspace_name)
        logging.info("FABRIC_LAKEHOUSE_NAME: %s", lakehouse_name)
        logging.info("Processing date: %s", processing_date)
        logging.info("Year/month/week: %s/%s/%s", year, month, week_folder)
        logging.info("OneLake source folder: %s", onelake_source_folder)
        logging.info("SFTP target folder: %s", sftp_target_folder)
        logging.info("File pattern: %s", file_pattern)
        logging.info("Expected file count: %s", expected_file_count)
        logging.info("Recursive: %s", recursive_copy)
        logging.info("Fail if no files: %s", fail_if_no_files)
        logging.info("Delete source after upload: %s", delete_source_after_upload)
        logging.info("Append week to SFTP target: %s", append_week_to_sftp_target)
        logging.info("Create SFTP target folder: %s", create_sftp_target_folder)
        logging.info("Overwrite SFTP file: %s", overwrite_sftp_file)

        # ------------------------------------------------------------
        # Connect to OneLake and SFTP
        # ------------------------------------------------------------
        credential = get_managed_identity_credential(key_vault_url=key_vault_url)

        onelake_service = OneLakeService(
            credential=credential,
            workspace_name=fabric_workspace_name,
            lakehouse_name=lakehouse_name
        )

        sftp_service = SftpService(
            credential=credential,
            key_vault_url=key_vault_url
        )

        # ------------------------------------------------------------
        # List and validate source files
        # ------------------------------------------------------------
        source_files = onelake_service.list_matching_files(
            folder_path=onelake_source_folder,
            file_pattern=file_pattern,
            recursive=recursive_copy
        )

        source_file_count = len(source_files)

        if source_file_count == 0:
            message = f"No matching files found in OneLake source folder: {onelake_source_folder}"
            if fail_if_no_files:
                raise FileNotFoundError(message)
            logging.warning(message)

        if expected_file_count is not None and source_file_count != expected_file_count:
            raise ValueError(
                f"Source file count validation failed. "
                f"Expected: {expected_file_count}, Actual: {source_file_count}, "
                f"Source folder: {onelake_source_folder}"
            )

        uploaded_files = []

        # ------------------------------------------------------------
        # Upload files to SFTP. Delete OneLake source only after all uploads pass.
        # ------------------------------------------------------------
        for source_file_path in source_files:
            file_name = onelake_service.get_file_name(source_file_path)
            file_content = onelake_service.read_file_by_full_path(source_file_path)

            upload_result = sftp_service.upload_bytes(
                file_content=file_content,
                target_folder=sftp_target_folder,
                file_name=file_name,
                create_target_folder=create_sftp_target_folder,
                overwrite=overwrite_sftp_file,
                validate_size=True
            )

            uploaded_files.append({
                "file_name": file_name,
                "onelake_source_path": source_file_path,
                "sftp_target_path": upload_result["target_file_path"],
                "source_size_bytes": len(file_content),
                "sftp_size_bytes": upload_result["remote_size_bytes"],
                "status": "uploaded"
            })

        uploaded_file_count = len(uploaded_files)

        if uploaded_file_count != source_file_count:
            raise ValueError(
                f"Uploaded file count validation failed. "
                f"Source count: {source_file_count}, Uploaded count: {uploaded_file_count}"
            )

        deleted_source_file_count = 0

        #if delete_source_after_upload:
         #   for source_file_path in source_files:
          #      onelake_service.delete_file_by_full_path(source_file_path)
           #     deleted_source_file_count += 1

            #for file_info in uploaded_files:
             #   file_info["status"] = "moved_to_sftp"

        response = {
            "status": "success",
            "message": "OneLake weekly file upload to SFTP completed successfully.",
            "processing_date": processing_date,
            "year": year,
            "month": month,
            "week_folder": week_folder,
            "onelake_source_folder": onelake_source_folder,
            "sftp_target_folder": sftp_target_folder,
            "source_file_count": source_file_count,
            "uploaded_file_count": uploaded_file_count,
            "deleted_source_file_count": deleted_source_file_count,
            "delete_source_after_upload": delete_source_after_upload,
            "files": uploaded_files
        }

        logging.info("Function completed successfully: %s", json.dumps(response))

        return func.HttpResponse(
            json.dumps(response, indent=2),
            status_code=200,
            mimetype="application/json"
        )

    except Exception as ex:
        logging.exception("move-weekly-onelake-to-sftp failed.")

        response = {
            "status": "failed",
            "error_message": str(ex)
        }

        return func.HttpResponse(
            json.dumps(response, indent=2),
            status_code=500,
            mimetype="application/json"
        )
